package com.adjdev.livetranslate.ai

import com.adjdev.livetranslate.settings.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets

/**
 * Tier COPILOT yang manggil server LLM di infrastruktur MILIK USER SENDIRI (mis. VPS pribadi
 * menjalankan llama.cpp server / Ollama / vLLM) lewat endpoint OpenAI-compatible
 * "/v1/chat/completions" — skema paling universal per Agustus 2026, jadi tidak mengunci ke satu
 * software server tertentu (llama.cpp server, Ollama, vLLM, LM Studio semuanya kompatibel).
 *
 * KENAPA INI ADA: model on-device (LocalLlmCopilotEngine) terbukti bisa CRASH TOTAL (native
 * SIGSEGV di liblitertlm_jni.so, tidak bisa ditangkap try/catch Kotlin karena crash-nya di
 * level native, bukan JVM exception) di device RAM 4GB kelas menengah. Kalau user punya server
 * sendiri dengan resource lebih longgar (mis. VPS 8GB RAM/2 core), jalur ini jauh lebih stabil.
 * Konsekuensinya: teks transcript dikirim lewat jaringan ke server TERSEBUT — bukan lagi murni
 * on-device. Karena server itu milik/dikontrol user sendiri (bukan pihak ketiga), ini tetap
 * sejalan dengan prinsip "tanpa cloud pihak ketiga" — tapi BUKAN lagi "tanpa jaringan sama
 * sekali", makanya field ini sengaja opt-in (URL kosong = tier ini otomatis dilewati, UNAVAILABLE
 * tanpa error).
 *
 * Stateless per panggilan (bukan sesi/histori tersimpan di server) — konsisten dengan sifat
 * request LocalLlmCopilotEngine yang lain, dan menghindari server menumpuk state per user tanpa
 * batas.
 *
 * ⚠️ BELUM PERNAH DITES ke server sungguhan (sandbox pembuatan kode ini tidak punya akses
 * jaringan ke VPS mana pun). Skema request/response yang dipakai (messages[], choices[0]
 * .message.content) adalah skema OpenAI Chat Completions standar yang direplikasi hampir semua
 * server self-hosted populer — kalau server kamu punya skema custom/berbeda, respons akan gagal
 * di-parse dan generateSuggestions() akan diam-diam mengembalikan list kosong (lihat try/catch
 * di bawah), bukan crash. Cek response body server kamu langsung (curl) kalau ini terjadi terus.
 *
 * CATATAN CLEARTEXT HTTP: VPS pribadi biasanya belum punya sertifikat TLS. Manifest app ini
 * mengizinkan cleartext traffic (usesCleartextTraffic) supaya http:// biasa tidak diblokir
 * Android — tapi itu berarti transcript percakapan lewat jaringan TANPA enkripsi kalau kamu
 * pakai http:// polos. Kalau VPS-nya diakses lewat internet publik (bukan cuma VPN/LAN
 * pribadi), sangat disarankan taruh reverse proxy TLS (mis. Caddy, gratis & otomatis HTTPS) di
 * depan llama.cpp server, lalu pakai https:// di sini.
 */
class RemoteCopilotEngine(
    private val settingsRepository: SettingsRepository
) : AIEngine {

    companion object {
        private const val CONNECT_TIMEOUT_MS = 5_000
        // VPS CPU-only 2 core biasanya jauh lebih lambat dari GPU cloud — timeout digenerkan
        // supaya masih terasa "hidup" untuk suggested replies real-time, tapi tidak nge-hang.
        private const val READ_TIMEOUT_MS = 20_000
        private const val OVERALL_TIMEOUT_MS = 25_000L
    }

    override var status: AIEngineStatus = AIEngineStatus.IDLE
        private set

    private var baseUrl: String? = null

    private var _lastError: String? = null
    override val lastError: String? get() = _lastError

    override suspend fun load() {
        // "Load" di sini cuma cek konfigurasi (bukan model beneran, tidak ada yang perlu
        // dimuat ke RAM device) — percobaan koneksi HTTP baru terjadi di generateSuggestions(),
        // supaya toggle Copilot ON tidak terasa lambat/nge-hang kalau VPS kebetulan sedang mati.
        baseUrl = settingsRepository.remoteCopilotUrl.first()
        status = if (baseUrl != null) AIEngineStatus.READY else AIEngineStatus.UNAVAILABLE
        _lastError = null
    }

    override fun unload() {
        baseUrl = null
        status = AIEngineStatus.IDLE
        _lastError = null
    }

    override suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>
    ): List<SuggestedReply> {
        val url = baseUrl ?: return emptyList()
        if (status != AIEngineStatus.READY) return emptyList()
        status = AIEngineStatus.GENERATING
        _lastError = null

        val result = try {
            withTimeoutOrNull(OVERALL_TIMEOUT_MS) {
                withContext(Dispatchers.IO) {
                    callChatCompletions(url, incomingTranslatedText, recentContext)
                }
            } ?: run {
                _lastError = "Timeout — VPS tidak merespons dalam ${OVERALL_TIMEOUT_MS / 1000} detik."
                emptyList()
            }
        } catch (e: Exception) {
            _lastError = "Koneksi ke VPS gagal: ${e.message ?: e.javaClass.simpleName}"
            emptyList()
        }

        // Sengaja tidak jadi UNAVAILABLE meski gagal (network flaky sekali panggil bukan
        // berarti VPS mati permanen) — biar dicoba lagi di panggilan berikutnya. Beda dengan
        // LocalLlmCopilotEngine yang UNAVAILABLE permanen kalau modelnya memang belum diimpor.
        status = AIEngineStatus.READY
        return result
    }

    private suspend fun callChatCompletions(
        baseUrl: String,
        incomingTranslatedText: String,
        recentContext: List<String>
    ): List<SuggestedReply> {
        val apiKey = settingsRepository.remoteCopilotApiKey.first()
        val modelName = settingsRepository.remoteCopilotModelName.first()

        val contextBlock = recentContext.takeLast(6).joinToString("\n") { "- $it" }
        val systemPrompt = "Kamu membantu menyusun balasan singkat dalam sebuah percakapan yang " +
            "sedang diterjemahkan live. Balas HANYA 3 baris saran balasan singkat (maksimal 12 " +
            "kata masing-masing), satu baris satu saran, tanpa nomor, tanpa tanda kutip, tanpa " +
            "penjelasan tambahan."
        val userPrompt = buildString {
            if (contextBlock.isNotBlank()) {
                appendLine("Giliran-giliran sebelumnya:")
                appendLine(contextBlock)
            }
            append("Pesan lawan bicara barusan: \"$incomingTranslatedText\"")
        }

        val requestBody = JSONObject().apply {
            put("model", modelName)
            put("temperature", 0.7)
            put("max_tokens", 120)
            put("messages", JSONArray().apply {
                put(JSONObject().put("role", "system").put("content", systemPrompt))
                put(JSONObject().put("role", "user").put("content", userPrompt))
            })
        }

        // FIX bug "suggested replies kosong tanpa error setelah Remote AI dikonfigurasi":
        // baseUrl dari user BISA sudah termasuk "/v1" di akhir (persis kayak yang dites lewat
        // curl: "https://host/v1/chat/completions") ATAU cuma host polos (sesuai contoh hint di
        // Settings: "http://203.0.113.5:8080"). Sebelumnya kode ini SELALU nempelin
        // "/v1/chat/completions" tanpa cek, jadi kalau user sudah isi URL yang diakhiri "/v1"
        // hasilnya jadi ".../v1/v1/chat/completions" — 404, lalu ditangkap silent sebagai emptyList() di bawah,
        // TANPA pesan error apapun ke user. resolveChatCompletionsUrl() menormalkan tiga bentuk
        // input yang mungkin (host polos / diakhiri "/v1" / sudah lengkap sampai
        // "/chat/completions") supaya tidak dobel apapun caranya user mengisi field-nya.
        val connection = (URL(resolveChatCompletionsUrl(baseUrl)).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            if (!apiKey.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }

        try {
            connection.outputStream.use { it.write(requestBody.toString().toByteArray(StandardCharsets.UTF_8)) }

            val code = connection.responseCode
            if (code !in 200..299) {
                // Sebelumnya diam total di sini — sekarang kelihatan di logcat DAN dikirim balik
                // sebagai lastError, supaya masalah konfigurasi (URL salah, model name typo
                // seperti kasus "local-model" vs nama model asli di server, API key salah, dst)
                // tidak lagi terlihat identik dengan "AI-nya emang gak ada saran" dari sisi user.
                val errorBody = runCatching {
                    connection.errorStream?.bufferedReader(StandardCharsets.UTF_8)?.use { it.readText() }
                }.getOrNull()
                android.util.Log.w(
                    "RemoteCopilotEngine",
                    "Remote AI HTTP $code dari ${connection.url} — body: ${errorBody ?: "(kosong)"}"
                )
                _lastError = "VPS balas HTTP $code" + if (!errorBody.isNullOrBlank()) {
                    " — ${errorBody.take(150)}"
                } else ""
                return emptyList()
            }

            val responseText = connection.inputStream.bufferedReader(StandardCharsets.UTF_8).use { it.readText() }
            val content = try {
                JSONObject(responseText)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
            } catch (e: Exception) {
                // Server merespons 200 tapi skema JSON-nya beda dari OpenAI Chat Completions
                // standar (lihat catatan kejujuran di kelas ini) — dilaporkan, bukan diam-diam.
                _lastError = "Respons VPS tidak sesuai skema OpenAI (choices[0].message.content): ${e.message}"
                return emptyList()
            }

            return content.lines()
                .map { it.trim().trimStart('-', '*', '•').trim().trim('"') }
                .filter { it.isNotBlank() }
                .take(3)
                .map { SuggestedReply(it, ReplyTone.NATURAL) }
        } finally {
            connection.disconnect()
        }
    }

    /**
     * Normalisasi [rawBaseUrl] jadi endpoint chat completions lengkap, apapun bentuk yang
     * dimasukkan user di Settings:
     * - "http://host:port"              -> "http://host:port/v1/chat/completions"
     * - "http://host:port/v1"           -> "http://host:port/v1/chat/completions"  (BUKAN /v1/v1/...)
     * - "http://host:port/v1/chat/completions" -> dipakai apa adanya
     */
    private fun resolveChatCompletionsUrl(rawBaseUrl: String): String {
        val trimmed = rawBaseUrl.trim().trimEnd('/')
        return when {
            trimmed.endsWith("/chat/completions") -> trimmed
            trimmed.endsWith("/v1") -> "$trimmed/chat/completions"
            else -> "$trimmed/v1/chat/completions"
        }
    }
}
