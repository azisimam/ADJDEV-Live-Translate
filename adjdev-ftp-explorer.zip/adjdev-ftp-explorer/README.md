# ADJDEV FTP Explorer

File manager Android native modern yang terinspirasi dari Solid Explorer, dengan fokus utama
mengelola file melalui **FTP**, **FTPS**, dan **SFTP**. Dibangun dengan Kotlin, Jetpack Compose,
dan Material 3.

## Fitur utama

- Server manager dengan penyimpanan banyak koneksi (FTP / FTPS / SFTP), kredensial dienkripsi
  memakai Android Keystore (AES-256/GCM) — password tidak pernah disimpan sebagai plaintext.
- File browser remote: browse, upload, download, buat folder/file, rename, delete, copy, move,
  multi-select, search rekursif, sort (nama/ukuran/tanggal/tipe), file hidden, properti file,
  bookmark folder, symlink & permission (jika didukung protokol).
- Local file browser sederhana untuk memilih file upload / lokasi download.
- Transfer manager serius: queue, progress, speed, ETA, pause/resume/cancel/retry, auto-retry,
  transfer paralel (jumlah konfigurabel), riwayat transfer, daftar transfer gagal, foreground
  service + notifikasi agar transfer tetap berjalan di background.
- Viewer bawaan: gambar, teks/kode (dengan syntax highlighting ringan), PDF (native
  `PdfRenderer`), plus text editor sederhana (edit → save/save as → otomatis re-upload ke server
  untuk file remote).
- Halaman informasi koneksi (status, protokol, host, port, status enkripsi, latency, log sesi),
  dengan opsi kirim raw FTP command (khusus FTP/FTPS).
- Dark mode & Light mode, Material 3, bottom navigation, breadcrumb, context menu (bottom sheet),
  multi-select.
- Settings: tema, folder download default, overwrite policy, concurrency transfer, auto retry,
  timeout, show hidden files, confirm before delete, notifikasi transfer, clear history.

## Teknologi & arsitektur

- Kotlin, Jetpack Compose, Material 3, Gradle Kotlin DSL
- MVVM + Repository pattern, Hilt (dependency injection), Kotlin Coroutines + StateFlow
- Room (server list, bookmark, riwayat transfer), DataStore Preferences (settings)
- Apache Commons Net (FTP/FTPS), sshj (SFTP) — diakses lewat interface `RemoteFileSystem` yang
  protocol-agnostic, sehingga UI tidak pernah bergantung langsung pada library FTP/SFTP tertentu
- Coil (image loading), `android.graphics.pdf.PdfRenderer` (PDF, tanpa dependency tambahan)
- Minimum SDK 26 (Android 8.0), target SDK terbaru stabil (34)

## Struktur proyek

```
app/src/main/java/com/adjdev/ftpexplorer/
├── data/
│   ├── remote/        # RemoteFileSystem interface + implementasi FTP/FTPS & SFTP
│   ├── local/          # Local file browser
│   ├── db/              # Room entities & DAO (server, bookmark, transfer history)
│   ├── security/       # CredentialManager (Android Keystore AES-GCM)
│   └── repository/     # Server, Settings, Session, Bookmark, TransferHistory repositories
├── transfer/            # TransferManager (queue engine) + TransferService (foreground service)
├── di/                   # Hilt modules
└── ui/                   # Compose screens per fitur (home, servers, browser, transfers,
                            settings, viewer, connectioninfo, search) + navigation & common widgets
```

## Cara build

### Build lokal (tanpa Android Studio)

Project ini menyertakan Gradle Wrapper (`gradlew` / `gradlew.bat`). Karena berkas biner
`gradle/wrapper/gradle-wrapper.jar` tidak dapat dihasilkan dari lingkungan sandbox tanpa akses
jaringan yang membuat repo ini, jalankan sekali saja sebelum build pertama (butuh Gradle
terinstall di mesin Anda, atau gunakan [SDKMAN](https://sdkman.io/) / package manager OS):

```bash
gradle wrapper --gradle-version 8.9
```

Setelah `gradle-wrapper.jar` ada, build seperti biasa:

```bash
./gradlew assembleDebug
```

APK debug akan berada di `app/build/outputs/apk/debug/`.

> Catatan: GitHub Actions workflow di repo ini (`.github/workflows/build.yml` dan `release.yml`)
> sudah menangani langkah `gradle wrapper` ini secara otomatis, jadi build di CI berjalan tanpa
> langkah manual apa pun.

### Requirement

- JDK 17
- Android SDK (compileSdk 34) — untuk build lokal tanpa Android Studio, install lewat
  `sdkmanager` (Android command line tools) dan set `ANDROID_HOME`/`local.properties`
- Koneksi internet saat build pertama (mengunduh dependency Gradle/Maven)

### Build dari Android Studio

Buka folder project di Android Studio (Giraffe/Koala atau lebih baru yang mendukung AGP 8.5+),
biarkan Gradle sync, lalu jalankan konfigurasi run seperti biasa. Android Studio akan otomatis
melengkapi `gradle-wrapper.jar` yang hilang saat sinkronisasi pertama.

## GitHub Actions (CI)

- **`.github/workflows/build.yml`** — berjalan di setiap push/PR ke `main`/`master`: checkout,
  setup JDK 17, generate wrapper jar bila belum ada, build `assembleDebug`, upload APK sebagai
  artifact.
- **`.github/workflows/release.yml`** — berjalan saat GitHub Release dipublikasikan (atau manual
  via `workflow_dispatch`): build `assembleRelease` (APK unsigned — repo ini sengaja tidak
  menyimpan keystore/signing secret apa pun) dan melampirkannya ke Release.

## Keamanan

- Password server dienkripsi dengan kunci AES-256-GCM yang dibuat & disimpan di Android Keystore
  (hardware-backed bila didukung perangkat); ciphertext + IV disimpan di Room, kunci tidak pernah
  meninggalkan Keystore.
- Tidak ada credential/API key yang di-hardcode di source code.
- FTPS memvalidasi sertifikat lewat trust store sistem (`FTPSClient`); SFTP saat ini memakai
  trust-on-first-use (`PromiscuousVerifier`) untuk host key — cocok untuk server pribadi/self-
  hosted; pinning host key per-server adalah pengembangan lanjutan yang disarankan untuk
  lingkungan yang butuh verifikasi ketat.
- Semua exception jaringan ditangani lewat tipe `RemoteException` (connection refused,
  authentication failed, timeout, permission denied, file not found, disk error, connection lost,
  TLS error, SFTP error) dengan opsi Retry/Reconnect di UI.

## Known limitations (transparansi)

- Copy folder (directory-to-directory) antar remote saat ini belum didukung penuh (copy file
  tunggal sudah berfungsi lewat download+upload internal); directory copy akan mengembalikan
  error yang jelas alih-alih diam-diam gagal.
- Verifikasi host key SFTP masih trust-on-first-use, belum ada pinning/known_hosts persisten.
- Syntax highlighting pada text editor bersifat ringan (regex-based: keyword/string/comment/
  angka), bukan grammar highlighting penuh seperti IDE.

## Lisensi pihak ketiga

Project ini menggunakan pustaka open-source berikut: Apache Commons Net (Apache 2.0), sshj
(Apache 2.0), Bouncy Castle (MIT), Jetpack Compose & AndroidX (Apache 2.0), Coil (Apache 2.0),
Dagger Hilt (Apache 2.0). Lisensi masing-masing tetap berlaku sesuai proyek asal.
