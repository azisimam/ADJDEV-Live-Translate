package com.adjdev.ftpexplorer.data.repository

import com.adjdev.ftpexplorer.data.db.ServerDao
import com.adjdev.ftpexplorer.data.db.ServerEntity
import com.adjdev.ftpexplorer.data.remote.ConnectionConfig
import com.adjdev.ftpexplorer.data.remote.Protocol
import com.adjdev.ftpexplorer.data.remote.TlsMode
import com.adjdev.ftpexplorer.data.security.CredentialManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ServerRepository @Inject constructor(
    private val dao: ServerDao,
    private val credentialManager: CredentialManager
) {

    fun observeServers(): Flow<List<Server>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    fun observeRecent(limit: Int = 5): Flow<List<Server>> =
        dao.observeRecent(limit).map { list -> list.map { it.toDomain() } }

    suspend fun getServer(id: String): Server? = dao.getById(id)?.toDomain()

    /** Resolves a full [ConnectionConfig] with the password decrypted, for actual use only. */
    suspend fun getConnectionConfig(id: String): ConnectionConfig? {
        val entity = dao.getById(id) ?: return null
        return ConnectionConfig(
            serverId = entity.id,
            name = entity.name,
            host = entity.host,
            port = entity.port,
            username = entity.username,
            password = credentialManager.decrypt(entity.encryptedPassword),
            protocol = Protocol.valueOf(entity.protocol),
            passiveMode = entity.passiveMode,
            tlsMode = TlsMode.valueOf(entity.tlsMode),
            timeoutSeconds = entity.timeoutSeconds,
            defaultRemoteDir = entity.defaultRemoteDir
        )
    }

    suspend fun saveServer(draft: ServerDraft): String {
        val id = draft.id ?: UUID.randomUUID().toString()
        val existing = draft.id?.let { dao.getById(it) }
        val encryptedPassword = if (draft.password.isNotEmpty()) {
            credentialManager.encrypt(draft.password)
        } else {
            existing?.encryptedPassword ?: credentialManager.encrypt("")
        }
        val entity = ServerEntity(
            id = id,
            name = draft.name,
            host = draft.host,
            port = draft.port,
            username = draft.username,
            encryptedPassword = encryptedPassword,
            protocol = draft.protocol.name,
            passiveMode = draft.passiveMode,
            tlsMode = draft.tlsMode.name,
            timeoutSeconds = draft.timeoutSeconds,
            defaultRemoteDir = draft.defaultRemoteDir,
            isFavorite = draft.isFavorite,
            lastConnectedAt = existing?.lastConnectedAt,
            createdAt = existing?.createdAt ?: System.currentTimeMillis()
        )
        dao.upsert(entity)
        return id
    }

    suspend fun deleteServer(server: Server) {
        dao.getById(server.id)?.let { dao.delete(it) }
    }

    suspend fun setFavorite(id: String, favorite: Boolean) = dao.setFavorite(id, favorite)

    suspend fun touchLastConnected(id: String) = dao.touchLastConnected(id, System.currentTimeMillis())

    private fun ServerEntity.toDomain() = Server(
        id = id,
        name = name,
        host = host,
        port = port,
        username = username,
        protocol = Protocol.valueOf(protocol),
        passiveMode = passiveMode,
        tlsMode = TlsMode.valueOf(tlsMode),
        timeoutSeconds = timeoutSeconds,
        defaultRemoteDir = defaultRemoteDir,
        isFavorite = isFavorite,
        lastConnectedAt = lastConnectedAt
    )
}
