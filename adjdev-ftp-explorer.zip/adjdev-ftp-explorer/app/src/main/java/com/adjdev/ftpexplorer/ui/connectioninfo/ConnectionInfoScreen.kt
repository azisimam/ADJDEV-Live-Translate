package com.adjdev.ftpexplorer.ui.connectioninfo

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun ConnectionInfoScreen(
    onBack: () -> Unit,
    viewModel: ConnectionInfoViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val info = state.info

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Connection Info") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
                actions = { IconButton(onClick = viewModel::refresh) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh") } }
            )
        }
    ) { padding ->
        Column(modifier = Modifier
            .padding(padding)
            .fillMaxSize()
            .padding(16.dp)) {

            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    InfoRow("Status", if (info?.isConnected == true) "Connected" else "Disconnected")
                    InfoRow("Protocol", info?.protocol?.name ?: "-")
                    InfoRow("Host", info?.host ?: "-")
                    InfoRow("Port", info?.port?.toString() ?: "-")
                    Row {
                        Icon(
                            if (info?.isEncrypted == true) Icons.Filled.Lock else Icons.Filled.LockOpen,
                            contentDescription = null,
                            tint = if (info?.isEncrypted == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                        Text(if (info?.isEncrypted == true) "Encryption enabled" else "No encryption")
                    }
                    InfoRow("Latency", state.latencyMs?.let { "$it ms" } ?: "-")
                    info?.serverGreeting?.let { InfoRow("Server", it.take(120)) }
                }
            }

            Row(modifier = Modifier.padding(vertical = 12.dp)) {
                OutlinedButton(onClick = viewModel::measureLatency, enabled = !state.isMeasuringLatency, modifier = Modifier.padding(end = 8.dp)) {
                    Text(if (state.isMeasuringLatency) "Measuring..." else "Ping")
                }
                Button(onClick = viewModel::reconnect) { Text("Reconnect") }
            }

            if (viewModel.supportsRawCommand()) {
                Text("Raw FTP command", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
                Text(
                    "Advanced: send a raw command directly to the FTP/FTPS server. Use with care.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)) {
                    OutlinedTextField(
                        value = state.rawCommand,
                        onValueChange = viewModel::onRawCommandChange,
                        placeholder = { Text("e.g. SYST") },
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = viewModel::sendRawCommand, modifier = Modifier.padding(start = 8.dp)) { Text("Send") }
                }
                state.rawCommandResult?.let {
                    Text(it, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 8.dp))
                }
            }

            Text("Session log", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 16.dp, bottom = 4.dp))
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(info?.log.orEmpty()) { line ->
                    Text(line, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 2.dp))
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 4.dp)) {
        Text(label, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Text(value, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
