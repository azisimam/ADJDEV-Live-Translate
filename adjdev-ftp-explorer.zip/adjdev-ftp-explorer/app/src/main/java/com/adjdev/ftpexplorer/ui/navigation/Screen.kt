package com.adjdev.ftpexplorer.ui.navigation

import android.net.Uri

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object ServerList : Screen("servers")
    data object AddEditServer : Screen("servers/edit?serverId={serverId}") {
        fun create(serverId: String? = null) = "servers/edit?serverId=${serverId ?: ""}"
    }
    data object FileBrowser : Screen("browser/{serverId}?path={path}") {
        fun create(serverId: String, path: String = "/") =
            "browser/$serverId?path=${Uri.encode(path)}"
    }
    data object Transfers : Screen("transfers")
    data object Settings : Screen("settings")
    data object ConnectionInfo : Screen("connection-info/{serverId}") {
        fun create(serverId: String) = "connection-info/$serverId"
    }
    data object Search : Screen("search/{serverId}?path={path}") {
        fun create(serverId: String, path: String) = "search/$serverId?path=${Uri.encode(path)}"
    }
    data object TextViewer : Screen("viewer/text/{serverId}?path={path}&local={local}") {
        fun create(serverId: String, path: String, isLocal: Boolean) =
            "viewer/text/$serverId?path=${Uri.encode(path)}&local=$isLocal"
    }
    data object ImageViewer : Screen("viewer/image/{serverId}?path={path}&local={local}") {
        fun create(serverId: String, path: String, isLocal: Boolean) =
            "viewer/image/$serverId?path=${Uri.encode(path)}&local=$isLocal"
    }
    data object PdfViewer : Screen("viewer/pdf/{serverId}?path={path}&local={local}") {
        fun create(serverId: String, path: String, isLocal: Boolean) =
            "viewer/pdf/$serverId?path=${Uri.encode(path)}&local=$isLocal"
    }
    data object TextEditor : Screen("editor/{serverId}?path={path}&local={local}") {
        fun create(serverId: String, path: String, isLocal: Boolean) =
            "editor/$serverId?path=${Uri.encode(path)}&local=$isLocal"
    }
    data object LocalPicker : Screen("local-picker?mode={mode}") {
        fun create(mode: String) = "local-picker?mode=$mode"
    }
}
