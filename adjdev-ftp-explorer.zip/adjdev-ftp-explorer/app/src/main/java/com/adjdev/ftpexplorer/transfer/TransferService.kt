package com.adjdev.ftpexplorer.transfer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.adjdev.ftpexplorer.MainActivity
import com.adjdev.ftpexplorer.R
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import javax.inject.Inject

/**
 * Foreground service whose sole job is to keep the process alive and show a summary
 * notification while [TransferManager] has active transfers. All transfer logic lives in
 * TransferManager itself so it keeps working even if this service is recreated.
 */
@AndroidEntryPoint
class TransferService : Service() {

    @Inject lateinit var transferManager: TransferManager

    private val job = Job()
    private val scope = CoroutineScope(Dispatchers.Main + job)

    companion object {
        const val CHANNEL_ID = "adjdev_transfers"
        const val NOTIFICATION_ID = 4201
    }

    override fun onCreate() {
        super.onCreate()
        createChannelIfNeeded()
        startForeground(NOTIFICATION_ID, buildNotification(0, 0))
        transferManager.transfers.onEach { list ->
            val active = list.count { it.state == TransferState.RUNNING || it.state == TransferState.QUEUED }
            val done = list.count { it.state == TransferState.COMPLETED }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.notify(NOTIFICATION_ID, buildNotification(active, done))
            if (active == 0 && list.none { it.state == TransferState.PAUSED }) {
                stopForeground(STOP_FOREGROUND_DETACH)
                stopSelf()
            }
        }.launchIn(scope)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        job.cancel()
        super.onDestroy()
    }

    private fun buildNotification(active: Int, done: Int): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = if (active > 0) "$active transfer(s) in progress" else "Transfers idle"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ADJDEV FTP Explorer")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_transfer_notification)
            .setOngoing(active > 0)
            .setContentIntent(openIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannelIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID, "File Transfers", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Upload and download progress" }
            manager?.createNotificationChannel(channel)
        }
    }
}
