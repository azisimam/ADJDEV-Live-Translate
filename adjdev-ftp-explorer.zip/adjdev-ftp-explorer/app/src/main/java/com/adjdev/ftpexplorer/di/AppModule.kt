package com.adjdev.ftpexplorer.di

import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/** Reserved for additional application-scoped bindings as the app grows. */
@Module
@InstallIn(SingletonComponent::class)
object AppModule
