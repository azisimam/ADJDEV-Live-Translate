package com.adjdev.ftpexplorer.ui.servers

import androidx.compose.material3.ExperimentalMaterial3Api

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.ExposedDropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.adjdev.ftpexplorer.data.remote.Protocol
import com.adjdev.ftpexplorer.data.remote.TlsMode

@Composable
fun AddEditServerScreen(
    onBack: () -> Unit,
    viewModel: AddEditServerViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    LaunchedEffect(state.saved) {
        if (state.saved) onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isEditing) "Edit Server" else "New Server") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = state.draft.name,
                onValueChange = { name -> viewModel.updateDraft { it.copy(name = name) } },
                label = { Text("Server name") },
                isError = state.nameError != null,
                supportingText = { state.nameError?.let { Text(it) } },
                modifier = Modifier.fillMaxWidth()
            )

            ProtocolDropdown(state.draft.protocol, onSelect = viewModel::onProtocolChange)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = state.draft.host,
                    onValueChange = { host -> viewModel.updateDraft { it.copy(host = host) } },
                    label = { Text("Host") },
                    isError = state.hostError != null,
                    supportingText = { state.hostError?.let { Text(it) } },
                    modifier = Modifier.weight(2f)
                )
                OutlinedTextField(
                    value = state.draft.port.toString(),
                    onValueChange = { p -> viewModel.updateDraft { it.copy(port = p.filter(Char::isDigit).toIntOrNull() ?: it.port) } },
                    label = { Text("Port") },
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            OutlinedTextField(
                value = state.draft.username,
                onValueChange = { u -> viewModel.updateDraft { it.copy(username = u) } },
                label = { Text("Username") },
                modifier = Modifier.fillMaxWidth()
            )

            var passwordVisible by remember { mutableStateOf(false) }
            OutlinedTextField(
                value = state.draft.password,
                onValueChange = { p -> viewModel.updateDraft { it.copy(password = p) } },
                label = { Text(if (state.isEditing) "Password (leave blank to keep current)" else "Password") },
                visualTransformation = if (passwordVisible) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    TextButton(onClick = { passwordVisible = !passwordVisible }) {
                        Text(if (passwordVisible) "Hide" else "Show")
                    }
                },
                modifier = Modifier.fillMaxWidth()
            )

            if (state.draft.protocol == Protocol.FTP || state.draft.protocol == Protocol.FTPS) {
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Checkbox(
                        checked = state.draft.passiveMode,
                        onCheckedChange = { v -> viewModel.updateDraft { it.copy(passiveMode = v) } }
                    )
                    Text("Passive mode")
                }
            }

            if (state.draft.protocol == Protocol.FTPS) {
                TlsModeDropdown(state.draft.tlsMode, onSelect = { mode -> viewModel.updateDraft { it.copy(tlsMode = mode) } })
            }

            OutlinedTextField(
                value = state.draft.defaultRemoteDir,
                onValueChange = { d -> viewModel.updateDraft { it.copy(defaultRemoteDir = d) } },
                label = { Text("Default remote directory") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = state.draft.timeoutSeconds.toString(),
                onValueChange = { t -> viewModel.updateDraft { it.copy(timeoutSeconds = t.filter(Char::isDigit).toIntOrNull() ?: it.timeoutSeconds) } },
                label = { Text("Connection timeout (seconds)") },
                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )

            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Checkbox(
                    checked = state.draft.isFavorite,
                    onCheckedChange = { v -> viewModel.updateDraft { it.copy(isFavorite = v) } }
                )
                Text("Mark as favorite")
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                OutlinedButton(onClick = viewModel::testConnection, enabled = state.testStatus != TestConnectionStatus.TESTING) {
                    Text("Test Connection")
                }
                when (state.testStatus) {
                    TestConnectionStatus.TESTING -> CircularProgressIndicator(modifier = Modifier.size(20.dp))
                    TestConnectionStatus.SUCCESS -> Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    TestConnectionStatus.FAILED -> Icon(Icons.Filled.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    TestConnectionStatus.IDLE -> {}
                }
            }
            state.testMessage?.let {
                Text(
                    it,
                    color = if (state.testStatus == TestConnectionStatus.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Button(onClick = viewModel::save, enabled = !state.isSaving, modifier = Modifier.fillMaxWidth()) {
                Text(if (state.isSaving) "Saving..." else "Save Server")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProtocolDropdown(selected: Protocol, onSelect: (Protocol) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selected.name,
            onValueChange = {},
            readOnly = true,
            label = { Text("Protocol") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            Protocol.entries.forEach { protocol ->
                DropdownMenuItem(text = { Text(protocol.name) }, onClick = { onSelect(protocol); expanded = false })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TlsModeDropdown(selected: TlsMode, onSelect: (TlsMode) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = selected.name,
            onValueChange = {},
            readOnly = true,
            label = { Text("TLS mode") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            TlsMode.entries.forEach { mode ->
                DropdownMenuItem(text = { Text(mode.name) }, onClick = { onSelect(mode); expanded = false })
            }
        }
    }
}
