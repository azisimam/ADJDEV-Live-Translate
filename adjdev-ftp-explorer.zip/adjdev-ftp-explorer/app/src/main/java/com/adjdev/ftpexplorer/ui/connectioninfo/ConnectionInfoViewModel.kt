package com.adjdev.ftpexplorer.ui.connectioninfo

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.remote.ConnectionInfo
import com.adjdev.ftpexplorer.data.remote.Protocol
import com.adjdev.ftpexplorer.data.repository.RemoteSessionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ConnectionInfoUiState(
    val info: ConnectionInfo? = null,
    val latencyMs: Long? = null,
    val rawCommand: String = "",
    val rawCommandResult: String? = null,
    val isMeasuringLatency: Boolean = false
)

@HiltViewModel
class ConnectionInfoViewModel @Inject constructor(
    private val sessionManager: RemoteSessionManager,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val serverId: String = checkNotNull(savedStateHandle["serverId"])

    private val _uiState = MutableStateFlow(ConnectionInfoUiState())
    val uiState: StateFlow<ConnectionInfoUiState> = _uiState.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            val info = sessionManager.getConnectionInfo(serverId)
            _uiState.update { it.copy(info = info) }
        }
    }

    fun measureLatency() {
        viewModelScope.launch {
            _uiState.update { it.copy(isMeasuringLatency = true) }
            val fs = sessionManager.activeSession(serverId)
            val latency = if (fs != null) {
                val start = System.currentTimeMillis()
                fs.exists("/")
                System.currentTimeMillis() - start
            } else null
            _uiState.update { it.copy(isMeasuringLatency = false, latencyMs = latency) }
        }
    }

    fun reconnect() {
        viewModelScope.launch {
            sessionManager.reconnect(serverId)
            refresh()
        }
    }

    fun onRawCommandChange(value: String) = _uiState.update { it.copy(rawCommand = value) }

    fun sendRawCommand() {
        viewModelScope.launch {
            val fs = sessionManager.activeSession(serverId) ?: return@launch
            val result = fs.sendRawCommand(_uiState.value.rawCommand)
            _uiState.update {
                it.copy(rawCommandResult = result.getOrNull() ?: result.exceptionOrNull()?.message ?: "No response")
            }
            refresh()
        }
    }

    fun supportsRawCommand(): Boolean = _uiState.value.info?.protocol != Protocol.SFTP
}
