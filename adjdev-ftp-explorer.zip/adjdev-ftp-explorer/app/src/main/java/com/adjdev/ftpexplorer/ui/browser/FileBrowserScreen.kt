package com.adjdev.ftpexplorer.ui.browser

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.SignalWifiStatusbarConnectedNoInternet4
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WifiTethering
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.adjdev.ftpexplorer.data.remote.RemoteFile
import com.adjdev.ftpexplorer.ui.common.BreadcrumbBar
import com.adjdev.ftpexplorer.ui.common.ConfirmDialog
import com.adjdev.ftpexplorer.ui.common.EmptyState
import com.adjdev.ftpexplorer.ui.common.ErrorBanner
import com.adjdev.ftpexplorer.ui.common.LoadingBox

private fun isViewableText(file: RemoteFile) = !file.isDirectory && file.extension.lowercase() in setOf(
    "txt", "md", "json", "xml", "html", "htm", "css", "js", "kt", "java", "py", "c", "cpp", "h", "log", "ini", "conf", "yml", "yaml", "gradle", "sh"
)

private fun isViewableImage(file: RemoteFile) = !file.isDirectory && file.extension.lowercase() in setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")
private fun isViewablePdf(file: RemoteFile) = !file.isDirectory && file.extension.lowercase() == "pdf"

@Composable
fun FileBrowserScreen(
    onBack: () -> Unit,
    onOpenTextViewer: (String) -> Unit,
    onOpenImageViewer: (String) -> Unit,
    onOpenPdfViewer: (String) -> Unit,
    onOpenTextEditor: (String) -> Unit,
    onOpenSearch: (String) -> Unit,
    onOpenConnectionInfo: () -> Unit,
    onPickUploadFiles: (onPicked: (List<java.io.File>) -> Unit) -> Unit,
    onPickDownloadFolder: (onPicked: (java.io.File) -> Unit) -> Unit,
    viewModel: FileBrowserViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var topMenuExpanded by remember { mutableStateOf(false) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var contextFile by remember { mutableStateOf<RemoteFile?>(null) }
    var propertiesFile by remember { mutableStateOf<RemoteFile?>(null) }
    var renameTarget by remember { mutableStateOf<RemoteFile?>(null) }
    var deleteTarget by remember { mutableStateOf<RemoteFile?>(null) }
    var showCreateFolder by remember { mutableStateOf(false) }
    var showCreateFile by remember { mutableStateOf(false) }
    var showBookmarkDialog by remember { mutableStateOf(false) }
    var showDeleteSelected by remember { mutableStateOf(false) }

    fun openFile(file: RemoteFile) {
        when {
            isViewableImage(file) -> onOpenImageViewer(file.path)
            isViewablePdf(file) -> onOpenPdfViewer(file.path)
            isViewableText(file) -> onOpenTextViewer(file.path)
            else -> onPickDownloadFolder { dir -> viewModel.downloadFile(file, dir) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.server?.name ?: "File Browser") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
                actions = {
                    if (state.isSelectionMode) {
                        IconButton(onClick = { onPickDownloadFolder { dir -> viewModel.downloadSelected(dir) } }) {
                            Icon(Icons.Filled.Download, contentDescription = "Download selected")
                        }
                        IconButton(onClick = { viewModel.copySelectedToClipboard(isCut = false) }) {
                            Icon(Icons.Filled.ContentCopy, contentDescription = "Copy")
                        }
                        IconButton(onClick = { viewModel.copySelectedToClipboard(isCut = true) }) {
                            Icon(Icons.Filled.ContentCut, contentDescription = "Cut")
                        }
                        IconButton(onClick = { showDeleteSelected = true }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete")
                        }
                        IconButton(onClick = viewModel::clearSelection) {
                            Icon(Icons.Filled.Close, contentDescription = "Clear selection")
                        }
                    } else {
                        IconButton(onClick = { onOpenSearch(state.currentPath) }) { Icon(Icons.Filled.Search, contentDescription = "Search") }
                        if (state.clipboard != null) {
                            IconButton(onClick = viewModel::pasteClipboard) { Icon(Icons.Filled.ContentPaste, contentDescription = "Paste") }
                        }
                        IconButton(onClick = viewModel::refresh) { Icon(Icons.Filled.Refresh, contentDescription = "Refresh") }
                        Box {
                            IconButton(onClick = { topMenuExpanded = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "More") }
                            DropdownMenu(expanded = topMenuExpanded, onDismissRequest = { topMenuExpanded = false }) {
                                DropdownMenuItem(text = { Text("Sort by") }, leadingIcon = { Icon(Icons.Filled.SwapVert, null) }, onClick = { topMenuExpanded = false; sortMenuExpanded = true })
                                DropdownMenuItem(
                                    text = { Text(if (state.showHidden) "Hide hidden files" else "Show hidden files") },
                                    leadingIcon = { Icon(Icons.Filled.VisibilityOff, null) },
                                    onClick = { topMenuExpanded = false; viewModel.toggleShowHidden() }
                                )
                                DropdownMenuItem(text = { Text("Select all") }, leadingIcon = { Icon(Icons.Filled.SelectAll, null) }, onClick = { topMenuExpanded = false; viewModel.selectAll() })
                                DropdownMenuItem(
                                    text = { Text("Connection info") },
                                    leadingIcon = { Icon(Icons.Filled.WifiTethering, null) },
                                    onClick = { topMenuExpanded = false; onOpenConnectionInfo() }
                                )
                                DropdownMenuItem(text = { Text("Bookmark this folder") }, leadingIcon = { Icon(Icons.Filled.Info, null) }, onClick = { topMenuExpanded = false; showBookmarkDialog = true })
                            }
                            DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                                SortMode.entries.forEach { mode ->
                                    DropdownMenuItem(text = { Text(mode.name) }, onClick = { viewModel.setSortMode(mode); sortMenuExpanded = false })
                                }
                            }
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            if (!state.isSelectionMode) {
                Box {
                    var fabMenuExpanded by remember { mutableStateOf(false) }
                    FloatingActionButton(onClick = { fabMenuExpanded = true }) { Icon(Icons.Filled.UploadFile, contentDescription = "Add") }
                    DropdownMenu(expanded = fabMenuExpanded, onDismissRequest = { fabMenuExpanded = false }) {
                        DropdownMenuItem(
                            text = { Text("Upload files") },
                            leadingIcon = { Icon(Icons.Filled.UploadFile, null) },
                            onClick = { fabMenuExpanded = false; onPickUploadFiles { files -> viewModel.uploadFiles(files) } }
                        )
                        DropdownMenuItem(
                            text = { Text("New folder") },
                            leadingIcon = { Icon(Icons.Filled.CreateNewFolder, null) },
                            onClick = { fabMenuExpanded = false; showCreateFolder = true }
                        )
                        DropdownMenuItem(
                            text = { Text("New file") },
                            leadingIcon = { Icon(Icons.Filled.NoteAdd, null) },
                            onClick = { fabMenuExpanded = false; showCreateFile = true }
                        )
                    }
                }
            }
        }
    ) { padding ->
        androidx.compose.foundation.layout.Column(modifier = Modifier
            .padding(padding)
            .fillMaxSize()) {
            BreadcrumbBar(path = state.currentPath, onNavigate = viewModel::navigateToBreadcrumb)

            when {
                state.isConnecting -> LoadingBox(modifier = Modifier.fillMaxSize())
                state.error != null && state.files.isEmpty() -> {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.SignalWifiStatusbarConnectedNoInternet4, contentDescription = null, modifier = Modifier.padding(bottom = 8.dp))
                            Text(state.error ?: "Connection error", color = MaterialTheme.colorScheme.error)
                            Button(onClick = viewModel::reconnect, modifier = Modifier.padding(top = 12.dp)) { Text("Reconnect") }
                        }
                    }
                }
                state.isLoading -> LoadingBox(modifier = Modifier.fillMaxSize())
                state.files.isEmpty() -> EmptyState(title = "This folder is empty", modifier = Modifier.fillMaxSize())
                else -> {
                    if (state.error != null) ErrorBanner(state.error!!)
                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(state.files, key = { it.path }) { file ->
                            FileListItem(
                                file = file,
                                isSelected = state.selectedPaths.contains(file.path),
                                isSelectionMode = state.isSelectionMode,
                                onClick = {
                                    if (state.isSelectionMode) {
                                        viewModel.toggleSelection(file)
                                    } else if (file.isDirectory) {
                                        viewModel.navigateInto(file)
                                    } else {
                                        openFile(file)
                                    }
                                },
                                onLongClick = { if (!state.isSelectionMode) contextFile = file else viewModel.toggleSelection(file) }
                            )
                        }
                    }
                }
            }
        }
    }

    contextFile?.let { file ->
        FileContextSheet(
            file = file,
            onDismiss = { contextFile = null },
            onOpen = { if (file.isDirectory) viewModel.navigateInto(file) else openFile(file) },
            onRename = { renameTarget = file },
            onDelete = { deleteTarget = file },
            onCopy = { viewModel.toggleSelection(file); viewModel.copySelectedToClipboard(isCut = false) },
            onCut = { viewModel.toggleSelection(file); viewModel.copySelectedToClipboard(isCut = true) },
            onDownload = { onPickDownloadFolder { dir -> viewModel.downloadFile(file, dir) } },
            onBookmark = { showBookmarkDialog = true },
            onProperties = { propertiesFile = file }
        )
    }

    propertiesFile?.let { FilePropertiesDialog(it, onDismiss = { propertiesFile = null }) }

    renameTarget?.let { file ->
        TextInputDialog(
            title = "Rename",
            initialValue = file.name,
            confirmLabel = "Rename",
            onConfirm = { newName -> viewModel.renameFile(file, newName); renameTarget = null },
            onDismiss = { renameTarget = null }
        )
    }

    deleteTarget?.let { file ->
        ConfirmDialog(
            title = "Delete ${if (file.isDirectory) "folder" else "file"}?",
            message = "\"${file.name}\" will be permanently deleted.",
            confirmLabel = "Delete",
            onConfirm = { viewModel.deleteFile(file); deleteTarget = null },
            onDismiss = { deleteTarget = null }
        )
    }

    if (showDeleteSelected) {
        ConfirmDialog(
            title = "Delete ${state.selectedPaths.size} item(s)?",
            message = "This cannot be undone.",
            confirmLabel = "Delete",
            onConfirm = { viewModel.deleteSelected(); showDeleteSelected = false },
            onDismiss = { showDeleteSelected = false }
        )
    }

    if (showCreateFolder) {
        TextInputDialog(
            title = "New folder",
            confirmLabel = "Create",
            onConfirm = { name -> viewModel.createFolder(name); showCreateFolder = false },
            onDismiss = { showCreateFolder = false }
        )
    }

    if (showCreateFile) {
        TextInputDialog(
            title = "New file",
            confirmLabel = "Create",
            onConfirm = { name -> viewModel.createFile(name); showCreateFile = false },
            onDismiss = { showCreateFile = false }
        )
    }

    if (showBookmarkDialog) {
        TextInputDialog(
            title = "Bookmark folder",
            initialValue = state.currentPath.substringAfterLast('/').ifEmpty { "Root" },
            label = "Bookmark name",
            confirmLabel = "Save",
            onConfirm = { label -> viewModel.addBookmark(label); showBookmarkDialog = false },
            onDismiss = { showBookmarkDialog = false }
        )
    }
}
