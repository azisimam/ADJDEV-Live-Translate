package com.adjdev.ftpexplorer.data.remote

import javax.inject.Inject
import javax.inject.Singleton

/** Creates a fresh [RemoteFileSystem] instance for the given protocol. Each connected server
 * session owns its own instance so multiple servers can be browsed/transferred concurrently. */
@Singleton
class RemoteFileSystemFactory @Inject constructor() {
    fun create(protocol: Protocol): RemoteFileSystem = when (protocol) {
        Protocol.FTP, Protocol.FTPS -> FtpFileSystem()
        Protocol.SFTP -> SftpFileSystem()
    }
}
