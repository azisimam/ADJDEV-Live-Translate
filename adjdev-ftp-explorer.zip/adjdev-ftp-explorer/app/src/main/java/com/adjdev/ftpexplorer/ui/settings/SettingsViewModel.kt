package com.adjdev.ftpexplorer.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.repository.AppSettings
import com.adjdev.ftpexplorer.data.repository.AppTheme
import com.adjdev.ftpexplorer.data.repository.SettingsRepository
import com.adjdev.ftpexplorer.data.repository.TransferHistoryRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val transferHistoryRepository: TransferHistoryRepository
) : ViewModel() {

    val settings: StateFlow<AppSettings> = settingsRepository.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    fun setTheme(theme: AppTheme) = viewModelScope.launch { settingsRepository.setTheme(theme) }
    fun setOverwriteOnUpload(v: Boolean) = viewModelScope.launch { settingsRepository.setOverwriteOnUpload(v) }
    fun setTransferConcurrency(v: Int) = viewModelScope.launch { settingsRepository.setTransferConcurrency(v) }
    fun setAutoRetry(v: Boolean) = viewModelScope.launch { settingsRepository.setAutoRetry(v) }
    fun setMaxRetryCount(v: Int) = viewModelScope.launch { settingsRepository.setMaxRetryCount(v) }
    fun setDefaultTimeout(v: Int) = viewModelScope.launch { settingsRepository.setDefaultTimeout(v) }
    fun setShowHiddenFiles(v: Boolean) = viewModelScope.launch { settingsRepository.setShowHiddenFiles(v) }
    fun setConfirmBeforeDelete(v: Boolean) = viewModelScope.launch { settingsRepository.setConfirmBeforeDelete(v) }
    fun setTransferNotifications(v: Boolean) = viewModelScope.launch { settingsRepository.setTransferNotifications(v) }
    fun clearTransferHistory() = viewModelScope.launch { transferHistoryRepository.clear() }
}
