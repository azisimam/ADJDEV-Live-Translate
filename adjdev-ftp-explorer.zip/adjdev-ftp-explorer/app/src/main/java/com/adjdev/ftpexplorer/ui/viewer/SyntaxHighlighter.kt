package com.adjdev.ftpexplorer.ui.viewer

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle

private val KEYWORDS = setOf(
    "fun", "val", "var", "class", "object", "interface", "if", "else", "when", "for", "while",
    "return", "import", "package", "public", "private", "protected", "override", "suspend",
    "def", "function", "const", "let", "public", "static", "void", "int", "String", "true", "false", "null",
    "try", "catch", "finally", "throw", "new", "extends", "implements"
)

private val keywordColor = Color(0xFF9C27B0)
private val stringColor = Color(0xFF2E7D32)
private val commentColor = Color(0xFF757575)
private val numberColor = Color(0xFF1565C0)

/**
 * Minimal, dependency-free syntax highlighter: colors keywords, string literals, comments and
 * numbers via regex tokenization. Not a full language grammar, but gives useful visual structure
 * for common code/text formats without pulling in a heavyweight highlighting library.
 */
fun highlightSyntax(code: String, extension: String): AnnotatedString {
    if (extension.lowercase() !in setOf("kt", "java", "js", "ts", "py", "c", "cpp", "h", "json", "xml", "html", "css", "gradle", "sh")) {
        return AnnotatedString(code)
    }
    return buildAnnotatedString {
        var i = 0
        val len = code.length
        while (i < len) {
            val c = code[i]
            when {
                c == '"' -> {
                    val start = i
                    i++
                    while (i < len && code[i] != '"') i++
                    if (i < len) i++
                    withStyle(SpanStyle(color = stringColor)) { append(code.substring(start, i)) }
                }
                c == '/' && i + 1 < len && code[i + 1] == '/' -> {
                    val start = i
                    while (i < len && code[i] != '\n') i++
                    withStyle(SpanStyle(color = commentColor)) { append(code.substring(start, i)) }
                }
                c == '#' -> {
                    val start = i
                    while (i < len && code[i] != '\n') i++
                    withStyle(SpanStyle(color = commentColor)) { append(code.substring(start, i)) }
                }
                c.isDigit() -> {
                    val start = i
                    while (i < len && (code[i].isDigit() || code[i] == '.')) i++
                    withStyle(SpanStyle(color = numberColor)) { append(code.substring(start, i)) }
                }
                c.isLetter() || c == '_' -> {
                    val start = i
                    while (i < len && (code[i].isLetterOrDigit() || code[i] == '_')) i++
                    val word = code.substring(start, i)
                    if (word in KEYWORDS) {
                        withStyle(SpanStyle(color = keywordColor, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)) { append(word) }
                    } else {
                        append(word)
                    }
                }
                else -> {
                    append(c)
                    i++
                }
            }
        }
    }
}
