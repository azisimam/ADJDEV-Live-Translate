package com.adjdev.ftpexplorer.data.local

import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/** Simple local file browser used for picking upload sources and download destinations. */
@Singleton
class LocalFileSystem @Inject constructor() {

    fun rootPath(): String = Environment.getExternalStorageDirectory().absolutePath

    fun defaultDownloadDir(): File {
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ADJDEV-FTP-Explorer")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    suspend fun list(path: String): Result<List<LocalFile>> = withContext(Dispatchers.IO) {
        try {
            val dir = File(path)
            val children = dir.listFiles() ?: emptyArray()
            val result = children
                .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                .map {
                    LocalFile(
                        name = it.name,
                        path = it.absolutePath,
                        isDirectory = it.isDirectory,
                        size = if (it.isFile) it.length() else 0L,
                        lastModified = it.lastModified()
                    )
                }
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createDirectory(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val ok = File(path).mkdirs()
            if (ok) Result.success(Unit) else Result.failure(java.io.IOException("Could not create directory"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun delete(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            File(path).deleteRecursively()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
