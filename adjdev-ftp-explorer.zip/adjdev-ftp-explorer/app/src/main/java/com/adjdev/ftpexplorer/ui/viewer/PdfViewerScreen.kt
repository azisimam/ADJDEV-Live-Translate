package com.adjdev.ftpexplorer.ui.viewer

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.adjdev.ftpexplorer.ui.common.ErrorBanner
import com.adjdev.ftpexplorer.ui.common.LoadingBox
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PdfViewerScreen(
    onBack: () -> Unit,
    viewModel: ViewerViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var pages by remember { mutableStateOf<List<Bitmap>>(emptyList()) }
    var renderError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(state.localFile) {
        val file = state.localFile ?: return@LaunchedEffect
        withContext(Dispatchers.IO) {
            try {
                val rendered = renderPdfPages(file)
                pages = rendered
            } catch (e: Exception) {
                renderError = e.message ?: "Could not render PDF"
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.fileName) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } }
            )
        }
    ) { padding ->
        when {
            state.isLoading -> LoadingBox(modifier = Modifier
                .padding(padding)
                .fillMaxSize())
            state.error != null -> ErrorBanner(state.error!!, modifier = Modifier.padding(padding))
            renderError != null -> ErrorBanner(renderError!!, modifier = Modifier.padding(padding))
            pages.isEmpty() -> LoadingBox(modifier = Modifier
                .padding(padding)
                .fillMaxSize())
            else -> LazyColumn(modifier = Modifier
                .padding(padding)
                .fillMaxSize()) {
                items(pages) { bitmap ->
                    Column(modifier = Modifier.padding(8.dp)) {
                        Image(bitmap = bitmap.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxWidth())
                    }
                }
            }
        }
    }
}

private fun renderPdfPages(file: File): List<Bitmap> {
    val bitmaps = mutableListOf<Bitmap>()
    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY).use { pfd ->
        PdfRenderer(pfd).use { renderer ->
            for (i in 0 until renderer.pageCount) {
                renderer.openPage(i).use { page ->
                    val bitmap = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmaps.add(bitmap)
                }
            }
        }
    }
    return bitmaps
}
