package com.adjdev.ftpexplorer.ui.browser

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.db.BookmarkEntity
import com.adjdev.ftpexplorer.data.remote.RemoteFile
import com.adjdev.ftpexplorer.data.repository.BookmarkRepository
import com.adjdev.ftpexplorer.data.repository.RemoteSessionManager
import com.adjdev.ftpexplorer.data.repository.Server
import com.adjdev.ftpexplorer.data.repository.ServerRepository
import com.adjdev.ftpexplorer.data.repository.SettingsRepository
import com.adjdev.ftpexplorer.transfer.TransferManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

enum class SortMode { NAME, SIZE, DATE, TYPE }

data class FileBrowserUiState(
    val server: Server? = null,
    val currentPath: String = "/",
    val files: List<RemoteFile> = emptyList(),
    val isLoading: Boolean = true,
    val isConnecting: Boolean = false,
    val error: String? = null,
    val selectedPaths: Set<String> = emptySet(),
    val sortMode: SortMode = SortMode.NAME,
    val sortAscending: Boolean = true,
    val showHidden: Boolean = false,
    val clipboard: ClipboardOp? = null,
    val bookmarks: List<BookmarkEntity> = emptyList()
) {
    val isSelectionMode: Boolean get() = selectedPaths.isNotEmpty()
}

data class ClipboardOp(val paths: List<RemoteFile>, val isCut: Boolean)

@HiltViewModel
class FileBrowserViewModel @Inject constructor(
    private val serverRepository: ServerRepository,
    private val sessionManager: RemoteSessionManager,
    private val transferManager: TransferManager,
    private val settingsRepository: SettingsRepository,
    private val bookmarkRepository: BookmarkRepository,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val serverId: String = checkNotNull(savedStateHandle["serverId"])
    private val startPath: String = savedStateHandle.get<String>("path")?.takeIf { it.isNotBlank() } ?: "/"

    private val _uiState = MutableStateFlow(FileBrowserUiState(currentPath = startPath))
    val uiState: StateFlow<FileBrowserUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val server = serverRepository.getServer(serverId)
            val hidden = settingsRepository.settings.first().showHiddenFiles
            _uiState.update { it.copy(server = server, showHidden = hidden) }
            connectAndLoad(startPath)
        }
        viewModelScope.launch {
            bookmarkRepository.observeForServer(serverId).collect { bookmarks ->
                _uiState.update { it.copy(bookmarks = bookmarks) }
            }
        }
    }

    private suspend fun connectAndLoad(path: String) {
        _uiState.update { it.copy(isConnecting = true, error = null) }
        val result = sessionManager.getOrConnect(serverId)
        if (result.isFailure) {
            _uiState.update {
                it.copy(isConnecting = false, isLoading = false, error = result.exceptionOrNull()?.message ?: "Connection failed")
            }
            return
        }
        _uiState.update { it.copy(isConnecting = false) }
        loadDirectory(path)
    }

    fun loadDirectory(path: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null, currentPath = path, selectedPaths = emptySet()) }
            val fs = sessionManager.activeSession(serverId)
            if (fs == null) {
                connectAndLoad(path)
                return@launch
            }
            val result = fs.listFiles(path)
            result.fold(
                onSuccess = { files -> _uiState.update { it.copy(files = sortFiles(files, it), isLoading = false) } },
                onFailure = { e -> _uiState.update { it.copy(isLoading = false, error = e.message ?: "Failed to list directory") } }
            )
        }
    }

    fun refresh() = loadDirectory(_uiState.value.currentPath)

    fun navigateInto(file: RemoteFile) {
        if (file.isDirectory) loadDirectory(file.path)
    }

    fun navigateToBreadcrumb(path: String) = loadDirectory(path)

    fun reconnect() {
        viewModelScope.launch {
            _uiState.update { it.copy(isConnecting = true, error = null) }
            val result = sessionManager.reconnect(serverId)
            _uiState.update { it.copy(isConnecting = false) }
            if (result.isSuccess) loadDirectory(_uiState.value.currentPath)
            else _uiState.update { it.copy(error = result.exceptionOrNull()?.message ?: "Reconnect failed") }
        }
    }

    fun setSortMode(mode: SortMode) {
        _uiState.update { it.copy(sortMode = mode, files = sortFiles(it.files, it.copy(sortMode = mode))) }
    }

    fun toggleSortDirection() {
        _uiState.update {
            val newState = it.copy(sortAscending = !it.sortAscending)
            newState.copy(files = sortFiles(it.files, newState))
        }
    }

    fun toggleShowHidden() {
        viewModelScope.launch {
            val newValue = !_uiState.value.showHidden
            settingsRepository.setShowHiddenFiles(newValue)
            _uiState.update { it.copy(showHidden = newValue) }
        }
    }

    private fun sortFiles(files: List<RemoteFile>, state: FileBrowserUiState): List<RemoteFile> {
        val visible = if (state.showHidden) files else files.filterNot { it.name.startsWith(".") }
        val comparator: Comparator<RemoteFile> = when (state.sortMode) {
            SortMode.NAME -> compareBy { it.name.lowercase() }
            SortMode.SIZE -> compareBy { it.size }
            SortMode.DATE -> compareBy { it.lastModified }
            SortMode.TYPE -> compareBy { it.extension.lowercase() }
        }
        val dirsFirst = visible.sortedWith(compareBy<RemoteFile> { !it.isDirectory }.then(comparator))
        return if (state.sortAscending) dirsFirst else dirsFirst.reversed().sortedBy { !it.isDirectory }
    }

    fun toggleSelection(file: RemoteFile) {
        _uiState.update {
            val current = it.selectedPaths
            val next = if (current.contains(file.path)) current - file.path else current + file.path
            it.copy(selectedPaths = next)
        }
    }

    fun clearSelection() = _uiState.update { it.copy(selectedPaths = emptySet()) }

    fun selectAll() = _uiState.update { it.copy(selectedPaths = it.files.map { f -> f.path }.toSet()) }

    fun createFolder(name: String) {
        viewModelScope.launch {
            val fs = sessionManager.activeSession(serverId) ?: return@launch
            val path = joinPath(_uiState.value.currentPath, name)
            val result = fs.createDirectory(path)
            if (result.isFailure) {
                _uiState.update { it.copy(error = result.exceptionOrNull()?.message ?: "Could not create folder") }
            } else {
                refresh()
            }
        }
    }

    fun createFile(name: String) {
        viewModelScope.launch {
            val fs = sessionManager.activeSession(serverId) ?: return@launch
            val path = joinPath(_uiState.value.currentPath, name)
            val result = fs.createFile(path)
            if (result.isFailure) {
                _uiState.update { it.copy(error = result.exceptionOrNull()?.message ?: "Could not create file") }
            } else {
                refresh()
            }
        }
    }

    fun renameFile(file: RemoteFile, newName: String) {
        viewModelScope.launch {
            val fs = sessionManager.activeSession(serverId) ?: return@launch
            val result = fs.rename(file.path, newName)
            if (result.isFailure) {
                _uiState.update { it.copy(error = result.exceptionOrNull()?.message ?: "Rename failed") }
            } else {
                refresh()
            }
        }
    }

    fun deleteSelected() {
        viewModelScope.launch {
            val fs = sessionManager.activeSession(serverId) ?: return@launch
            val targets = _uiState.value.files.filter { _uiState.value.selectedPaths.contains(it.path) }
            for (file in targets) {
                fs.delete(file.path, file.isDirectory)
            }
            clearSelection()
            refresh()
        }
    }

    fun deleteFile(file: RemoteFile) {
        viewModelScope.launch {
            val fs = sessionManager.activeSession(serverId) ?: return@launch
            val result = fs.delete(file.path, file.isDirectory)
            if (result.isFailure) {
                _uiState.update { it.copy(error = result.exceptionOrNull()?.message ?: "Delete failed") }
            } else {
                refresh()
            }
        }
    }

    fun copySelectedToClipboard(isCut: Boolean) {
        val targets = _uiState.value.files.filter { _uiState.value.selectedPaths.contains(it.path) }
        _uiState.update { it.copy(clipboard = ClipboardOp(targets, isCut), selectedPaths = emptySet()) }
    }

    fun pasteClipboard() {
        val clipboard = _uiState.value.clipboard ?: return
        viewModelScope.launch {
            val fs = sessionManager.activeSession(serverId) ?: return@launch
            for (file in clipboard.paths) {
                val destination = joinPath(_uiState.value.currentPath, file.name)
                if (clipboard.isCut) {
                    fs.move(file.path, destination)
                } else {
                    fs.copy(file.path, destination, file.isDirectory)
                }
            }
            _uiState.update { it.copy(clipboard = null) }
            refresh()
        }
    }

    fun addBookmark(label: String) {
        viewModelScope.launch { bookmarkRepository.addBookmark(serverId, _uiState.value.currentPath, label) }
    }

    fun removeBookmark(bookmark: BookmarkEntity) {
        viewModelScope.launch { bookmarkRepository.removeBookmark(bookmark) }
    }

    fun downloadSelected(destinationDir: File) {
        val server = _uiState.value.server ?: return
        val targets = _uiState.value.files.filter { _uiState.value.selectedPaths.contains(it.path) && !it.isDirectory }
        for (file in targets) {
            transferManager.enqueueDownload(serverId, server.name, file.path, file.name, destinationDir, file.size)
        }
        clearSelection()
    }

    fun downloadFile(file: RemoteFile, destinationDir: File) {
        val server = _uiState.value.server ?: return
        transferManager.enqueueDownload(serverId, server.name, file.path, file.name, destinationDir, file.size)
    }

    fun uploadFiles(localFiles: List<File>) {
        val server = _uiState.value.server ?: return
        for (local in localFiles) {
            transferManager.enqueueUpload(serverId, server.name, local, _uiState.value.currentPath)
        }
    }

    fun consumeError() = _uiState.update { it.copy(error = null) }

    private fun joinPath(base: String, name: String): String {
        val b = base.trimEnd('/')
        return if (b.isEmpty()) "/$name" else "$b/$name"
    }

    override fun onCleared() {
        super.onCleared()
        // Session intentionally kept alive in RemoteSessionManager so transfers/other screens
        // for the same server can keep using it after this ViewModel is destroyed.
    }
}
