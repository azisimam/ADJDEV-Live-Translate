package com.adjdev.ftpexplorer.data.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "adjdev_settings")

enum class AppTheme { SYSTEM, LIGHT, DARK }

data class AppSettings(
    val theme: AppTheme = AppTheme.SYSTEM,
    val defaultDownloadFolder: String = "",
    val overwriteOnUpload: Boolean = false,
    val transferConcurrency: Int = 2,
    val autoRetry: Boolean = true,
    val maxRetryCount: Int = 3,
    val defaultTimeoutSeconds: Int = 30,
    val showHiddenFiles: Boolean = false,
    val confirmBeforeDelete: Boolean = true,
    val transferNotificationsEnabled: Boolean = true,
    val cacheLimitMb: Int = 256
)

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme")
        val DOWNLOAD_FOLDER = stringPreferencesKey("default_download_folder")
        val OVERWRITE_UPLOAD = booleanPreferencesKey("overwrite_on_upload")
        val CONCURRENCY = intPreferencesKey("transfer_concurrency")
        val AUTO_RETRY = booleanPreferencesKey("auto_retry")
        val MAX_RETRY = intPreferencesKey("max_retry_count")
        val TIMEOUT = intPreferencesKey("default_timeout_seconds")
        val HIDDEN_FILES = booleanPreferencesKey("show_hidden_files")
        val CONFIRM_DELETE = booleanPreferencesKey("confirm_before_delete")
        val NOTIFICATIONS = booleanPreferencesKey("transfer_notifications_enabled")
        val CACHE_LIMIT = intPreferencesKey("cache_limit_mb")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            theme = prefs[Keys.THEME]?.let { runCatching { AppTheme.valueOf(it) }.getOrNull() } ?: AppTheme.SYSTEM,
            defaultDownloadFolder = prefs[Keys.DOWNLOAD_FOLDER] ?: "",
            overwriteOnUpload = prefs[Keys.OVERWRITE_UPLOAD] ?: false,
            transferConcurrency = prefs[Keys.CONCURRENCY] ?: 2,
            autoRetry = prefs[Keys.AUTO_RETRY] ?: true,
            maxRetryCount = prefs[Keys.MAX_RETRY] ?: 3,
            defaultTimeoutSeconds = prefs[Keys.TIMEOUT] ?: 30,
            showHiddenFiles = prefs[Keys.HIDDEN_FILES] ?: false,
            confirmBeforeDelete = prefs[Keys.CONFIRM_DELETE] ?: true,
            transferNotificationsEnabled = prefs[Keys.NOTIFICATIONS] ?: true,
            cacheLimitMb = prefs[Keys.CACHE_LIMIT] ?: 256
        )
    }

    suspend fun setTheme(theme: AppTheme) = context.dataStore.edit { it[Keys.THEME] = theme.name }
    suspend fun setDefaultDownloadFolder(path: String) = context.dataStore.edit { it[Keys.DOWNLOAD_FOLDER] = path }
    suspend fun setOverwriteOnUpload(value: Boolean) = context.dataStore.edit { it[Keys.OVERWRITE_UPLOAD] = value }
    suspend fun setTransferConcurrency(value: Int) = context.dataStore.edit { it[Keys.CONCURRENCY] = value }
    suspend fun setAutoRetry(value: Boolean) = context.dataStore.edit { it[Keys.AUTO_RETRY] = value }
    suspend fun setMaxRetryCount(value: Int) = context.dataStore.edit { it[Keys.MAX_RETRY] = value }
    suspend fun setDefaultTimeout(value: Int) = context.dataStore.edit { it[Keys.TIMEOUT] = value }
    suspend fun setShowHiddenFiles(value: Boolean) = context.dataStore.edit { it[Keys.HIDDEN_FILES] = value }
    suspend fun setConfirmBeforeDelete(value: Boolean) = context.dataStore.edit { it[Keys.CONFIRM_DELETE] = value }
    suspend fun setTransferNotifications(value: Boolean) = context.dataStore.edit { it[Keys.NOTIFICATIONS] = value }
    suspend fun setCacheLimitMb(value: Int) = context.dataStore.edit { it[Keys.CACHE_LIMIT] = value }
}
