package com.adjdev.ftpexplorer.ui.browser

import androidx.compose.material3.ExperimentalMaterial3Api

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.adjdev.ftpexplorer.data.remote.RemoteFile
import com.adjdev.ftpexplorer.ui.common.formatBytes
import com.adjdev.ftpexplorer.ui.common.formatDate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileContextSheet(
    file: RemoteFile,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onDownload: () -> Unit,
    onBookmark: () -> Unit,
    onProperties: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(bottom = 24.dp)) {
            Text(file.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            Divider()
            ListItem(headlineContent = { Text("Open") }, leadingContent = { Icon(Icons.Filled.OpenInNew, null) }, modifier = Modifier.clickableRow { onOpen(); onDismiss() })
            if (!file.isDirectory) {
                ListItem(headlineContent = { Text("Download") }, leadingContent = { Icon(Icons.Filled.Download, null) }, modifier = Modifier.clickableRow { onDownload(); onDismiss() })
            }
            ListItem(headlineContent = { Text("Rename") }, leadingContent = { Icon(Icons.Filled.DriveFileRenameOutline, null) }, modifier = Modifier.clickableRow { onRename(); onDismiss() })
            ListItem(headlineContent = { Text("Copy") }, leadingContent = { Icon(Icons.Filled.ContentCopy, null) }, modifier = Modifier.clickableRow { onCopy(); onDismiss() })
            ListItem(headlineContent = { Text("Cut") }, leadingContent = { Icon(Icons.Filled.ContentCut, null) }, modifier = Modifier.clickableRow { onCut(); onDismiss() })
            if (file.isDirectory) {
                ListItem(headlineContent = { Text("Bookmark") }, leadingContent = { Icon(Icons.Filled.Bookmark, null) }, modifier = Modifier.clickableRow { onBookmark(); onDismiss() })
            }
            ListItem(headlineContent = { Text("Properties") }, leadingContent = { Icon(Icons.Filled.Info, null) }, modifier = Modifier.clickableRow { onProperties(); onDismiss() })
            ListItem(
                headlineContent = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                leadingContent = { Icon(Icons.Filled.Delete, null, tint = MaterialTheme.colorScheme.error) },
                modifier = Modifier.clickableRow { onDelete(); onDismiss() }
            )
        }
    }
}

private fun Modifier.clickableRow(onClick: () -> Unit): Modifier =
    this.clickable(onClick = onClick)

@Composable
fun FilePropertiesDialog(file: RemoteFile, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(file.name) },
        text = {
            Column {
                PropertyRow("Path", file.path)
                PropertyRow("Type", if (file.isDirectory) "Directory" else "File")
                if (!file.isDirectory) PropertyRow("Size", formatBytes(file.size))
                PropertyRow("Modified", formatDate(file.lastModified))
                file.permissions?.let { PropertyRow("Permissions", it) }
                if (file.isSymlink) PropertyRow("Symlink target", file.symlinkTarget ?: "-")
                file.owner?.let { PropertyRow("Owner", it) }
                file.group?.let { PropertyRow("Group", it) }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}

@Composable
private fun PropertyRow(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun TextInputDialog(
    title: String,
    initialValue: String = "",
    label: String = "Name",
    confirmLabel: String = "OK",
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var value by remember { mutableStateOf(initialValue) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it },
                label = { Text(label) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = { if (value.isNotBlank()) onConfirm(value) }, enabled = value.isNotBlank()) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
