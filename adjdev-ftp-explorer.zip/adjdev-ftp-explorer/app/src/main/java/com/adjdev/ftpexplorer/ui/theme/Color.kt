package com.adjdev.ftpexplorer.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFF9ECAFF)
val BlueGrey80 = Color(0xFFBFC8E0)
val Teal80 = Color(0xFF9BE4D8)

val Blue40 = Color(0xFF1565C0)
val BlueGrey40 = Color(0xFF48597A)
val Teal40 = Color(0xFF2E7D6B)

val ErrorLight = Color(0xFFBA1A1A)
val ErrorDark = Color(0xFFFFB4AB)
