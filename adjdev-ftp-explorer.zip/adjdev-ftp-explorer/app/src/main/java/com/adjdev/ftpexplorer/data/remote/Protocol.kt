package com.adjdev.ftpexplorer.data.remote

/** Supported remote file transfer protocols. */
enum class Protocol {
    FTP,
    FTPS,
    SFTP;

    val defaultPort: Int
        get() = when (this) {
            FTP -> 21
            FTPS -> 21
            SFTP -> 22
        }
}

/** FTPS encryption mode: explicit (AUTH TLS over port 21) or implicit (TLS from connect, port 990). */
enum class TlsMode {
    NONE,
    EXPLICIT,
    IMPLICIT
}
