package com.adjdev.ftpexplorer.data.repository

import com.adjdev.ftpexplorer.data.db.TransferHistoryDao
import com.adjdev.ftpexplorer.data.db.TransferHistoryEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TransferHistoryRepository @Inject constructor(private val dao: TransferHistoryDao) {
    fun observeAll(): Flow<List<TransferHistoryEntity>> = dao.observeAll()
    fun observeFailed(): Flow<List<TransferHistoryEntity>> = dao.observeFailed()
    suspend fun record(entry: TransferHistoryEntity) = dao.insert(entry)
    suspend fun clear() = dao.clearAll()
}
