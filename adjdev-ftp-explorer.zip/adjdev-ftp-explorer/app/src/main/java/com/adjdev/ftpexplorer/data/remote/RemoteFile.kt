package com.adjdev.ftpexplorer.data.remote

/** A file or directory entry on a remote server, protocol-agnostic. */
data class RemoteFile(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long,
    val lastModified: Long,
    val permissions: String? = null,
    val isSymlink: Boolean = false,
    val symlinkTarget: String? = null,
    val owner: String? = null,
    val group: String? = null
) {
    val extension: String
        get() = name.substringAfterLast('.', "")
}
