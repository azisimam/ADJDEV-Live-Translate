package com.adjdev.ftpexplorer

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.adjdev.ftpexplorer.data.repository.SettingsRepository
import com.adjdev.ftpexplorer.ui.navigation.AdjdevNavGraph
import com.adjdev.ftpexplorer.ui.theme.ADJDEVFtpExplorerTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var settingsRepository: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by settingsRepository.settings.collectAsState(
                initial = com.adjdev.ftpexplorer.data.repository.AppSettings()
            )
            ADJDEVFtpExplorerTheme(
                appTheme = settings.theme,
                dynamicColor = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AdjdevNavGraph()
                }
            }
        }
    }
}
