package com.adjdev.ftpexplorer.data.local

data class LocalFile(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long,
    val lastModified: Long
)
