package com.adjdev.ftpexplorer.di

import android.content.Context
import androidx.room.Room
import com.adjdev.ftpexplorer.data.db.AppDatabase
import com.adjdev.ftpexplorer.data.db.BookmarkDao
import com.adjdev.ftpexplorer.data.db.ServerDao
import com.adjdev.ftpexplorer.data.db.TransferHistoryDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "adjdev_ftp_explorer.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideServerDao(db: AppDatabase): ServerDao = db.serverDao()

    @Provides
    fun provideBookmarkDao(db: AppDatabase): BookmarkDao = db.bookmarkDao()

    @Provides
    fun provideTransferHistoryDao(db: AppDatabase): TransferHistoryDao = db.transferHistoryDao()
}
