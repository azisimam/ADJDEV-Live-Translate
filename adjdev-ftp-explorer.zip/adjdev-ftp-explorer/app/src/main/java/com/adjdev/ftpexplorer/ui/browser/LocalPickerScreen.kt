package com.adjdev.ftpexplorer.ui.browser

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.adjdev.ftpexplorer.ui.common.BreadcrumbBar
import com.adjdev.ftpexplorer.ui.common.LoadingBox
import java.io.File

/** mode = "upload" (pick one or more files to upload) or "download" (pick a destination folder). */
@Composable
fun LocalPickerScreen(
    mode: String,
    onPickFiles: (List<File>) -> Unit,
    onPickFolder: (File) -> Unit,
    onBack: () -> Unit,
    viewModel: LocalPickerViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var showCreateFolder by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (mode == "download") "Choose destination folder" else "Choose files to upload") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
                actions = {
                    if (mode == "download") {
                        androidx.compose.material3.TextButton(onClick = { onPickFolder(File(state.currentPath)) }) { Text("Select this folder") }
                    } else if (state.selected.isNotEmpty()) {
                        androidx.compose.material3.TextButton(onClick = { onPickFiles(state.selected.map { File(it) }) }) { Text("Upload (${state.selected.size})") }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateFolder = true }) { Icon(Icons.Filled.CreateNewFolder, contentDescription = "New folder") }
        }
    ) { padding ->
        androidx.compose.foundation.layout.Column(modifier = Modifier
            .padding(padding)
            .fillMaxSize()) {
            BreadcrumbBar(path = state.currentPath, onNavigate = viewModel::load)
            if (state.isLoading) {
                LoadingBox(modifier = Modifier.fillMaxSize())
            } else {
                LazyColumn {
                    items(state.files, key = { it.path }) { file ->
                        LocalFileRow(
                            file = file,
                            isSelected = state.selected.contains(file.path),
                            selectionEnabled = mode == "upload",
                            onClick = {
                                if (file.isDirectory) viewModel.load(file.path)
                                else if (mode == "upload") viewModel.toggleSelect(file)
                            }
                        )
                    }
                }
            }
        }
    }

    if (showCreateFolder) {
        TextInputDialog(
            title = "New folder",
            onConfirm = { name -> viewModel.createFolder(name); showCreateFolder = false },
            onDismiss = { showCreateFolder = false }
        )
    }
}

@Composable
private fun LocalFileRow(
    file: com.adjdev.ftpexplorer.data.local.LocalFile,
    isSelected: Boolean,
    selectionEnabled: Boolean,
    onClick: () -> Unit
) {
    androidx.compose.material3.ListItem(
        headlineContent = { Text(file.name) },
        supportingContent = {
            Text(if (file.isDirectory) "Folder" else com.adjdev.ftpexplorer.ui.common.formatBytes(file.size))
        },
        leadingContent = {
            Icon(
                if (file.isDirectory) androidx.compose.material.icons.Icons.Filled.Folder else androidx.compose.material.icons.Icons.Filled.InsertDriveFile,
                contentDescription = null
            )
        },
        trailingContent = {
            if (selectionEnabled && !file.isDirectory) {
                androidx.compose.material3.Checkbox(checked = isSelected, onCheckedChange = { onClick() })
            }
        },
        modifier = Modifier.clickable(onClick = onClick)
    )
}
