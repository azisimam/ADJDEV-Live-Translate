package com.adjdev.ftpexplorer.data.repository

import com.adjdev.ftpexplorer.data.remote.ConnectionInfo
import com.adjdev.ftpexplorer.data.remote.RemoteFileSystem
import com.adjdev.ftpexplorer.data.remote.RemoteFileSystemFactory
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Keeps at most one live [RemoteFileSystem] connection per server id so the file browser,
 * search, and connection-info screens for the same server share one session, while different
 * servers can stay connected in parallel.
 */
@Singleton
class RemoteSessionManager @Inject constructor(
    private val factory: RemoteFileSystemFactory,
    private val serverRepository: ServerRepository
) {
    private val sessions = mutableMapOf<String, RemoteFileSystem>()
    private val mutex = Mutex()

    suspend fun getOrConnect(serverId: String): Result<RemoteFileSystem> = mutex.withLock {
        sessions[serverId]?.let { if (it.isConnected()) return@withLock Result.success(it) }
        val config = serverRepository.getConnectionConfig(serverId)
            ?: return@withLock Result.failure(IllegalArgumentException("Server not found"))
        val fs = factory.create(config.protocol)
        val result = fs.connect(config)
        return@withLock if (result.isSuccess) {
            sessions[serverId] = fs
            serverRepository.touchLastConnected(serverId)
            Result.success(fs)
        } else {
            Result.failure(result.exceptionOrNull() ?: Exception("Unknown connection error"))
        }
    }

    suspend fun reconnect(serverId: String): Result<RemoteFileSystem> = mutex.withLock {
        sessions.remove(serverId)?.disconnect()
        return@withLock getOrConnectInternal(serverId)
    }

    private suspend fun getOrConnectInternal(serverId: String): Result<RemoteFileSystem> {
        val config = serverRepository.getConnectionConfig(serverId)
            ?: return Result.failure(IllegalArgumentException("Server not found"))
        val fs = factory.create(config.protocol)
        val result = fs.connect(config)
        return if (result.isSuccess) {
            sessions[serverId] = fs
            serverRepository.touchLastConnected(serverId)
            Result.success(fs)
        } else {
            Result.failure(result.exceptionOrNull() ?: Exception("Unknown connection error"))
        }
    }

    suspend fun getConnectionInfo(serverId: String): ConnectionInfo? = sessions[serverId]?.getConnectionInfo()

    suspend fun disconnect(serverId: String) = mutex.withLock {
        sessions.remove(serverId)?.disconnect()
    }

    suspend fun disconnectAll() = mutex.withLock {
        sessions.values.forEach { it.disconnect() }
        sessions.clear()
    }

    fun activeSession(serverId: String): RemoteFileSystem? = sessions[serverId]?.takeIf { it.isConnected() }
}
