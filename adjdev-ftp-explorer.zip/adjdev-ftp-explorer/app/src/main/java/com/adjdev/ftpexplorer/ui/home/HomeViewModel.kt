package com.adjdev.ftpexplorer.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.repository.Server
import com.adjdev.ftpexplorer.data.repository.ServerRepository
import com.adjdev.ftpexplorer.transfer.TransferManager
import com.adjdev.ftpexplorer.transfer.TransferState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class HomeUiState(
    val recentServers: List<Server> = emptyList(),
    val totalServers: Int = 0,
    val activeTransfers: Int = 0,
    val failedTransfers: Int = 0
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    serverRepository: ServerRepository,
    transferManager: TransferManager
) : ViewModel() {

    val uiState: StateFlow<HomeUiState> = combine(
        serverRepository.observeRecent(5),
        serverRepository.observeServers(),
        transferManager.transfers
    ) { recent, all, transfers ->
        HomeUiState(
            recentServers = recent,
            totalServers = all.size,
            activeTransfers = transfers.count { it.state == TransferState.RUNNING || it.state == TransferState.QUEUED },
            failedTransfers = transfers.count { it.state == TransferState.FAILED }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUiState())
}
