package com.adjdev.ftpexplorer.data.remote

/** Typed errors so the UI can show clear, localized messages and offer Retry/Reconnect. */
sealed class RemoteException(message: String, cause: Throwable? = null) : Exception(message, cause) {
    class ConnectionRefused(cause: Throwable? = null) : RemoteException("Connection refused", cause)
    class AuthenticationFailed(cause: Throwable? = null) : RemoteException("Authentication failed", cause)
    class TimeoutError(cause: Throwable? = null) : RemoteException("Connection timed out", cause)
    class PermissionDenied(path: String? = null, cause: Throwable? = null) :
        RemoteException("Permission denied${path?.let { ": $it" } ?: ""}", cause)
    class FileNotFound(path: String? = null, cause: Throwable? = null) :
        RemoteException("File not found${path?.let { ": $it" } ?: ""}", cause)
    class DiskError(cause: Throwable? = null) : RemoteException("Disk or storage error", cause)
    class ConnectionLost(cause: Throwable? = null) : RemoteException("Connection lost", cause)
    class TlsError(cause: Throwable? = null) : RemoteException("TLS/SSL error", cause)
    class SftpError(message: String, cause: Throwable? = null) : RemoteException(message, cause)
    class Cancelled : RemoteException("Transfer cancelled")
    class Unknown(cause: Throwable) : RemoteException(cause.message ?: "Unknown error", cause)
}
