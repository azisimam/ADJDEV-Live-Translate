package com.adjdev.ftpexplorer.ui.viewer

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.SaveAs
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.adjdev.ftpexplorer.ui.browser.TextInputDialog
import com.adjdev.ftpexplorer.ui.common.ErrorBanner
import com.adjdev.ftpexplorer.ui.common.LoadingBox

@Composable
fun TextEditorScreen(
    onBack: () -> Unit,
    viewModel: TextEditorViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var showSaveAs by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.saveSuccess) {
        if (state.saveSuccess) snackbarHostState.showSnackbar("Saved")
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = { Text(state.fileName + if (state.isDirty) " *" else "") },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
                actions = {
                    if (state.isSaving) {
                        CircularProgressIndicator(modifier = Modifier
                            .padding(end = 12.dp)
                            .size(20.dp))
                    } else {
                        IconButton(onClick = viewModel::save) { Icon(Icons.Filled.Save, contentDescription = "Save") }
                        IconButton(onClick = { showSaveAs = true }) { Icon(Icons.Filled.SaveAs, contentDescription = "Save As") }
                    }
                }
            )
        }
    ) { padding ->
        when {
            state.isLoading -> LoadingBox(modifier = Modifier
                .padding(padding)
                .fillMaxSize())
            state.error != null -> ErrorBanner(state.error!!, modifier = Modifier.padding(padding))
            else -> OutlinedTextField(
                value = state.content,
                onValueChange = viewModel::onContentChange,
                textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = androidx.compose.ui.unit.TextUnit(13f, androidx.compose.ui.unit.TextUnitType.Sp)),
                modifier = Modifier
                    .padding(padding)
                    .fillMaxSize()
                    .padding(8.dp),
                keyboardOptions = KeyboardOptions.Default
            )
        }
    }

    if (showSaveAs) {
        TextInputDialog(
            title = "Save As",
            initialValue = state.fileName,
            confirmLabel = "Save",
            onConfirm = { name -> viewModel.saveAs(name); showSaveAs = false },
            onDismiss = { showSaveAs = false }
        )
    }
}
