package com.adjdev.ftpexplorer.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "servers")
data class ServerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val username: String,
    /** "ivBase64:cipherTextBase64" produced by CredentialManager. Never plaintext. */
    val encryptedPassword: String,
    val protocol: String,
    val passiveMode: Boolean,
    val tlsMode: String,
    val timeoutSeconds: Int,
    val defaultRemoteDir: String,
    val isFavorite: Boolean = false,
    val lastConnectedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
