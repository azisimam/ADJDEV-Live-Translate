package com.adjdev.ftpexplorer.ui.transfers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.db.TransferHistoryEntity
import com.adjdev.ftpexplorer.data.repository.TransferHistoryRepository
import com.adjdev.ftpexplorer.transfer.TransferItem
import com.adjdev.ftpexplorer.transfer.TransferManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class TransfersUiState(
    val active: List<TransferItem> = emptyList(),
    val history: List<TransferHistoryEntity> = emptyList(),
    val failedHistory: List<TransferHistoryEntity> = emptyList()
)

@HiltViewModel
class TransfersViewModel @Inject constructor(
    private val transferManager: TransferManager,
    private val historyRepository: TransferHistoryRepository
) : ViewModel() {

    val uiState: StateFlow<TransfersUiState> = combine(
        transferManager.transfers,
        historyRepository.observeAll(),
        historyRepository.observeFailed()
    ) { active, history, failed ->
        TransfersUiState(active = active, history = history, failedHistory = failed)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TransfersUiState())

    fun pause(id: String) = transferManager.pause(id)
    fun resume(id: String) = transferManager.resume(id)
    fun cancel(id: String) = transferManager.cancel(id)
    fun retry(id: String) = transferManager.retry(id)
    fun remove(id: String) = transferManager.remove(id)
    fun clearCompleted() = transferManager.clearCompleted()
    fun clearHistory() = viewModelScope.launch { historyRepository.clear() }
}
