package com.adjdev.ftpexplorer.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPFile
import org.apache.commons.net.ftp.FTPReply
import org.apache.commons.net.ftp.FTPSClient
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.SocketException
import java.net.SocketTimeoutException
import javax.net.ssl.SSLException

/**
 * FTP and FTPS implementation of [RemoteFileSystem] built on Apache Commons Net.
 * A single instance is bound to one connection at a time (see RemoteFileSystemFactory).
 */
class FtpFileSystem : RemoteFileSystem {

    private var client: FTPClient? = null
    private var config: ConnectionConfig? = null
    private val log = mutableListOf<String>()

    private fun appendLog(line: String) {
        synchronized(log) {
            log.add(line)
            if (log.size > 200) log.removeAt(0)
        }
    }

    override suspend fun connect(config: ConnectionConfig): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            this@FtpFileSystem.config = config
            val c: FTPClient = if (config.protocol == Protocol.FTPS) {
                FTPSClient(config.tlsMode == TlsMode.IMPLICIT).apply {
                    if (config.tlsMode == TlsMode.EXPLICIT) {
                        // explicit AUTH TLS is negotiated automatically by FTPSClient after connect()
                    }
                }
            } else {
                FTPClient()
            }
            c.connectTimeout = config.timeoutSeconds * 1000
            c.controlEncoding = "UTF-8"
            c.connect(config.host, config.port)
            appendLog("Connected to ${config.host}:${config.port}")
            val reply = c.replyCode
            if (!FTPReply.isPositiveCompletion(reply)) {
                c.disconnect()
                return@withContext Result.failure(RemoteException.ConnectionRefused())
            }

            if (c is FTPSClient) {
                c.execPBSZ(0)
                c.execPROT("P")
            }

            c.soTimeout = config.timeoutSeconds * 1000
            if (!c.login(config.username, config.password)) {
                val code = c.replyCode
                c.disconnect()
                return@withContext Result.failure(RemoteException.AuthenticationFailed())
            }
            appendLog("Logged in as ${config.username}")

            c.setFileType(FTP.BINARY_FILE_TYPE)
            if (config.passiveMode) c.enterLocalPassiveMode() else c.enterLocalActiveMode()
            c.bufferSize = 1024 * 64

            val startDir = config.defaultRemoteDir.ifBlank { "/" }
            if (startDir != "/" && !c.changeWorkingDirectory(startDir)) {
                appendLog("Warning: default directory $startDir not found, staying at root")
            }

            client = c
            Result.success(Unit)
        } catch (e: SocketTimeoutException) {
            Result.failure(RemoteException.TimeoutError(e))
        } catch (e: SSLException) {
            Result.failure(RemoteException.TlsError(e))
        } catch (e: SocketException) {
            Result.failure(RemoteException.ConnectionRefused(e))
        } catch (e: IOException) {
            Result.failure(RemoteException.ConnectionLost(e))
        } catch (e: Exception) {
            Result.failure(RemoteException.Unknown(e))
        }
    }

    override suspend fun disconnect() = withContext(Dispatchers.IO) {
        try {
            client?.let { if (it.isConnected) { it.logout(); it.disconnect() } }
        } catch (_: Exception) {
            // best-effort cleanup
        } finally {
            client = null
        }
        Unit
    }

    override fun isConnected(): Boolean = client?.isConnected == true

    private fun requireClient(): FTPClient = client ?: throw RemoteException.ConnectionLost()

    override suspend fun listFiles(path: String): Result<List<RemoteFile>> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            val files: Array<FTPFile> = c.listFiles(path) ?: emptyArray()
            val result = files.filter { it.name != "." && it.name != ".." }.map { it.toRemoteFile(path) }
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    private fun FTPFile.toRemoteFile(basePath: String): RemoteFile {
        val fullPath = joinPath(basePath, name)
        return RemoteFile(
            name = name,
            path = fullPath,
            isDirectory = isDirectory,
            size = size,
            lastModified = timestamp?.timeInMillis ?: 0L,
            permissions = buildPermissionString(this),
            isSymlink = isSymbolicLink,
            symlinkTarget = link,
            owner = user,
            group = group
        )
    }

    private fun buildPermissionString(f: FTPFile): String {
        val sb = StringBuilder(10)
        sb.append(if (f.isDirectory) 'd' else if (f.isSymbolicLink) 'l' else '-')
        val types = intArrayOf(FTPFile.USER_ACCESS, FTPFile.GROUP_ACCESS, FTPFile.WORLD_ACCESS)
        val perms = intArrayOf(FTPFile.READ_PERMISSION, FTPFile.WRITE_PERMISSION, FTPFile.EXECUTE_PERMISSION)
        val chars = charArrayOf('r', 'w', 'x')
        for (t in types) {
            for (i in perms.indices) {
                sb.append(if (f.hasPermission(t, perms[i])) chars[i] else '-')
            }
        }
        return sb.toString()
    }

    override suspend fun createDirectory(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            if (c.makeDirectory(path)) Result.success(Unit)
            else Result.failure(RemoteException.PermissionDenied(path))
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    override suspend fun createFile(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            val empty = java.io.ByteArrayInputStream(ByteArray(0))
            val ok = c.storeFile(path, empty)
            if (ok) Result.success(Unit) else Result.failure(RemoteException.PermissionDenied(path))
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    override suspend fun delete(path: String, isDirectory: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            val ok = if (isDirectory) deleteDirectoryRecursive(c, path) else c.deleteFile(path)
            if (ok) Result.success(Unit) else Result.failure(RemoteException.PermissionDenied(path))
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    private fun deleteDirectoryRecursive(c: FTPClient, path: String): Boolean {
        val children = c.listFiles(path) ?: emptyArray()
        for (child in children) {
            if (child.name == "." || child.name == "..") continue
            val childPath = joinPath(path, child.name)
            if (child.isDirectory) {
                if (!deleteDirectoryRecursive(c, childPath)) return false
            } else {
                if (!c.deleteFile(childPath)) return false
            }
        }
        return c.removeDirectory(path)
    }

    override suspend fun rename(oldPath: String, newName: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            val parent = oldPath.substringBeforeLast('/', "")
            val newPath = joinPath(parent, newName)
            if (c.rename(oldPath, newPath)) Result.success(Unit)
            else Result.failure(RemoteException.PermissionDenied(oldPath))
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    override suspend fun move(sourcePath: String, destinationPath: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val c = requireClient()
                if (c.rename(sourcePath, destinationPath)) Result.success(Unit)
                else Result.failure(RemoteException.PermissionDenied(sourcePath))
            } catch (e: Exception) {
                Result.failure(e.toRemoteException())
            }
        }

    override suspend fun copy(
        sourcePath: String,
        destinationPath: String,
        isDirectory: Boolean,
        onProgress: (transferred: Long, total: Long) -> Unit
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (isDirectory) {
                return@withContext Result.failure(
                    UnsupportedOperationException("Directory copy is not supported for FTP in this build")
                )
            }
            val c = requireClient()
            val tmp = File.createTempFile("adjdev_copy_", ".tmp")
            try {
                downloadInternal(c, sourcePath, tmp, onProgress, { false }, { false })
                uploadInternal(c, tmp, destinationPath, onProgress, { false }, { false })
            } finally {
                tmp.delete()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    override suspend fun download(
        remotePath: String,
        localFile: File,
        onProgress: (transferred: Long, total: Long) -> Unit,
        isPaused: () -> Boolean,
        isCancelled: () -> Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            downloadInternal(c, remotePath, localFile, onProgress, isPaused, isCancelled)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    private fun downloadInternal(
        c: FTPClient,
        remotePath: String,
        localFile: File,
        onProgress: (Long, Long) -> Unit,
        isPaused: () -> Boolean,
        isCancelled: () -> Boolean
    ) {
        val total = c.mlistFile(remotePath)?.size ?: c.listFiles(remotePath)?.firstOrNull()?.size ?: -1L
        val remoteIn = c.retrieveFileStream(remotePath)
            ?: throw RemoteException.FileNotFound(remotePath)
        BufferedInputStream(remoteIn).use { input ->
            BufferedOutputStream(FileOutputStream(localFile)).use { output ->
                copyStreamWithControl(input, output, total, onProgress, isPaused, isCancelled)
            }
        }
        if (!c.completePendingCommand()) {
            throw RemoteException.ConnectionLost()
        }
    }

    override suspend fun upload(
        localFile: File,
        remotePath: String,
        onProgress: (transferred: Long, total: Long) -> Unit,
        isPaused: () -> Boolean,
        isCancelled: () -> Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            uploadInternal(c, localFile, remotePath, onProgress, isPaused, isCancelled)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    private fun uploadInternal(
        c: FTPClient,
        localFile: File,
        remotePath: String,
        onProgress: (Long, Long) -> Unit,
        isPaused: () -> Boolean,
        isCancelled: () -> Boolean
    ) {
        val total = localFile.length()
        val remoteOut = c.storeFileStream(remotePath) ?: throw RemoteException.PermissionDenied(remotePath)
        BufferedOutputStream(remoteOut).use { output ->
            BufferedInputStream(FileInputStream(localFile)).use { input ->
                copyStreamWithControl(input, output, total, onProgress, isPaused, isCancelled)
            }
        }
        if (!c.completePendingCommand()) {
            throw RemoteException.ConnectionLost()
        }
    }

    private fun copyStreamWithControl(
        input: java.io.InputStream,
        output: java.io.OutputStream,
        total: Long,
        onProgress: (Long, Long) -> Unit,
        isPaused: () -> Boolean,
        isCancelled: () -> Boolean
    ) {
        val buffer = ByteArray(64 * 1024)
        var transferred = 0L
        while (true) {
            if (isCancelled()) throw RemoteException.Cancelled()
            while (isPaused()) {
                if (isCancelled()) throw RemoteException.Cancelled()
                Thread.sleep(200)
            }
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
            transferred += read
            onProgress(transferred, total)
        }
        output.flush()
    }

    override suspend fun exists(path: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            val files = c.listFiles(path)
            Result.success(!files.isNullOrEmpty() || c.changeWorkingDirectory(path))
        } catch (e: Exception) {
            Result.success(false)
        }
    }

    override suspend fun getFileSize(path: String): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            val size = c.mlistFile(path)?.size ?: c.listFiles(path)?.firstOrNull()?.size ?: -1L
            Result.success(size)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    override suspend fun getConnectionInfo(): ConnectionInfo {
        val cfg = config
        val c = client
        return ConnectionInfo(
            host = cfg?.host.orEmpty(),
            port = cfg?.port ?: 0,
            protocol = cfg?.protocol ?: Protocol.FTP,
            isEncrypted = cfg?.protocol == Protocol.FTPS,
            isConnected = c?.isConnected == true,
            serverGreeting = c?.replyString,
            log = synchronized(log) { log.toList() }
        )
    }

    override suspend fun sendRawCommand(command: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val c = requireClient()
            appendLog("> $command")
            val parts = command.split(" ", limit = 2)
            val ok = if (parts.size > 1) c.sendCommand(parts[0], parts[1]) else c.sendCommand(parts[0])
            val reply = c.replyStrings?.joinToString("\n") ?: c.replyString
            appendLog("< $reply")
            Result.success(reply ?: "")
        } catch (e: Exception) {
            Result.failure(e.toRemoteException())
        }
    }

    private fun joinPath(base: String, name: String): String {
        val b = base.trimEnd('/')
        return if (b.isEmpty()) "/$name" else "$b/$name"
    }

    private fun Exception.toRemoteException(): Throwable = when (this) {
        is RemoteException -> this
        is SocketTimeoutException -> RemoteException.TimeoutError(this)
        is SSLException -> RemoteException.TlsError(this)
        is SocketException -> RemoteException.ConnectionLost(this)
        is IOException -> RemoteException.ConnectionLost(this)
        else -> RemoteException.Unknown(this)
    }
}
