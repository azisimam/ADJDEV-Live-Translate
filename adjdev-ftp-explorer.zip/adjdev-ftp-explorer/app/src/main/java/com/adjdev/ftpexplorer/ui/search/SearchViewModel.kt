package com.adjdev.ftpexplorer.ui.search

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.remote.RemoteFile
import com.adjdev.ftpexplorer.data.remote.RemoteFileSystem
import com.adjdev.ftpexplorer.data.repository.RemoteSessionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SearchUiState(
    val query: String = "",
    val results: List<RemoteFile> = emptyList(),
    val isSearching: Boolean = false,
    val scannedFolders: Int = 0,
    val error: String? = null,
    val finished: Boolean = false
)

/** Recursive breadth-first remote search with a folder-count cap so it never hammers the server. */
private const val MAX_FOLDERS_SCANNED = 500

@HiltViewModel
class SearchViewModel @Inject constructor(
    private val sessionManager: RemoteSessionManager,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    val serverId: String = checkNotNull(savedStateHandle["serverId"])
    private val startPath: String = savedStateHandle.get<String>("path") ?: "/"

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null

    fun onQueryChange(query: String) {
        _uiState.update { it.copy(query = query) }
    }

    fun search() {
        val query = _uiState.value.query.trim()
        if (query.isBlank()) return
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            _uiState.update { it.copy(isSearching = true, results = emptyList(), scannedFolders = 0, error = null, finished = false) }
            val fs = sessionManager.activeSession(serverId)
            if (fs == null) {
                _uiState.update { it.copy(isSearching = false, error = "Not connected") }
                return@launch
            }
            val found = mutableListOf<RemoteFile>()
            var scanned = 0
            val queue = ArrayDeque<String>()
            queue.add(startPath)
            while (queue.isNotEmpty() && scanned < MAX_FOLDERS_SCANNED) {
                val dir = queue.removeFirst()
                val listResult = fs.listFiles(dir)
                scanned++
                _uiState.update { it.copy(scannedFolders = scanned) }
                val children = listResult.getOrNull() ?: continue
                for (child in children) {
                    if (child.name.contains(query, ignoreCase = true)) {
                        found.add(child)
                        _uiState.update { it.copy(results = found.toList()) }
                    }
                    if (child.isDirectory) queue.add(child.path)
                }
            }
            _uiState.update { it.copy(isSearching = false, finished = true) }
        }
    }

    fun cancelSearch() {
        searchJob?.cancel()
        _uiState.update { it.copy(isSearching = false) }
    }
}
