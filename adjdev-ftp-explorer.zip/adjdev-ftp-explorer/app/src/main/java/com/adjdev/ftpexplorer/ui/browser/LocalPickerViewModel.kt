package com.adjdev.ftpexplorer.ui.browser

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.local.LocalFile
import com.adjdev.ftpexplorer.data.local.LocalFileSystem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LocalPickerUiState(
    val currentPath: String = "",
    val files: List<LocalFile> = emptyList(),
    val selected: Set<String> = emptySet(),
    val isLoading: Boolean = true
)

@HiltViewModel
class LocalPickerViewModel @Inject constructor(
    private val localFileSystem: LocalFileSystem
) : ViewModel() {

    private val _uiState = MutableStateFlow(LocalPickerUiState(currentPath = localFileSystem.rootPath()))
    val uiState: StateFlow<LocalPickerUiState> = _uiState.asStateFlow()

    init {
        load(_uiState.value.currentPath)
    }

    fun load(path: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, currentPath = path) }
            localFileSystem.list(path).fold(
                onSuccess = { files -> _uiState.update { it.copy(files = files, isLoading = false) } },
                onFailure = { _uiState.update { it.copy(isLoading = false, files = emptyList()) } }
            )
        }
    }

    fun toggleSelect(file: LocalFile) {
        _uiState.update {
            val next = if (it.selected.contains(file.path)) it.selected - file.path else it.selected + file.path
            it.copy(selected = next)
        }
    }

    fun createFolder(name: String) {
        viewModelScope.launch {
            localFileSystem.createDirectory("${_uiState.value.currentPath}/$name")
            load(_uiState.value.currentPath)
        }
    }
}
