package com.adjdev.ftpexplorer.ui.viewer

import android.content.Context
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.repository.RemoteSessionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

data class ViewerUiState(
    val localFile: File? = null,
    val fileName: String = "",
    val isLoading: Boolean = true,
    val error: String? = null
)

@HiltViewModel
class ViewerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sessionManager: RemoteSessionManager,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val serverId: String = checkNotNull(savedStateHandle["serverId"])
    private val remotePath: String = checkNotNull(savedStateHandle["path"])
    private val isLocal: Boolean = savedStateHandle.get<String>("local")?.toBoolean() ?: false

    private val _uiState = MutableStateFlow(ViewerUiState(fileName = remotePath.substringAfterLast('/')))
    val uiState: StateFlow<ViewerUiState> = _uiState.asStateFlow()

    init {
        load()
    }

    private fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            if (isLocal) {
                val file = File(remotePath)
                _uiState.update { it.copy(isLoading = false, localFile = file) }
                return@launch
            }
            val fsResult = sessionManager.getOrConnect(serverId)
            val fs = fsResult.getOrNull()
            if (fs == null) {
                _uiState.update { it.copy(isLoading = false, error = fsResult.exceptionOrNull()?.message ?: "Connection failed") }
                return@launch
            }
            val cacheFile = withContext(Dispatchers.IO) {
                File(context.cacheDir, "preview_${serverId}_${remotePath.hashCode()}_${remotePath.substringAfterLast('/')}")
            }
            val result = fs.download(remotePath, cacheFile, { _, _ -> })
            if (result.isSuccess) {
                _uiState.update { it.copy(isLoading = false, localFile = cacheFile) }
            } else {
                _uiState.update { it.copy(isLoading = false, error = result.exceptionOrNull()?.message ?: "Could not load file") }
            }
        }
    }

    fun retry() = load()
}
