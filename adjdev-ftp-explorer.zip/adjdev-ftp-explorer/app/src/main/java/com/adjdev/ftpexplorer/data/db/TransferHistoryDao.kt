package com.adjdev.ftpexplorer.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TransferHistoryDao {
    @Query("SELECT * FROM transfer_history ORDER BY finishedAt DESC LIMIT 300")
    fun observeAll(): Flow<List<TransferHistoryEntity>>

    @Query("SELECT * FROM transfer_history WHERE finalState = 'FAILED' ORDER BY finishedAt DESC")
    fun observeFailed(): Flow<List<TransferHistoryEntity>>

    @Insert
    suspend fun insert(entry: TransferHistoryEntity)

    @Query("DELETE FROM transfer_history")
    suspend fun clearAll()
}
