package com.adjdev.ftpexplorer.data.remote

import java.io.File

/**
 * Protocol-agnostic remote file system contract. FTP, FTPS and SFTP implementations live
 * behind this interface so the UI/repository layer never depends on a specific client library.
 */
interface RemoteFileSystem {

    suspend fun connect(config: ConnectionConfig): Result<Unit>

    suspend fun disconnect()

    fun isConnected(): Boolean

    suspend fun listFiles(path: String): Result<List<RemoteFile>>

    suspend fun createDirectory(path: String): Result<Unit>

    suspend fun createFile(path: String): Result<Unit>

    suspend fun delete(path: String, isDirectory: Boolean): Result<Unit>

    suspend fun rename(oldPath: String, newName: String): Result<Unit>

    suspend fun move(sourcePath: String, destinationPath: String): Result<Unit>

    /** Remote-to-remote copy. Most FTP/SFTP servers have no native copy, so implementations
     * stream through a temporary local buffer (download then upload) transparently. */
    suspend fun copy(
        sourcePath: String,
        destinationPath: String,
        isDirectory: Boolean,
        onProgress: (transferred: Long, total: Long) -> Unit = { _, _ -> }
    ): Result<Unit>

    suspend fun download(
        remotePath: String,
        localFile: File,
        onProgress: (transferred: Long, total: Long) -> Unit,
        isPaused: () -> Boolean = { false },
        isCancelled: () -> Boolean = { false }
    ): Result<Unit>

    suspend fun upload(
        localFile: File,
        remotePath: String,
        onProgress: (transferred: Long, total: Long) -> Unit,
        isPaused: () -> Boolean = { false },
        isCancelled: () -> Boolean = { false }
    ): Result<Unit>

    suspend fun exists(path: String): Result<Boolean>

    suspend fun getFileSize(path: String): Result<Long>

    suspend fun getConnectionInfo(): ConnectionInfo

    /** Only supported (and only exposed in UI) for the FTP/FTPS protocol. */
    suspend fun sendRawCommand(command: String): Result<String> =
        Result.failure(UnsupportedOperationException("Raw commands are only supported over FTP/FTPS"))
}
