package com.adjdev.ftpexplorer.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.sftp.FileAttributes
import net.schmizz.sshj.sftp.FileMode
import net.schmizz.sshj.sftp.OpenMode
import net.schmizz.sshj.sftp.RemoteResourceInfo
import net.schmizz.sshj.sftp.Response
import net.schmizz.sshj.sftp.SFTPClient
import net.schmizz.sshj.sftp.SFTPException
import net.schmizz.sshj.transport.TransportException
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import net.schmizz.sshj.userauth.UserAuthException
import java.io.File
import java.net.SocketTimeoutException
import java.util.EnumSet

/**
 * SFTP implementation of [RemoteFileSystem] built on sshj.
 *
 * Host key verification uses [PromiscuousVerifier] so first-time connections to self-hosted
 * servers succeed without a pre-provisioned known_hosts file. This mirrors the trust-on-first-use
 * behaviour of most mobile FTP/SFTP clients; a future enhancement could persist and pin host
 * keys per server for stricter verification.
 */
class SftpFileSystem : RemoteFileSystem {

    private var ssh: SSHClient? = null
    private var sftp: SFTPClient? = null
    private var config: ConnectionConfig? = null
    private val log = mutableListOf<String>()

    private fun appendLog(line: String) {
        synchronized(log) {
            log.add(line)
            if (log.size > 200) log.removeAt(0)
        }
    }

    override suspend fun connect(config: ConnectionConfig): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            this@SftpFileSystem.config = config
            val client = SSHClient()
            client.addHostKeyVerifier(PromiscuousVerifier())
            client.connectTimeout = config.timeoutSeconds * 1000
            client.timeout = config.timeoutSeconds * 1000
            client.connect(config.host, config.port)
            appendLog("Connected to ${config.host}:${config.port}")
            client.authPassword(config.username, config.password)
            appendLog("Authenticated as ${config.username}")
            ssh = client
            sftp = client.newSFTPClient()
            val startDir = config.defaultRemoteDir.ifBlank { "." }
            Result.success(Unit).also { appendLog("SFTP session ready ($startDir)") }
        } catch (e: UserAuthException) {
            Result.failure(RemoteException.AuthenticationFailed(e))
        } catch (e: SocketTimeoutException) {
            Result.failure(RemoteException.TimeoutError(e))
        } catch (e: TransportException) {
            Result.failure(RemoteException.ConnectionLost(e))
        } catch (e: Exception) {
            Result.failure(RemoteException.Unknown(e))
        }
    }

    override suspend fun disconnect() = withContext(Dispatchers.IO) {
        try {
            sftp?.close()
            ssh?.disconnect()
        } catch (_: Exception) {
        } finally {
            sftp = null
            ssh = null
        }
    }

    override fun isConnected(): Boolean = ssh?.isConnected == true

    private fun requireSftp(): SFTPClient = sftp ?: throw RemoteException.ConnectionLost()

    override suspend fun listFiles(path: String): Result<List<RemoteFile>> = withContext(Dispatchers.IO) {
        try {
            val c = requireSftp()
            val entries: List<RemoteResourceInfo> = c.ls(path)
            val result = entries
                .filter { it.name != "." && it.name != ".." }
                .map { it.toRemoteFile() }
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(path))
        }
    }

    private fun RemoteResourceInfo.toRemoteFile(): RemoteFile {
        val attrs: FileAttributes = attributes
        val isDir = attrs.type == FileMode.Type.DIRECTORY
        val isLink = attrs.type == FileMode.Type.SYMLINK
        return RemoteFile(
            name = name,
            path = path,
            isDirectory = isDir,
            size = attrs.size,
            lastModified = attrs.mtime * 1000L,
            permissions = attrs.mode.toString(),
            isSymlink = isLink,
            owner = attrs.uid.toString(),
            group = attrs.gid.toString()
        )
    }

    override suspend fun createDirectory(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            requireSftp().mkdir(path)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(path))
        }
    }

    override suspend fun createFile(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireSftp()
            val handle = c.open(
                path,
                EnumSet.of(OpenMode.CREAT, OpenMode.WRITE, OpenMode.TRUNC)
            )
            handle.close()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(path))
        }
    }

    override suspend fun delete(path: String, isDirectory: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireSftp()
            if (isDirectory) deleteDirectoryRecursive(c, path) else c.rm(path)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(path))
        }
    }

    private fun deleteDirectoryRecursive(c: SFTPClient, path: String) {
        val children = c.ls(path)
        for (child in children) {
            if (child.name == "." || child.name == "..") continue
            if (child.attributes.type == FileMode.Type.DIRECTORY) {
                deleteDirectoryRecursive(c, child.path)
            } else {
                c.rm(child.path)
            }
        }
        c.rmdir(path)
    }

    override suspend fun rename(oldPath: String, newName: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireSftp()
            val parent = oldPath.substringBeforeLast('/', "")
            val newPath = if (parent.isEmpty()) "/$newName" else "$parent/$newName"
            c.rename(oldPath, newPath)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(oldPath))
        }
    }

    override suspend fun move(sourcePath: String, destinationPath: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                requireSftp().rename(sourcePath, destinationPath)
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e.toRemoteException(sourcePath))
            }
        }

    override suspend fun copy(
        sourcePath: String,
        destinationPath: String,
        isDirectory: Boolean,
        onProgress: (transferred: Long, total: Long) -> Unit
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (isDirectory) {
                return@withContext Result.failure(
                    UnsupportedOperationException("Directory copy is not supported for SFTP in this build")
                )
            }
            val c = requireSftp()
            val tmp = File.createTempFile("adjdev_copy_", ".tmp")
            try {
                c.get(sourcePath, tmp.absolutePath)
                c.put(tmp.absolutePath, destinationPath)
            } finally {
                tmp.delete()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(sourcePath))
        }
    }

    override suspend fun download(
        remotePath: String,
        localFile: File,
        onProgress: (transferred: Long, total: Long) -> Unit,
        isPaused: () -> Boolean,
        isCancelled: () -> Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireSftp()
            val remoteAttrs = c.stat(remotePath)
            val total = remoteAttrs.size
            val handle = c.open(remotePath, EnumSet.of(OpenMode.READ))
            handle.use { h ->
                java.io.BufferedOutputStream(java.io.FileOutputStream(localFile)).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var offset = 0L
                    while (true) {
                        if (isCancelled()) throw RemoteException.Cancelled()
                        while (isPaused()) {
                            if (isCancelled()) throw RemoteException.Cancelled()
                            Thread.sleep(200)
                        }
                        val read = h.read(offset, buffer, 0, buffer.size)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        offset += read
                        onProgress(offset, total)
                    }
                    output.flush()
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(remotePath))
        }
    }

    override suspend fun upload(
        localFile: File,
        remotePath: String,
        onProgress: (transferred: Long, total: Long) -> Unit,
        isPaused: () -> Boolean,
        isCancelled: () -> Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val c = requireSftp()
            val total = localFile.length()
            val handle = c.open(
                remotePath,
                EnumSet.of(OpenMode.CREAT, OpenMode.WRITE, OpenMode.TRUNC)
            )
            handle.use { h ->
                java.io.BufferedInputStream(java.io.FileInputStream(localFile)).use { input ->
                    val buffer = ByteArray(64 * 1024)
                    var offset = 0L
                    while (true) {
                        if (isCancelled()) throw RemoteException.Cancelled()
                        while (isPaused()) {
                            if (isCancelled()) throw RemoteException.Cancelled()
                            Thread.sleep(200)
                        }
                        val read = input.read(buffer)
                        if (read == -1) break
                        h.write(offset, buffer, 0, read)
                        offset += read
                        onProgress(offset, total)
                    }
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(remotePath))
        }
    }

    override suspend fun exists(path: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val c = requireSftp()
            Result.success(c.statExistence(path) != null)
        } catch (e: Exception) {
            Result.success(false)
        }
    }

    override suspend fun getFileSize(path: String): Result<Long> = withContext(Dispatchers.IO) {
        try {
            Result.success(requireSftp().stat(path).size)
        } catch (e: Exception) {
            Result.failure(e.toRemoteException(path))
        }
    }

    override suspend fun getConnectionInfo(): ConnectionInfo {
        val cfg = config
        return ConnectionInfo(
            host = cfg?.host.orEmpty(),
            port = cfg?.port ?: 0,
            protocol = Protocol.SFTP,
            isEncrypted = true,
            isConnected = isConnected(),
            serverGreeting = ssh?.transport?.serverVersion,
            log = synchronized(log) { log.toList() }
        )
    }

    private fun Exception.toRemoteException(path: String? = null): Throwable = when (this) {
        is RemoteException -> this
        is SFTPException -> when (statusCode) {
            Response.StatusCode.NO_SUCH_FILE -> RemoteException.FileNotFound(path, this)
            Response.StatusCode.PERMISSION_DENIED -> RemoteException.PermissionDenied(path, this)
            else -> RemoteException.SftpError(message ?: "SFTP error", this)
        }
        is SocketTimeoutException -> RemoteException.TimeoutError(this)
        is TransportException -> RemoteException.ConnectionLost(this)
        else -> RemoteException.Unknown(this)
    }
}
