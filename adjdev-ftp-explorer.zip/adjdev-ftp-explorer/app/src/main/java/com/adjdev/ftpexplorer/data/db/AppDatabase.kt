package com.adjdev.ftpexplorer.data.db

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [ServerEntity::class, BookmarkEntity::class, TransferHistoryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun serverDao(): ServerDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun transferHistoryDao(): TransferHistoryDao
}
