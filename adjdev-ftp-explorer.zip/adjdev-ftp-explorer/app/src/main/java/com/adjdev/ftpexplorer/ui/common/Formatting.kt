package com.adjdev.ftpexplorer.ui.common

import java.text.DateFormat
import java.util.Date
import kotlin.math.ln
import kotlin.math.pow

fun formatBytes(bytes: Long): String {
    if (bytes < 0) return "-"
    if (bytes < 1024) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    val exp = (ln(bytes.toDouble()) / ln(1024.0)).toInt().coerceIn(1, units.size)
    val value = bytes / 1024.0.pow(exp.toDouble())
    return String.format("%.1f %s", value, units[exp - 1])
}

fun formatSpeed(bytesPerSec: Long): String = if (bytesPerSec <= 0) "-" else "${formatBytes(bytesPerSec)}/s"

fun formatEta(seconds: Long?): String {
    if (seconds == null || seconds <= 0) return "-"
    val m = seconds / 60
    val s = seconds % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}

fun formatDate(timestampMillis: Long): String {
    if (timestampMillis <= 0) return "-"
    return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(timestampMillis))
}
