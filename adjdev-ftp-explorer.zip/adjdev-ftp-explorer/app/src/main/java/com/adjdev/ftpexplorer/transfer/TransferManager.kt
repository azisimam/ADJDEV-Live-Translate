package com.adjdev.ftpexplorer.transfer

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.adjdev.ftpexplorer.data.db.TransferHistoryEntity
import com.adjdev.ftpexplorer.data.repository.RemoteSessionManager
import com.adjdev.ftpexplorer.data.repository.SettingsRepository
import com.adjdev.ftpexplorer.data.repository.TransferHistoryRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import javax.inject.Inject
import javax.inject.Singleton

private class TransferControl {
    val paused = AtomicBoolean(false)
    val cancelled = AtomicBoolean(false)
    var job: Job? = null
}

/**
 * Owns the upload/download queue, drives progress via [transfers], and persists completed
 * transfers to history. Runs on an application-scoped coroutine scope so transfers survive
 * screen rotation and backgrounding; [TransferService] keeps the process alive with a
 * foreground notification while anything is queued or running.
 */
@Singleton
class TransferManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sessionManager: RemoteSessionManager,
    private val settingsRepository: SettingsRepository,
    private val historyRepository: TransferHistoryRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var semaphore = Semaphore(2)
    private val controls = mutableMapOf<String, TransferControl>()

    private val _transfers = MutableStateFlow<List<TransferItem>>(emptyList())
    val transfers: StateFlow<List<TransferItem>> = _transfers

    fun enqueueDownload(serverId: String, serverName: String, remotePath: String, fileName: String, localDestDir: File, totalBytes: Long): String {
        val localPath = File(localDestDir, fileName).absolutePath
        val item = TransferItem(
            serverId = serverId, serverName = serverName, type = TransferType.DOWNLOAD,
            remotePath = remotePath, localPath = localPath, fileName = fileName, totalBytes = totalBytes
        )
        enqueue(item)
        return item.id
    }

    fun enqueueUpload(serverId: String, serverName: String, localFile: File, remoteDir: String): String {
        val remotePath = if (remoteDir.endsWith("/")) "$remoteDir${localFile.name}" else "$remoteDir/${localFile.name}"
        val item = TransferItem(
            serverId = serverId, serverName = serverName, type = TransferType.UPLOAD,
            remotePath = remotePath, localPath = localFile.absolutePath, fileName = localFile.name,
            totalBytes = localFile.length()
        )
        enqueue(item)
        return item.id
    }

    private fun enqueue(item: TransferItem) {
        controls[item.id] = TransferControl()
        _transfers.update { it + item }
        ensureServiceStarted()
        val job = scope.launch {
            val concurrency = settingsRepository.settings.first().transferConcurrency.coerceIn(1, 6)
            semaphore = Semaphore(concurrency)
            semaphore.withPermit { runTransfer(item.id) }
        }
        controls[item.id]?.job = job
    }

    private suspend fun runTransfer(id: String) {
        val settings = settingsRepository.settings.first()
        var attempt = 0
        var lastError: String? = null
        val maxAttempts = if (settings.autoRetry) settings.maxRetryCount + 1 else 1

        while (attempt < maxAttempts) {
            val control = controls[id] ?: return
            if (control.cancelled.get()) {
                updateItem(id) { it.copy(state = TransferState.CANCELLED) }
                finalizeHistory(id)
                return
            }
            updateItem(id) { it.copy(state = TransferState.RUNNING, errorMessage = null, retryCount = attempt) }
            val item = currentItem(id) ?: return

            val sessionResult = sessionManager.getOrConnect(item.serverId)
            val fs = sessionResult.getOrNull()
            if (fs == null) {
                lastError = sessionResult.exceptionOrNull()?.message ?: "Connection failed"
                attempt++
                continue
            }

            var lastBytes = 0L
            var lastTimestamp = System.currentTimeMillis()

            val onProgress: (Long, Long) -> Unit = onProgress@{ transferred, total ->
                val now = System.currentTimeMillis()
                val elapsedMs = (now - lastTimestamp).coerceAtLeast(1)
                val deltaBytes = (transferred - lastBytes).coerceAtLeast(0)
                val speed = (deltaBytes * 1000L) / elapsedMs
                val remaining = (total - transferred).coerceAtLeast(0)
                val eta = if (speed > 0) remaining / speed else null
                lastBytes = transferred
                lastTimestamp = now
                updateItem(id) {
                    it.copy(
                        transferredBytes = transferred,
                        totalBytes = if (total > 0) total else it.totalBytes,
                        speedBytesPerSec = speed,
                        etaSeconds = eta
                    )
                }
            }

            val result = try {
                if (item.type == TransferType.DOWNLOAD) {
                    fs.download(
                        item.remotePath, File(item.localPath), onProgress,
                        isPaused = { control.paused.get() }, isCancelled = { control.cancelled.get() }
                    )
                } else {
                    fs.upload(
                        File(item.localPath), item.remotePath, onProgress,
                        isPaused = { control.paused.get() }, isCancelled = { control.cancelled.get() }
                    )
                }
            } catch (e: Exception) {
                Result.failure(e)
            }

            if (result.isSuccess) {
                updateItem(id) { it.copy(state = TransferState.COMPLETED, transferredBytes = it.totalBytes) }
                finalizeHistory(id)
                maybeStopService()
                return
            }

            val error = result.exceptionOrNull()
            if (error is com.adjdev.ftpexplorer.data.remote.RemoteException.Cancelled || control.cancelled.get()) {
                updateItem(id) { it.copy(state = TransferState.CANCELLED) }
                finalizeHistory(id)
                maybeStopService()
                return
            }
            lastError = error?.message ?: "Transfer failed"
            attempt++
        }

        updateItem(id) { it.copy(state = TransferState.FAILED, errorMessage = lastError) }
        finalizeHistory(id)
        maybeStopService()
    }

    private fun currentItem(id: String) = _transfers.value.find { it.id == id }

    private fun updateItem(id: String, transform: (TransferItem) -> TransferItem) {
        _transfers.update { list -> list.map { if (it.id == id) transform(it) else it } }
    }

    private suspend fun finalizeHistory(id: String) {
        val item = currentItem(id) ?: return
        historyRepository.record(
            TransferHistoryEntity(
                id = item.id,
                serverId = item.serverId,
                serverName = item.serverName,
                type = item.type.name,
                fileName = item.fileName,
                remotePath = item.remotePath,
                localPath = item.localPath,
                totalBytes = item.totalBytes,
                finalState = item.state.name,
                errorMessage = item.errorMessage,
                startedAt = item.createdAt,
                finishedAt = System.currentTimeMillis()
            )
        )
    }

    fun pause(id: String) {
        controls[id]?.paused?.set(true)
        updateItem(id) { it.copy(state = TransferState.PAUSED) }
    }

    fun resume(id: String) {
        val control = controls[id] ?: return
        if (control.job?.isActive == true) {
            control.paused.set(false)
            updateItem(id) { it.copy(state = TransferState.RUNNING) }
        } else {
            // job already finished/failed - relaunch
            retry(id)
        }
    }

    fun cancel(id: String) {
        controls[id]?.cancelled?.set(true)
        controls[id]?.paused?.set(false)
    }

    fun retry(id: String) {
        val item = currentItem(id) ?: return
        controls[id] = TransferControl()
        val job = scope.launch { runTransfer(id) }
        controls[id]?.job = job
        updateItem(id) { it.copy(state = TransferState.QUEUED, errorMessage = null) }
    }

    fun remove(id: String) {
        controls[id]?.cancelled?.set(true)
        controls.remove(id)
        _transfers.update { list -> list.filterNot { it.id == id } }
    }

    fun clearCompleted() {
        _transfers.update { list -> list.filterNot { it.state == TransferState.COMPLETED || it.state == TransferState.CANCELLED } }
    }

    fun activeCount(): Int = _transfers.value.count {
        it.state == TransferState.RUNNING || it.state == TransferState.QUEUED || it.state == TransferState.PAUSED
    }

    private fun ensureServiceStarted() {
        val intent = Intent(context, TransferService::class.java)
        ContextCompat.startForegroundService(context, intent)
    }

    private fun maybeStopService() {
        if (activeCount() == 0) {
            context.stopService(Intent(context, TransferService::class.java))
        }
    }
}
