package com.adjdev.ftpexplorer.data.repository

import com.adjdev.ftpexplorer.data.remote.Protocol
import com.adjdev.ftpexplorer.data.remote.TlsMode

/** UI/domain-facing server model. Password is only decrypted transiently when connecting. */
data class Server(
    val id: String,
    val name: String,
    val host: String,
    val port: Int,
    val username: String,
    val protocol: Protocol,
    val passiveMode: Boolean,
    val tlsMode: TlsMode,
    val timeoutSeconds: Int,
    val defaultRemoteDir: String,
    val isFavorite: Boolean,
    val lastConnectedAt: Long?
)

/** Draft used by the add/edit server form; carries the raw password before it's encrypted. */
data class ServerDraft(
    val id: String? = null,
    val name: String = "",
    val host: String = "",
    val port: Int = 21,
    val username: String = "",
    val password: String = "",
    val protocol: Protocol = Protocol.FTP,
    val passiveMode: Boolean = true,
    val tlsMode: TlsMode = TlsMode.NONE,
    val timeoutSeconds: Int = 30,
    val defaultRemoteDir: String = "/",
    val isFavorite: Boolean = false
)
