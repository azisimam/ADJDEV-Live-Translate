package com.adjdev.ftpexplorer.data.remote

/** Runtime connection parameters resolved from a saved server (password already decrypted). */
data class ConnectionConfig(
    val serverId: String,
    val name: String,
    val host: String,
    val port: Int,
    val username: String,
    val password: String,
    val protocol: Protocol,
    val passiveMode: Boolean,
    val tlsMode: TlsMode,
    val timeoutSeconds: Int,
    val defaultRemoteDir: String
)

/** Live status of a connection info page. */
data class ConnectionInfo(
    val host: String,
    val port: Int,
    val protocol: Protocol,
    val isEncrypted: Boolean,
    val isConnected: Boolean,
    val latencyMs: Long? = null,
    val serverGreeting: String? = null,
    val log: List<String> = emptyList()
)
