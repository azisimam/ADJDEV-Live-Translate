package com.adjdev.ftpexplorer.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transfer_history")
data class TransferHistoryEntity(
    @PrimaryKey val id: String,
    val serverId: String,
    val serverName: String,
    val type: String, // UPLOAD / DOWNLOAD
    val fileName: String,
    val remotePath: String,
    val localPath: String,
    val totalBytes: Long,
    val finalState: String, // COMPLETED / FAILED / CANCELLED
    val errorMessage: String? = null,
    val startedAt: Long,
    val finishedAt: Long
)
