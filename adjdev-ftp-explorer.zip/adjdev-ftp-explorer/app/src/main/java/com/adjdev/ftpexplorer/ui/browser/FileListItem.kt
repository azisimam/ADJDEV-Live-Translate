package com.adjdev.ftpexplorer.ui.browser

import androidx.compose.foundation.ExperimentalFoundationApi

import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.adjdev.ftpexplorer.data.remote.RemoteFile
import com.adjdev.ftpexplorer.ui.common.formatBytes
import com.adjdev.ftpexplorer.ui.common.formatDate

private val imageExts = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")
private val codeExts = setOf("kt", "java", "js", "ts", "py", "c", "cpp", "h", "json", "xml", "html", "css", "sh", "gradle", "yml", "yaml")
private val textExts = setOf("txt", "md", "log", "ini", "conf")

private fun iconFor(file: RemoteFile): ImageVector = when {
    file.isDirectory -> Icons.Filled.Folder
    file.isSymlink -> Icons.Filled.Link
    file.extension.lowercase() in imageExts -> Icons.Filled.Image
    file.extension.lowercase() == "pdf" -> Icons.Filled.PictureAsPdf
    file.extension.lowercase() in codeExts -> Icons.Filled.Code
    file.extension.lowercase() in textExts -> Icons.Filled.Description
    else -> Icons.Filled.InsertDriveFile
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileListItem(
    file: RemoteFile,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isSelectionMode) {
            Checkbox(checked = isSelected, onCheckedChange = { onClick() })
        }
        Icon(
            iconFor(file),
            contentDescription = null,
            tint = if (file.isDirectory) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(end = 12.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(file.name, fontWeight = FontWeight.Medium, maxLines = 1)
            val meta = if (file.isDirectory) formatDate(file.lastModified) else "${formatBytes(file.size)} · ${formatDate(file.lastModified)}"
            Text(meta, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}
