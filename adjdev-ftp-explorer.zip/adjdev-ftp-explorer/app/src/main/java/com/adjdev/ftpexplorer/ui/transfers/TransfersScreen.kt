package com.adjdev.ftpexplorer.ui.transfers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.adjdev.ftpexplorer.data.db.TransferHistoryEntity
import com.adjdev.ftpexplorer.transfer.TransferItem
import com.adjdev.ftpexplorer.transfer.TransferState
import com.adjdev.ftpexplorer.transfer.TransferType
import com.adjdev.ftpexplorer.ui.common.AdjdevBottomNavBar
import com.adjdev.ftpexplorer.ui.common.EmptyState
import com.adjdev.ftpexplorer.ui.common.formatBytes
import com.adjdev.ftpexplorer.ui.common.formatDate
import com.adjdev.ftpexplorer.ui.common.formatEta
import com.adjdev.ftpexplorer.ui.common.formatSpeed

@Composable
fun TransfersScreen(
    navController: NavHostController,
    viewModel: TransfersViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var tabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf("Active", "History", "Failed")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Transfers") },
                actions = {
                    if (tabIndex == 0) {
                        TextButton(onClick = viewModel::clearCompleted) { Text("Clear finished") }
                    } else if (tabIndex == 1) {
                        TextButton(onClick = viewModel::clearHistory) { Text("Clear history") }
                    }
                }
            )
        },
        bottomBar = { AdjdevBottomNavBar(navController) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            TabRow(selectedTabIndex = tabIndex) {
                tabs.forEachIndexed { index, title ->
                    Tab(selected = tabIndex == index, onClick = { tabIndex = index }, text = { Text(title) })
                }
            }

            when (tabIndex) {
                0 -> ActiveTransfersList(state.active, viewModel)
                1 -> HistoryList(state.history)
                2 -> HistoryList(state.failedHistory)
            }
        }
    }
}

@Composable
private fun ActiveTransfersList(items: List<TransferItem>, viewModel: TransfersViewModel) {
    if (items.isEmpty()) {
        EmptyState(title = "No active transfers", subtitle = "Uploads and downloads will appear here.")
        return
    }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items, key = { it.id }) { item -> TransferCard(item, viewModel) }
    }
}

@Composable
private fun TransferCard(item: TransferItem, viewModel: TransfersViewModel) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Text(
                    (if (item.type == TransferType.UPLOAD) "⬆ " else "⬇ ") + item.fileName,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.weight(1f),
                    maxLines = 1
                )
                when (item.state) {
                    TransferState.RUNNING -> IconButton(onClick = { viewModel.pause(item.id) }) { Icon(Icons.Filled.Pause, contentDescription = "Pause") }
                    TransferState.PAUSED -> IconButton(onClick = { viewModel.resume(item.id) }) { Icon(Icons.Filled.PlayArrow, contentDescription = "Resume") }
                    TransferState.FAILED -> IconButton(onClick = { viewModel.retry(item.id) }) { Icon(Icons.Filled.Replay, contentDescription = "Retry") }
                    else -> {}
                }
                if (item.state == TransferState.RUNNING || item.state == TransferState.PAUSED || item.state == TransferState.QUEUED) {
                    IconButton(onClick = { viewModel.cancel(item.id) }) { Icon(Icons.Filled.Cancel, contentDescription = "Cancel") }
                } else {
                    IconButton(onClick = { viewModel.remove(item.id) }) { Icon(Icons.Filled.Close, contentDescription = "Remove") }
                }
            }
            Text(item.serverName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

            when (item.state) {
                TransferState.RUNNING, TransferState.PAUSED -> {
                    LinearProgressIndicator(progress = { item.progressFraction }, modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("${formatBytes(item.transferredBytes)} / ${formatBytes(item.totalBytes)}", style = MaterialTheme.typography.labelSmall)
                        Text(
                            if (item.state == TransferState.PAUSED) "Paused" else "${formatSpeed(item.speedBytesPerSec)} · ETA ${formatEta(item.etaSeconds)}",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
                TransferState.QUEUED -> Text("Queued", style = MaterialTheme.typography.labelSmall)
                TransferState.COMPLETED -> StatusRow(Icons.Filled.CheckCircle, "Completed", MaterialTheme.colorScheme.primary)
                TransferState.FAILED -> StatusRow(Icons.Filled.Error, item.errorMessage ?: "Failed", MaterialTheme.colorScheme.error)
                TransferState.CANCELLED -> StatusRow(Icons.Filled.Cancel, "Cancelled", MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun StatusRow(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String, color: androidx.compose.ui.graphics.Color) {
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
        Icon(icon, contentDescription = null, tint = color, modifier = Modifier.padding(end = 6.dp))
        Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun HistoryList(items: List<TransferHistoryEntity>) {
    if (items.isEmpty()) {
        EmptyState(title = "Nothing here yet")
        return
    }
    LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items, key = { it.id }) { entry ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row {
                        Text(
                            (if (entry.type == "UPLOAD") "⬆ " else "⬇ ") + entry.fileName,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f),
                            maxLines = 1
                        )
                        Text(entry.finalState, color = when (entry.finalState) {
                            "COMPLETED" -> MaterialTheme.colorScheme.primary
                            "FAILED" -> MaterialTheme.colorScheme.error
                            else -> MaterialTheme.colorScheme.onSurfaceVariant
                        }, style = MaterialTheme.typography.labelSmall)
                    }
                    Text(entry.serverName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("${formatBytes(entry.totalBytes)} · ${formatDate(entry.finishedAt)}", style = MaterialTheme.typography.labelSmall)
                    entry.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall) }
                }
            }
        }
    }
}
