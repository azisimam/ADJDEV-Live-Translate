package com.adjdev.ftpexplorer.ui.viewer

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.adjdev.ftpexplorer.ui.common.ErrorBanner
import com.adjdev.ftpexplorer.ui.common.LoadingBox

@Composable
fun TextViewerScreen(
    onBack: () -> Unit,
    onEdit: () -> Unit,
    viewModel: ViewerViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var content by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(state.localFile) {
        state.localFile?.let { file ->
            content = runCatching { file.readText() }.getOrElse { "Could not read file: ${it.message}" }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(state.fileName) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Back") } },
                actions = { IconButton(onClick = onEdit) { Icon(Icons.Filled.Edit, contentDescription = "Edit") } }
            )
        }
    ) { padding ->
        when {
            state.isLoading -> LoadingBox(modifier = Modifier
                .padding(padding)
                .fillMaxSize())
            state.error != null -> ErrorBanner(state.error!!, modifier = Modifier.padding(padding))
            content != null -> SelectionContainer {
                Text(
                    content!!,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .padding(padding)
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp)
                )
            }
        }
    }
}
