package com.adjdev.ftpexplorer.ui.viewer

import android.content.Context
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.repository.RemoteSessionManager
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

data class TextEditorUiState(
    val fileName: String = "",
    val content: String = "",
    val isLoading: Boolean = true,
    val isSaving: Boolean = false,
    val isDirty: Boolean = false,
    val error: String? = null,
    val saveSuccess: Boolean = false
)

@HiltViewModel
class TextEditorViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val sessionManager: RemoteSessionManager,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val serverId: String = checkNotNull(savedStateHandle["serverId"])
    private val remotePath: String = checkNotNull(savedStateHandle["path"])
    private val isLocal: Boolean = savedStateHandle.get<String>("local")?.toBoolean() ?: false

    private var localCacheFile: File? = null

    private val _uiState = MutableStateFlow(TextEditorUiState(fileName = remotePath.substringAfterLast('/')))
    val uiState: StateFlow<TextEditorUiState> = _uiState.asStateFlow()

    init {
        load()
    }

    private fun load() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            val file: File
            if (isLocal) {
                file = File(remotePath)
            } else {
                val fsResult = sessionManager.getOrConnect(serverId)
                val fs = fsResult.getOrNull()
                if (fs == null) {
                    _uiState.update { it.copy(isLoading = false, error = fsResult.exceptionOrNull()?.message ?: "Connection failed") }
                    return@launch
                }
                val cacheFile = File(context.cacheDir, "edit_${serverId}_${remotePath.hashCode()}_${remotePath.substringAfterLast('/')}")
                val result = fs.download(remotePath, cacheFile, { _, _ -> })
                if (result.isFailure) {
                    _uiState.update { it.copy(isLoading = false, error = result.exceptionOrNull()?.message ?: "Could not load file") }
                    return@launch
                }
                file = cacheFile
            }
            localCacheFile = file
            val text = withContext(Dispatchers.IO) { runCatching { file.readText() }.getOrElse { "" } }
            _uiState.update { it.copy(isLoading = false, content = text) }
        }
    }

    fun onContentChange(newContent: String) {
        _uiState.update { it.copy(content = newContent, isDirty = true, saveSuccess = false) }
    }

    fun save() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, error = null) }
            val file = localCacheFile ?: File(context.cacheDir, "edit_new_${System.currentTimeMillis()}.txt").also { localCacheFile = it }
            withContext(Dispatchers.IO) { file.writeText(_uiState.value.content) }

            if (isLocal) {
                _uiState.update { it.copy(isSaving = false, isDirty = false, saveSuccess = true) }
                return@launch
            }

            val fs = sessionManager.activeSession(serverId)
            if (fs == null) {
                _uiState.update { it.copy(isSaving = false, error = "Not connected") }
                return@launch
            }
            val result = fs.upload(file, remotePath, { _, _ -> })
            if (result.isSuccess) {
                _uiState.update { it.copy(isSaving = false, isDirty = false, saveSuccess = true) }
            } else {
                _uiState.update { it.copy(isSaving = false, error = result.exceptionOrNull()?.message ?: "Upload failed") }
            }
        }
    }

    fun saveAs(newFileName: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true, error = null) }
            val newRemotePath = remotePath.substringBeforeLast('/', "") + "/" + newFileName
            val file = File(context.cacheDir, "edit_saveas_${System.currentTimeMillis()}_$newFileName")
            withContext(Dispatchers.IO) { file.writeText(_uiState.value.content) }
            if (isLocal) {
                val destination = File(File(remotePath).parentFile, newFileName)
                withContext(Dispatchers.IO) { file.copyTo(destination, overwrite = true) }
                _uiState.update { it.copy(isSaving = false, isDirty = false, saveSuccess = true) }
                return@launch
            }
            val fs = sessionManager.activeSession(serverId)
            if (fs == null) {
                _uiState.update { it.copy(isSaving = false, error = "Not connected") }
                return@launch
            }
            val result = fs.upload(file, newRemotePath, { _, _ -> })
            _uiState.update {
                if (result.isSuccess) it.copy(isSaving = false, isDirty = false, saveSuccess = true)
                else it.copy(isSaving = false, error = result.exceptionOrNull()?.message ?: "Upload failed")
            }
        }
    }
}
