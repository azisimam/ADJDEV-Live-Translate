package com.adjdev.ftpexplorer.ui.servers

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.repository.Server
import com.adjdev.ftpexplorer.data.repository.ServerRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class ServerListUiState(
    val servers: List<Server> = emptyList(),
    val searchQuery: String = ""
)

@HiltViewModel
class ServerListViewModel @Inject constructor(
    private val serverRepository: ServerRepository
) : ViewModel() {

    private val searchQuery = MutableStateFlow("")

    val uiState: StateFlow<ServerListUiState> = combine(
        serverRepository.observeServers(), searchQuery
    ) { servers, query ->
        val filtered = if (query.isBlank()) servers else servers.filter {
            it.name.contains(query, ignoreCase = true) || it.host.contains(query, ignoreCase = true)
        }
        ServerListUiState(servers = filtered, searchQuery = query)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ServerListUiState())

    fun onSearchQueryChange(query: String) {
        searchQuery.value = query
    }

    fun toggleFavorite(server: Server) {
        viewModelScope.launch { serverRepository.setFavorite(server.id, !server.isFavorite) }
    }

    fun deleteServer(server: Server) {
        viewModelScope.launch { serverRepository.deleteServer(server) }
    }
}
