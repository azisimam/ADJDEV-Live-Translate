package com.adjdev.ftpexplorer.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.adjdev.ftpexplorer.data.remote.RemoteFile
import com.adjdev.ftpexplorer.data.repository.Server
import com.adjdev.ftpexplorer.ui.browser.FileBrowserScreen
import com.adjdev.ftpexplorer.ui.browser.LocalPickerScreen
import com.adjdev.ftpexplorer.ui.connectioninfo.ConnectionInfoScreen
import com.adjdev.ftpexplorer.ui.home.HomeScreen
import com.adjdev.ftpexplorer.ui.search.SearchScreen
import com.adjdev.ftpexplorer.ui.servers.AddEditServerScreen
import com.adjdev.ftpexplorer.ui.servers.ServerListScreen
import com.adjdev.ftpexplorer.ui.settings.SettingsScreen
import com.adjdev.ftpexplorer.ui.transfers.TransfersScreen
import com.adjdev.ftpexplorer.ui.viewer.ImageViewerScreen
import com.adjdev.ftpexplorer.ui.viewer.PdfViewerScreen
import com.adjdev.ftpexplorer.ui.viewer.TextEditorScreen
import com.adjdev.ftpexplorer.ui.viewer.TextViewerScreen
import java.io.File

@Composable
fun AdjdevNavGraph() {
    val navController = rememberNavController()

    // Simple in-memory "activity result"-style bridge for the local file/folder picker,
    // since it is used from several call sites (upload from browser, download destination, etc).
    var pendingFilesCallback by remember { mutableStateOf<((List<File>) -> Unit)?>(null) }
    var pendingFolderCallback by remember { mutableStateOf<((File) -> Unit)?>(null) }

    fun openUploadPicker(onPicked: (List<File>) -> Unit) {
        pendingFilesCallback = onPicked
        navController.navigate(Screen.LocalPicker.create("upload"))
    }

    fun openDownloadPicker(onPicked: (File) -> Unit) {
        pendingFolderCallback = onPicked
        navController.navigate(Screen.LocalPicker.create("download"))
    }

    NavHost(navController = navController, startDestination = Screen.Home.route) {

        composable(Screen.Home.route) {
            HomeScreen(
                navController = navController,
                onOpenServer = { server: Server -> navController.navigate(Screen.FileBrowser.create(server.id, server.defaultRemoteDir)) },
                onAddServer = { navController.navigate(Screen.AddEditServer.create()) }
            )
        }

        composable(Screen.ServerList.route) {
            ServerListScreen(
                navController = navController,
                onOpenServer = { server -> navController.navigate(Screen.FileBrowser.create(server.id, server.defaultRemoteDir)) },
                onEditServer = { server -> navController.navigate(Screen.AddEditServer.create(server.id)) },
                onAddServer = { navController.navigate(Screen.AddEditServer.create()) }
            )
        }

        composable(
            route = Screen.AddEditServer.route,
            arguments = listOf(navArgument("serverId") { type = NavType.StringType; nullable = true; defaultValue = "" })
        ) {
            AddEditServerScreen(onBack = { navController.popBackStack() })
        }

        composable(Screen.Transfers.route) {
            TransfersScreen(navController = navController)
        }

        composable(Screen.Settings.route) {
            SettingsScreen(navController = navController)
        }

        composable(
            route = Screen.FileBrowser.route,
            arguments = listOf(
                navArgument("serverId") { type = NavType.StringType },
                navArgument("path") { type = NavType.StringType; defaultValue = "/" }
            )
        ) { backStackEntry ->
            val serverId = backStackEntry.arguments?.getString("serverId").orEmpty()
            FileBrowserScreen(
                onBack = { navController.popBackStack() },
                onOpenTextViewer = { path -> navController.navigate(Screen.TextViewer.create(serverId, path, isLocal = false)) },
                onOpenImageViewer = { path -> navController.navigate(Screen.ImageViewer.create(serverId, path, isLocal = false)) },
                onOpenPdfViewer = { path -> navController.navigate(Screen.PdfViewer.create(serverId, path, isLocal = false)) },
                onOpenTextEditor = { path -> navController.navigate(Screen.TextEditor.create(serverId, path, isLocal = false)) },
                onOpenSearch = { path -> navController.navigate(Screen.Search.create(serverId, path)) },
                onOpenConnectionInfo = { navController.navigate(Screen.ConnectionInfo.create(serverId)) },
                onPickUploadFiles = { onPicked -> openUploadPicker(onPicked) },
                onPickDownloadFolder = { onPicked -> openDownloadPicker(onPicked) }
            )
        }

        composable(
            route = Screen.Search.route,
            arguments = listOf(
                navArgument("serverId") { type = NavType.StringType },
                navArgument("path") { type = NavType.StringType; defaultValue = "/" }
            )
        ) { backStackEntry ->
            val serverId = backStackEntry.arguments?.getString("serverId").orEmpty()
            SearchScreen(
                onBack = { navController.popBackStack() },
                onOpenResult = { file: RemoteFile ->
                    if (file.isDirectory) {
                        navController.navigate(Screen.FileBrowser.create(serverId, file.path)) {
                            popUpTo(Screen.FileBrowser.route) { inclusive = true }
                        }
                    } else {
                        navController.navigate(Screen.TextViewer.create(serverId, file.path, isLocal = false))
                    }
                }
            )
        }

        composable(
            route = Screen.ConnectionInfo.route,
            arguments = listOf(navArgument("serverId") { type = NavType.StringType })
        ) {
            ConnectionInfoScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Screen.TextViewer.route,
            arguments = listOf(
                navArgument("serverId") { type = NavType.StringType },
                navArgument("path") { type = NavType.StringType },
                navArgument("local") { type = NavType.StringType; defaultValue = "false" }
            )
        ) { backStackEntry ->
            val serverId = backStackEntry.arguments?.getString("serverId").orEmpty()
            val path = backStackEntry.arguments?.getString("path").orEmpty()
            val local = backStackEntry.arguments?.getString("local") ?: "false"
            TextViewerScreen(
                onBack = { navController.popBackStack() },
                onEdit = { navController.navigate(Screen.TextEditor.create(serverId, path, local.toBoolean())) }
            )
        }

        composable(
            route = Screen.ImageViewer.route,
            arguments = listOf(
                navArgument("serverId") { type = NavType.StringType },
                navArgument("path") { type = NavType.StringType },
                navArgument("local") { type = NavType.StringType; defaultValue = "false" }
            )
        ) {
            ImageViewerScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Screen.PdfViewer.route,
            arguments = listOf(
                navArgument("serverId") { type = NavType.StringType },
                navArgument("path") { type = NavType.StringType },
                navArgument("local") { type = NavType.StringType; defaultValue = "false" }
            )
        ) {
            PdfViewerScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Screen.TextEditor.route,
            arguments = listOf(
                navArgument("serverId") { type = NavType.StringType },
                navArgument("path") { type = NavType.StringType },
                navArgument("local") { type = NavType.StringType; defaultValue = "false" }
            )
        ) {
            TextEditorScreen(onBack = { navController.popBackStack() })
        }

        composable(
            route = Screen.LocalPicker.route,
            arguments = listOf(navArgument("mode") { type = NavType.StringType; defaultValue = "upload" })
        ) { backStackEntry ->
            val mode = backStackEntry.arguments?.getString("mode") ?: "upload"
            LocalPickerScreen(
                mode = mode,
                onPickFiles = { files ->
                    pendingFilesCallback?.invoke(files)
                    pendingFilesCallback = null
                    navController.popBackStack()
                },
                onPickFolder = { folder ->
                    pendingFolderCallback?.invoke(folder)
                    pendingFolderCallback = null
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}
