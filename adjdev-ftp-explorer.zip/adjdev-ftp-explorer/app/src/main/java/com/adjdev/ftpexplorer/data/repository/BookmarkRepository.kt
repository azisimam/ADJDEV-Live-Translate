package com.adjdev.ftpexplorer.data.repository

import com.adjdev.ftpexplorer.data.db.BookmarkDao
import com.adjdev.ftpexplorer.data.db.BookmarkEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BookmarkRepository @Inject constructor(private val dao: BookmarkDao) {
    fun observeForServer(serverId: String): Flow<List<BookmarkEntity>> = dao.observeForServer(serverId)

    suspend fun addBookmark(serverId: String, path: String, label: String) =
        dao.insert(BookmarkEntity(serverId = serverId, path = path, label = label))

    suspend fun removeBookmark(bookmark: BookmarkEntity) = dao.delete(bookmark)
}
