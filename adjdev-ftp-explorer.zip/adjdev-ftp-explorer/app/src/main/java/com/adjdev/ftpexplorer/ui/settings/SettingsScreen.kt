package com.adjdev.ftpexplorer.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Divider
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.adjdev.ftpexplorer.BuildConfig
import com.adjdev.ftpexplorer.data.repository.AppTheme
import com.adjdev.ftpexplorer.ui.browser.TextInputDialog
import com.adjdev.ftpexplorer.ui.common.AdjdevBottomNavBar
import com.adjdev.ftpexplorer.ui.common.ConfirmDialog

@Composable
fun SettingsScreen(
    navController: NavHostController,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsState()
    var showClearHistoryConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Settings") }) },
        bottomBar = { AdjdevBottomNavBar(navController) }
    ) { padding ->
        Column(modifier = Modifier
            .padding(padding)
            .verticalScroll(rememberScrollState())) {

            SectionHeader("Appearance")
            ListItem(headlineContent = { Text("Theme") }, supportingContent = { Text(settings.theme.name) })
            Row(modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)) {
                AppTheme.entries.forEach { theme ->
                    TextButton(onClick = { viewModel.setTheme(theme) }) {
                        Text(theme.name, color = if (settings.theme == theme) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            Divider()
            SectionHeader("Transfers")
            SwitchRow("Overwrite existing files on upload", settings.overwriteOnUpload, viewModel::setOverwriteOnUpload)
            ListItem(
                headlineContent = { Text("Concurrent transfers: ${settings.transferConcurrency}") },
                supportingContent = {
                    Slider(
                        value = settings.transferConcurrency.toFloat(),
                        onValueChange = { viewModel.setTransferConcurrency(it.toInt()) },
                        valueRange = 1f..6f,
                        steps = 4
                    )
                }
            )
            SwitchRow("Auto retry on failure", settings.autoRetry, viewModel::setAutoRetry)
            if (settings.autoRetry) {
                ListItem(
                    headlineContent = { Text("Max retry attempts: ${settings.maxRetryCount}") },
                    supportingContent = {
                        Slider(
                            value = settings.maxRetryCount.toFloat(),
                            onValueChange = { viewModel.setMaxRetryCount(it.toInt()) },
                            valueRange = 0f..10f,
                            steps = 9
                        )
                    }
                )
            }
            ListItem(
                headlineContent = { Text("Connection timeout: ${settings.defaultTimeoutSeconds}s") },
                supportingContent = {
                    Slider(
                        value = settings.defaultTimeoutSeconds.toFloat(),
                        onValueChange = { viewModel.setDefaultTimeout(it.toInt()) },
                        valueRange = 5f..120f
                    )
                }
            )
            SwitchRow("Transfer notifications", settings.transferNotificationsEnabled, viewModel::setTransferNotifications)

            Divider()
            SectionHeader("File Browser")
            SwitchRow("Show hidden files", settings.showHiddenFiles, viewModel::setShowHiddenFiles)
            SwitchRow("Confirm before delete", settings.confirmBeforeDelete, viewModel::setConfirmBeforeDelete)

            Divider()
            SectionHeader("Storage")
            ListItem(
                headlineContent = { Text("Clear transfer history") },
                trailingContent = { TextButton(onClick = { showClearHistoryConfirm = true }) { Text("Clear") } }
            )

            Divider()
            SectionHeader("About")
            ListItem(headlineContent = { Text("ADJDEV FTP Explorer") }, supportingContent = { Text("Version ${BuildConfig.VERSION_NAME}") })
            ListItem(
                headlineContent = { Text("Open source libraries") },
                supportingContent = { Text("Apache Commons Net, sshj, Jetpack Compose, Coil, and other OSS components") }
            )
        }
    }

    if (showClearHistoryConfirm) {
        ConfirmDialog(
            title = "Clear transfer history?",
            message = "This removes the completed/failed transfer log. Active transfers are not affected.",
            confirmLabel = "Clear",
            onConfirm = { viewModel.clearTransferHistory(); showClearHistoryConfirm = false },
            onDismiss = { showClearHistoryConfirm = false }
        )
    }
}

@Composable
private fun SectionHeader(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp)
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(label) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onCheckedChange) }
    )
}
