package com.adjdev.ftpexplorer.transfer

import java.util.UUID

enum class TransferType { UPLOAD, DOWNLOAD }

enum class TransferState { QUEUED, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED }

data class TransferItem(
    val id: String = UUID.randomUUID().toString(),
    val serverId: String,
    val serverName: String,
    val type: TransferType,
    val remotePath: String,
    val localPath: String,
    val fileName: String,
    val totalBytes: Long,
    val transferredBytes: Long = 0L,
    val state: TransferState = TransferState.QUEUED,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long? = null,
    val errorMessage: String? = null,
    val retryCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    val progressFraction: Float
        get() = if (totalBytes <= 0) 0f else (transferredBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
}
