package com.adjdev.ftpexplorer.ui.servers

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.ftpexplorer.data.remote.ConnectionConfig
import com.adjdev.ftpexplorer.data.remote.Protocol
import com.adjdev.ftpexplorer.data.remote.RemoteFileSystemFactory
import com.adjdev.ftpexplorer.data.remote.TlsMode
import com.adjdev.ftpexplorer.data.repository.ServerDraft
import com.adjdev.ftpexplorer.data.repository.ServerRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class TestConnectionStatus { IDLE, TESTING, SUCCESS, FAILED }

data class AddEditServerUiState(
    val draft: ServerDraft = ServerDraft(),
    val isEditing: Boolean = false,
    val isSaving: Boolean = false,
    val testStatus: TestConnectionStatus = TestConnectionStatus.IDLE,
    val testMessage: String? = null,
    val nameError: String? = null,
    val hostError: String? = null,
    val saved: Boolean = false
)

@HiltViewModel
class AddEditServerViewModel @Inject constructor(
    private val serverRepository: ServerRepository,
    private val remoteFileSystemFactory: RemoteFileSystemFactory,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val serverId: String? = savedStateHandle.get<String>("serverId")?.takeIf { it.isNotBlank() }

    private val _uiState = MutableStateFlow(AddEditServerUiState(isEditing = serverId != null))
    val uiState: StateFlow<AddEditServerUiState> = _uiState.asStateFlow()

    init {
        if (serverId != null) {
            viewModelScope.launch {
                serverRepository.getServer(serverId)?.let { server ->
                    _uiState.update {
                        it.copy(
                            draft = ServerDraft(
                                id = server.id,
                                name = server.name,
                                host = server.host,
                                port = server.port,
                                username = server.username,
                                password = "",
                                protocol = server.protocol,
                                passiveMode = server.passiveMode,
                                tlsMode = server.tlsMode,
                                timeoutSeconds = server.timeoutSeconds,
                                defaultRemoteDir = server.defaultRemoteDir,
                                isFavorite = server.isFavorite
                            )
                        )
                    }
                }
            }
        }
    }

    fun updateDraft(transform: (ServerDraft) -> ServerDraft) {
        _uiState.update { it.copy(draft = transform(it.draft), testStatus = TestConnectionStatus.IDLE) }
    }

    fun onProtocolChange(protocol: Protocol) {
        updateDraft { it.copy(protocol = protocol, port = protocol.defaultPort) }
    }

    fun testConnection() {
        val draft = _uiState.value.draft
        if (draft.host.isBlank()) {
            _uiState.update { it.copy(testStatus = TestConnectionStatus.FAILED, testMessage = "Host is required") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(testStatus = TestConnectionStatus.TESTING, testMessage = null) }
            val fs = remoteFileSystemFactory.create(draft.protocol)
            val config = ConnectionConfig(
                serverId = draft.id ?: "test",
                name = draft.name,
                host = draft.host,
                port = draft.port,
                username = draft.username,
                password = draft.password,
                protocol = draft.protocol,
                passiveMode = draft.passiveMode,
                tlsMode = draft.tlsMode,
                timeoutSeconds = draft.timeoutSeconds,
                defaultRemoteDir = draft.defaultRemoteDir
            )
            val result = fs.connect(config)
            fs.disconnect()
            if (result.isSuccess) {
                _uiState.update { it.copy(testStatus = TestConnectionStatus.SUCCESS, testMessage = "Connection successful") }
            } else {
                _uiState.update {
                    it.copy(
                        testStatus = TestConnectionStatus.FAILED,
                        testMessage = result.exceptionOrNull()?.message ?: "Connection failed"
                    )
                }
            }
        }
    }

    fun save() {
        val draft = _uiState.value.draft
        val nameError = if (draft.name.isBlank()) "Name is required" else null
        val hostError = if (draft.host.isBlank()) "Host is required" else null
        if (nameError != null || hostError != null) {
            _uiState.update { it.copy(nameError = nameError, hostError = hostError) }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isSaving = true) }
            serverRepository.saveServer(draft)
            _uiState.update { it.copy(isSaving = false, saved = true) }
        }
    }
}
