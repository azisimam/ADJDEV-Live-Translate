# ADJDEV FTP Explorer ProGuard rules

# Keep sshj / bouncycastle (reflection heavy)
-keep class net.schmizz.sshj.** { *; }
-keep class com.hierynomus.** { *; }
-keep class org.bouncycastle.** { *; }
-dontwarn net.schmizz.sshj.**
-dontwarn org.bouncycastle.**
-dontwarn org.slf4j.**

# Keep commons-net FTP client
-keep class org.apache.commons.net.** { *; }
-dontwarn org.apache.commons.net.**

# Room
-keep class androidx.room.** { *; }

# Kotlinx serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class **.*$$serializer {
    *** INSTANCE;
}

# Hilt
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.HiltAndroidApp

# Data / entity classes used with reflection-based libraries
-keep class com.adjdev.ftpexplorer.data.db.** { *; }
-keep class com.adjdev.ftpexplorer.data.remote.** { *; }
