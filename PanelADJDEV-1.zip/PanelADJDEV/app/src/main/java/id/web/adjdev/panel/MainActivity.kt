package id.web.adjdev.panel

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar

    private val targetUrl = "https://panel.adjdev.web.id/dashboard"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Splash screen resmi (Android 12+ API, otomatis fallback di versi lama)
        installSplashScreen()

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)

        setupWebView()
        webView.loadUrl(targetUrl)
    }

    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT

            // Samarkan User-Agent jadi Chrome biasa (hilangkan tanda "; wv")
            // supaya Google tidak menolak proses login (disallowed_useragent)
            val originalUA = userAgentString
            userAgentString = originalUA.replace("; wv", "")
        }

        // Pastikan cookie (termasuk sesi login) tersimpan dengan benar
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        // Domain yang boleh dibuka LANGSUNG di dalam WebView (termasuk buat login Google OAuth)
        val allowedHosts = listOf(
            "adjdev.web.id",
            "accounts.google.com",
            "accounts.youtube.com",
            "google.com",
            "gstatic.com",
            "googleusercontent.com",
            "googleapis.com"
        )

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val host = request.url.host ?: return false
                return if (allowedHosts.any { host == it || host.endsWith(".$it") }) {
                    false // biarkan WebView yang load (termasuk flow login Google)
                } else {
                    // Link keluar domain (misal WhatsApp, dokumen eksternal, dll), buka di app luar
                    try {
                        startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, request.url))
                    } catch (_: Exception) { }
                    true
                }
            }
        }

        webView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progressBar.progress = newProgress
                progressBar.visibility = if (newProgress in 1..99) android.view.View.VISIBLE else android.view.View.GONE
                if (newProgress >= 100) {
                    swipeRefresh.isRefreshing = false
                }
            }
        }

        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
