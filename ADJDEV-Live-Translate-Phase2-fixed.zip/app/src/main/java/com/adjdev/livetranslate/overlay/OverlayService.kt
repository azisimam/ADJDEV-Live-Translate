package com.adjdev.livetranslate.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.compose.ui.platform.ComposeView
import com.adjdev.livetranslate.MainActivity
import com.adjdev.livetranslate.audio.MicAudioSource
import com.adjdev.livetranslate.core.TranslationPipeline
import com.adjdev.livetranslate.core.TranslatorState
import com.adjdev.livetranslate.detection.MlKitLanguageDetector
import com.adjdev.livetranslate.settings.SettingsRepository
import com.adjdev.livetranslate.stt.AndroidSpeechRecognizerEngine
import com.adjdev.livetranslate.storage.TranslationCache
import com.adjdev.livetranslate.translation.MlKitTranslationEngine
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Satu Foreground Service yang bertanggung jawab atas:
 *  1. Menjalankan TranslationPipeline (audio -> VAD -> STT -> translation).
 *  2. Menampilkan floating overlay (panel penuh atau bubble minimized) via WindowManager.
 *
 * Service ini TIDAK melakukan apa pun ketika translator OFF: stopSelf() dipanggil
 * dan seluruh resource (audio, overlay view, pipeline) dilepas (spesifikasi #14/#18).
 */
class OverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    companion object {
        const val ACTION_START = "com.adjdev.livetranslate.action.START"
        const val ACTION_STOP = "com.adjdev.livetranslate.action.STOP"
        private const val NOTIFICATION_CHANNEL_ID = "adjdev_live_translate_channel"
        private const val NOTIFICATION_ID = 1001
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private lateinit var windowManager: WindowManager
    private var overlayComposeView: ComposeView? = null
    private var overlayLayoutParams: WindowManager.LayoutParams? = null
    private var isMinimized = false

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var pipeline: TranslationPipeline

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        settingsRepository = SettingsRepository(applicationContext)

        pipeline = TranslationPipeline(
            micSource = MicAudioSource(applicationContext),
            sttEngine = AndroidSpeechRecognizerEngine(applicationContext),
            languageDetector = MlKitLanguageDetector(),
            translationEngine = MlKitTranslationEngine(),
            cache = TranslationCache(context = applicationContext)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEverything()
                return START_NOT_STICKY
            }
            else -> startEverything()
        }
        return START_STICKY
    }

    private fun startEverything() {
        // Phase 2: pipeline hanya menggunakan Mic (System Audio via MediaProjection belum
        // di-wire ke pipeline). Manifest men-declare type "microphone|mediaProjection" agar
        // service siap untuk System Audio di fase berikutnya, TAPI kita wajib memberi tahu
        // sistem secara eksplisit type mana yang benar-benar aktif SEKARANG lewat overload
        // 3-argumen ini. Overload 2-argumen (startForeground(id, notif)) otomatis meminta
        // SEMUA type yang ada di manifest — termasuk mediaProjection — padahal kita belum
        // pernah minta izin MediaProjection ke user, sehingga Android 14 (targetSdk 34)
        // melempar SecurityException karena syarat mediaProjection tidak terpenuhi.
        //
        // Saat System Audio capture benar-benar diimplementasikan nanti:
        // 1. Minta consent lewat MediaProjectionManager.createScreenCaptureIntent() di Activity.
        // 2. Kirim resultCode + data Intent ke service ini (mis. lewat Intent extra).
        // 3. Baru tambahkan `or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION` di bawah,
        //    dan panggil mediaProjectionManager.getMediaProjection(...) SETELAH startForeground()
        //    dipanggil (urutan ini wajib di Android 14+, kalau dibalik akan crash juga).
        androidx.core.app.ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        showOverlayPanel()

        lifecycleScope.launch {
            val target = settingsRepository.targetLanguage
            val auto = settingsRepository.autoDetect
            val source = settingsRepository.sourceLanguage
            // Ambil snapshot konfigurasi awal lalu pantau perubahan target/auto-detect secara live.
            kotlinx.coroutines.flow.combine(target, auto, source) { t, a, s ->
                Triple(t, a, if (a) null else s)
            }.collectLatest { (t, a, s) ->
                pipeline.configure(targetLanguageTag = t, autoDetect = a, sourceLanguageTag = s)
            }
        }

        lifecycleScope.launch {
            settingsRepository.micOn.collectLatest { micOn ->
                if (micOn) pipeline.startMic() else pipeline.stopMic()
            }
        }

        lifecycleScope.launch {
            settingsRepository.contextMessageLimit.collectLatest { limit ->
                pipeline.setContextLimit(limit)
            }
        }
    }

    private fun stopEverything() {
        pipeline.stopAll()
        removeOverlay()
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun showOverlayPanel() {
        removeOverlay()
        isMinimized = false

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                val state by pipeline.state.collectAsState()
                val opacity by settingsRepository.overlayOpacity.collectAsState(initial = 0.92f)
                val fontSize by settingsRepository.overlayFontSize.collectAsState(initial = 14)

                if (isMinimized) {
                    OverlayBubble(onTap = { toggleMinimize() })
                } else {
                    OverlayScreen(
                        state = state,
                        opacity = opacity,
                        fontSizeSp = fontSize,
                        onToggleMic = { toggleMic(state) },
                        onMinimize = { toggleMinimize() },
                        onClose = { stopEverything() },
                        onClearConversation = { pipeline.clearConversation() }
                    )
                }
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        windowManager.addView(composeView, params)
        overlayComposeView = composeView
        overlayLayoutParams = params
        attachDragHandling(composeView, params)
    }

    /**
     * Drag manual via ACTION_DOWN/MOVE/UP pada window overlay itu sendiri, lalu snap ke
     * tepi layar terdekat (kiri/kanan) saat jari dilepas (spesifikasi §12: draggable,
     * snap to screen edges). Klik singkat (gerakan < touchSlop) tetap diteruskan sebagai
     * tap normal ke Compose (mis. tombol minimize/mic) karena FLAG_NOT_FOCUSABLE membuat
     * event tap tetap sampai ke child view saat tidak dianggap sebagai drag.
     */
    private fun attachDragHandling(view: ComposeView, params: WindowManager.LayoutParams) {
        var startTouchX = 0f
        var startTouchY = 0f
        var startX = 0
        var startY = 0
        var isDragging = false
        val touchSlopPx = 16f

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startTouchX = event.rawX
                    startTouchY = event.rawY
                    startX = params.x
                    startY = params.y
                    isDragging = false
                    false // biarkan Compose tetap memproses tap di bawahnya
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - startTouchX
                    val dy = event.rawY - startTouchY
                    if (!isDragging && (kotlin.math.abs(dx) > touchSlopPx || kotlin.math.abs(dy) > touchSlopPx)) {
                        isDragging = true
                    }
                    if (isDragging) {
                        params.x = (startX + dx).toInt()
                        params.y = (startY + dy).toInt()
                        runCatching { windowManager.updateViewLayout(view, params) }
                    }
                    isDragging // konsumsi event hanya kalau sedang benar-benar di-drag
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isDragging) {
                        snapToNearestEdge(view, params)
                        true
                    } else {
                        false // tap pendek, teruskan ke Compose (klik tombol dsb.)
                    }
                }
                else -> false
            }
        }
    }

    private fun snapToNearestEdge(view: ComposeView, params: WindowManager.LayoutParams) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(metrics)
        val screenWidth = metrics.widthPixels
        val viewWidth = view.width.takeIf { it > 0 } ?: 320
        val centerX = params.x + viewWidth / 2
        val targetX = if (centerX < screenWidth / 2) 0 else screenWidth - viewWidth

        val animator = ValueAnimator.ofInt(params.x, targetX).apply {
            duration = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                params.x = it.animatedValue as Int
                runCatching { windowManager.updateViewLayout(view, params) }
            }
        }
        animator.start()
    }

    private fun toggleMinimize() {
        isMinimized = !isMinimized
        showOverlayPanel()
    }

    private fun toggleMic(current: TranslatorState) {
        lifecycleScope.launch { settingsRepository.setMicOn(!current.micOn) }
    }

    private fun removeOverlay() {
        overlayComposeView?.let {
            runCatching { windowManager.removeView(it) }
        }
        overlayComposeView = null
    }

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "ADJDEV Live Translate",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Status penerjemahan realtime sedang aktif" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Translator Active")
            .setContentText("Menerjemahkan percakapan secara realtime")
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        removeOverlay()
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        super.onDestroy()
    }
}
