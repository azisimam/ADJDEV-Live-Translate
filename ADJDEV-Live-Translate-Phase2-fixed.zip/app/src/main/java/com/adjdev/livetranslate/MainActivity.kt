package com.adjdev.livetranslate

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.adjdev.livetranslate.overlay.OverlayService
import com.adjdev.livetranslate.settings.TranslationMode
import com.adjdev.livetranslate.ui.theme.ADJDEVLiveTranslateTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ADJDEVLiveTranslateTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen(viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current

    val micOn by viewModel.settings.micOn.collectAsState(initial = true)
    val systemAudioOn by viewModel.settings.systemAudioOn.collectAsState(initial = false)
    val autoDetect by viewModel.settings.autoDetect.collectAsState(initial = true)
    val mode by viewModel.settings.translationMode.collectAsState(initial = TranslationMode.LIGHT)

    var isRunning by remember { mutableStateOf(false) }

    val recordAudioPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("ADJDEV Live Translate", style = MaterialTheme.typography.headlineSmall)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (isRunning) "\uD83D\uDFE2 Translator Active" else "\u26AA Translator Idle")
        }

        Text("Language: AUTO", style = MaterialTheme.typography.bodyMedium)

        HorizontalDivider()

        Text("Input", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(selected = micOn, onClick = { viewModel.setMicOn(!micOn) }, label = { Text("\uD83C\uDF99 Microphone") })
            FilterChip(selected = systemAudioOn, onClick = { viewModel.setSystemAudioOn(!systemAudioOn) }, label = { Text("\uD83D\uDD0A System Audio") })
        }
        Text(
            "Catatan: System Audio (Phase 1) hanya menangkap audio media/game dari aplikasi lain, " +
                "bukan audio panggilan VoIP — lihat penjelasan di SystemAudioSource.kt.",
            style = MaterialTheme.typography.bodySmall
        )

        HorizontalDivider()

        Text("Mode", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == TranslationMode.LIGHT, onClick = { viewModel.setMode(TranslationMode.LIGHT) }, label = { Text("\uD83D\uDFE2 LIGHT") })
            FilterChip(selected = mode == TranslationMode.SMART, onClick = { viewModel.setMode(TranslationMode.SMART) }, label = { Text("\uD83D\uDFE1 SMART (Phase 3)") }, enabled = false)
            FilterChip(selected = mode == TranslationMode.COPILOT, onClick = { viewModel.setMode(TranslationMode.COPILOT) }, label = { Text("\uD83D\uDD34 COPILOT (Phase 3)") }, enabled = false)
        }

        HorizontalDivider()

        Button(
            onClick = {
                val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                    context, Manifest.permission.RECORD_AUDIO
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (!hasMic) {
                    recordAudioPermission.launch(Manifest.permission.RECORD_AUDIO)
                    return@Button
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val hasNotif = androidx.core.content.ContextCompat.checkSelfPermission(
                        context, Manifest.permission.POST_NOTIFICATIONS
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!hasNotif) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (!Settings.canDrawOverlays(context)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    overlayPermissionLauncher.launch(intent)
                    return@Button
                }

                context.startForegroundService(Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_START))
                isRunning = true
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isRunning
        ) { Text("Start Translator") }

        OutlinedButton(
            onClick = {
                context.startService(Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
                isRunning = false
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = isRunning
        ) { Text("Stop Translator") }
    }
}
