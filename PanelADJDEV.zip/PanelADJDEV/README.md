# Panel ADJDEV — Android WebView App

Aplikasi Android sederhana yang menampilkan https://panel.adjdev.web.id/dashboard
menggunakan WebView, lengkap dengan splash screen dan icon custom.

## Cara pakai
1. Buka folder ini di **Android Studio** (File > Open).
2. Tunggu Gradle sync selesai.
3. Klik Run ▶️ untuk build & jalankan di emulator/device.

## Yang sudah termasuk
- WebView full-screen dengan progress bar & pull-to-refresh
- Link keluar domain adjdev.web.id otomatis dibuka di browser luar
- Tombol back Android navigasi ke halaman sebelumnya di WebView
- Splash screen (androidx.core.splashscreen) pakai warna brand
- Adaptive icon placeholder (di res/drawable/ic_launcher_*.xml)

## Ganti icon custom
Icon sekarang masih placeholder (kotak biru + segitiga).
Cara ganti dengan logo asli:
1. Klik kanan folder `app` di Android Studio > New > Image Asset
2. Pilih logo ADJDEV kamu sebagai Foreground Layer
3. Generate — otomatis replace semua ukuran mipmap

## Ganti URL / warna splash
- URL: `app/src/main/java/id/web/adjdev/panel/MainActivity.kt` (variabel `targetUrl`)
- Warna splash & brand: `app/src/main/res/values/colors.xml`

## Build APK via GitHub Actions
Workflow sudah disiapkan di `.github/workflows/build-apk.yml`.

Cara pakai:
1. Push seluruh folder ini ke repo GitHub (branch `main`).
2. Buka tab **Actions** di repo → workflow "Build APK" akan otomatis jalan
   (atau klik **Run workflow** manual kalau mau trigger sendiri).
3. Setelah selesai (± 2-4 menit), buka run yang selesai → scroll ke bagian
   **Artifacts** → download `panel-adjdev-debug-apk`.
4. Extract zip-nya, isinya `app-debug.apk` — install langsung ke HP Android.

Catatan:
- Workflow ini build APK **debug** (belum di-sign untuk rilis Play Store),
  cocok untuk testing/install manual.
- Kalau nanti butuh APK release yang di-sign, tinggal minta ditambahin
  step signing pakai keystore.
