package com.adjdev.livetranslate.stt

import com.adjdev.livetranslate.audio.AudioChunk
import com.adjdev.livetranslate.stt.vosk.PcmSttEngine
import com.adjdev.livetranslate.vad.EnergyVadEngine
import com.adjdev.livetranslate.vad.VoiceActivityDetector
import com.adjdev.livetranslate.vad.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

/**
 * Alternatif System Audio STT pakai Groq Whisper — dipakai kalau user sudah isi Groq API key
 * (Settings ⚙️ > Cloud Speech-to-Text, field yang SAMA dipakai mic). Jauh lebih cepat &
 * akurat dibanding Vosk offline (model kecil, terbatas ~10 bahasa resmi, endpointing kadang
 * motong kalimat prematur — lihat riwayat panjang soal ini). Trade-off: butuh internet, dan
 * teks yang diucapkan terkirim ke server Groq (bukan lagi 100% on-device seperti Vosk).
 *
 * ARSITEKTUR: [accept] dipanggil sinkron per-chunk oleh TranslationPipeline (loop
 * collect{}), tapi upload ke Groq itu network call yang lama (ratusan ms - detik) — TIDAK
 * BOLEH nge-block accept() nunggu network, karena itu akan bikin chunk audio BERIKUTNYA
 * ketunda/keburu numpuk. Solusinya: upload dilempar ke coroutine terpisah (fire-and-forget,
 * pakai [scope] milik TranslationPipeline), hasilnya dikirim lewat [resultChannel], dan
 * [accept] mengecek channel itu (non-blocking, `tryReceive`) di awal tiap panggilan — jadi
 * hasil transkrip "telat" satu-dua chunk dari kapan sebenarnya selesai di-upload, tapi audio
 * capture tidak pernah tersendat.
 */
class GroqWhisperPcmSttEngine(
    private val scope: CoroutineScope,
    private val apiKeyProvider: () -> String?,
    private val vad: VoiceActivityDetector = EnergyVadEngine()
) : PcmSttEngine {

    companion object {
        private const val SAMPLE_RATE_HZ = 16_000
        private const val MIN_UTTERANCE_MS = 600L
        private const val SILENCE_TO_FLUSH_MS = 900L
        private const val MIN_RMS_TO_UPLOAD = 300.0 // lihat catatan anti-halusinasi di GroqWhisperSttEngine
    }

    private val resultChannel = Channel<TranscriptResult>(Channel.UNLIMITED)
    private val buffer = mutableListOf<Short>()
    private var inSpeech = false
    private var lastSpeechAtMs = 0L
    private var languageTag: String? = null

    override var lastError: String? = null
        private set

    override val isReady: Boolean get() = !apiKeyProvider().isNullOrBlank()

    override fun start(languageTag: String): Boolean {
        this.languageTag = languageTag
        vad.reset()
        buffer.clear()
        inSpeech = false
        lastError = null
        return isReady
    }

    override suspend fun accept(chunk: AudioChunk): TranscriptResult? {
        // Cek dulu ada hasil upload sebelumnya yang sudah selesai (non-blocking) — lihat
        // penjelasan arsitektur di dokumentasi kelas ini.
        resultChannel.tryReceive().getOrNull()?.let { return it }

        val now = System.currentTimeMillis()
        when (vad.evaluate(chunk)) {
            VoiceState.SPEECH -> {
                inSpeech = true
                lastSpeechAtMs = now
                buffer.addAll(chunk.samples.toList())
            }
            VoiceState.SILENCE -> {
                if (inSpeech && (now - lastSpeechAtMs) >= SILENCE_TO_FLUSH_MS) {
                    inSpeech = false
                    flushAsync()
                }
            }
        }
        return null
    }

    private fun flushAsync() {
        if (buffer.isEmpty()) return
        val durationMs = buffer.size * 1000L / SAMPLE_RATE_HZ
        if (durationMs < MIN_UTTERANCE_MS) {
            buffer.clear()
            return
        }
        val pcm = buffer.toShortArray()
        buffer.clear()

        val rms = GroqTranscriptionClient.rmsOf(pcm)
        if (rms < MIN_RMS_TO_UPLOAD) return // jaring pengaman anti-halusinasi, sama seperti mic

        val lang = languageTag
        val key = apiKeyProvider()
        scope.launch {
            val result = runCatching {
                GroqTranscriptionClient.transcribe(pcm, SAMPLE_RATE_HZ, lang, key)
            }
            result.onFailure { e -> lastError = e.message }
            val text = result.getOrNull()
            if (!text.isNullOrBlank()) {
                resultChannel.trySend(TranscriptResult(text, isFinal = true, languageHint = lang))
            }
        }
    }

    override fun stop() {
        buffer.clear()
        inSpeech = false
    }
}
