plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.adjdev.livetranslate"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.adjdev.livetranslate"
        minSdk = 26 // butuh 26+ untuk overlay & foreground service yang stabil
        targetSdk = 34
        // Diambil dari env var BUILD_VERSION_CODE (di-set workflow GitHub Actions pakai
        // nomor run yang selalu naik) supaya Android menganggap tiap build sebagai UPDATE,
        // bukan app beda -> install lewat "Update" tanpa uninstall APK lama. Fallback ke 1
        // untuk build lokal biasa (Android Studio) yang tidak lewat CI.
        versionCode = (System.getenv("BUILD_VERSION_CODE") ?: "1").toInt()
        versionName = "0.4.0-phase3"
    }

    signingConfigs {
        // Keystore TETAP (bukan debug.keystore bawaan yang di-generate ulang tiap mesin/run
        // CI) — supaya tanda tangan APK selalu SAMA antar build, syarat wajib Android supaya
        // instalasi baru dianggap "update" dari yang lama, bukan app berbeda. File keystore
        // ini di-commit ke repo (aman: ini cuma untuk instal pribadi/testing, BUKAN untuk
        // publish ke Play Store — kalau nanti mau publish ke Play Store, ganti dengan keystore
        // rilis terpisah yang TIDAK di-commit ke repo publik).
        create("adjdevFixed") {
            storeFile = file("../keystore/adjdev-debug.keystore")
            storePassword = "adjdevlivetranslate"
            keyAlias = "adjdev-live-translate"
            keyPassword = "adjdevlivetranslate"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("adjdevFixed")
        }
        debug {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("adjdevFixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    // composeOptions { kotlinCompilerExtensionVersion = ... } DIHAPUS: mekanisme itu K1-only.
    // Sejak Kotlin 2.0+, versi compiler Compose ditentukan otomatis oleh plugin
    // "org.jetbrains.kotlin.plugin.compose" (lihat root build.gradle.kts) mengikuti versi
    // Kotlin project ini — tidak perlu diset manual lagi di sini.

    packaging {
        resources.excludes.add("/META-INF/{AL2.0,LGPL2.1}")
    }
}

dependencies {
    // Core & lifecycle
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.savedstate:savedstate-ktx:1.2.1")

    // Compose (BOM)
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.compose.material:material-icons-extended:1.6.8")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // DataStore untuk settings lokal (bukan cloud db)
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // ML Kit on-device: translation & language identification (offline setelah model diunduh sekali)
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")

    // ML Kit GenAI Prompt API — Gemini Nano on-device via AICore (Phase 3: mode SMART yang
    // benar-benar context-aware + COPILOT dengan suggested replies sungguhan, bukan lagi
    // rule-based). Beta, hanya berjalan di perangkat yang didukung AICore — lihat catatan
    // kejujuran di ContextAwareTranslationEngine.kt / GeminiNanoCopilotEngine.kt. Aman
    // ditambahkan di semua perangkat: di perangkat tak didukung, checkStatus() otomatis
    // UNAVAILABLE dan pipeline jatuh ke perilaku Phase 2 (ML Kit Translate biasa + placeholder).
    implementation("com.google.mlkit:genai-prompt:1.0.0-beta2")

    // Vosk (org.vosk:vosk-android via com.alphacephei) — STT offline berbasis PCM untuk
    // System Audio (Phase 3.1). BEDA dari ML Kit di atas: model bahasa TIDAK dibundel di APK,
    // diunduh sekali saat System Audio pertama kali diaktifkan (lihat VoskModelManager) supaya
    // ukuran APK dasar tidak membengkak untuk fitur yang belum tentu dipakai semua user.
    // JNA (dependensi transitif vosk-android) WAJIB deklarasi @aar eksplisit di sini kalau
    // versi vosk-android yang dipakai tidak menariknya otomatis sebagai aar.
    implementation("com.alphacephei:vosk-android:0.3.75")
    implementation("net.java.dev.jna:jna:5.18.1@aar")
}
