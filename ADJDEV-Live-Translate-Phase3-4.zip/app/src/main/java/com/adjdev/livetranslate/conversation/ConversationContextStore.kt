package com.adjdev.livetranslate.conversation

/** Satu giliran bicara dalam percakapan yang sudah diterjemahkan. */
data class ConversationTurn(
    val sourceText: String,
    val translatedText: String,
    val languageTag: String,
    val timestampMs: Long = System.currentTimeMillis()
)

/**
 * Menyimpan histori percakapan terbaru secara lokal saja, dengan batas jumlah pesan yang
 * ketat (spesifikasi §4: "Context harus memiliki batas jumlah pesan/token agar penggunaan
 * RAM tetap rendah" / "Jangan menyimpan percakapan tanpa batas").
 *
 * Phase 1/2: in-memory murni, dipakai sebagai dasar untuk mode SMART (context-aware
 * translation) di Phase 3 — mis. menyisipkan N turn terakhir sebagai context ke prompt AI.
 * Tidak ada persistence ke disk secara default demi privasi (spesifikasi §15).
 */
class ConversationContextStore(private var maxTurns: Int = 12) {

    private val turns = ArrayDeque<ConversationTurn>()

    @Synchronized
    fun addTurn(turn: ConversationTurn) {
        turns.addLast(turn)
        while (turns.size > maxTurns) turns.removeFirst()
    }

    @Synchronized
    fun recentTurns(): List<ConversationTurn> = turns.toList()

    @Synchronized
    fun setMaxTurns(value: Int) {
        maxTurns = value.coerceAtLeast(1)
        while (turns.size > maxTurns) turns.removeFirst()
    }

    /** Dipanggil oleh tombol "Clear Conversation" (spesifikasi §4 dan §15). */
    @Synchronized
    fun clear() = turns.clear()
}
