package com.adjdev.livetranslate.ai

import com.google.mlkit.genai.common.DownloadStatus
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.prompt.Generation

/**
 * Implementasi SUNGGUHAN mode COPILOT (Phase 3) — menggantikan PlaceholderCopilotEngine
 * (rule-based) dengan model generatif on-device asli: Gemini Nano via ML Kit GenAI Prompt
 * API (com.google.mlkit:genai-prompt), diakses lewat AICore. Siklus idle->load->generate
 * sesuai kontrak AIEngine/spesifikasi §6 tetap dipertahankan persis.
 *
 * load(): checkStatus() dulu (WAJIB sebelum apa pun lain, sesuai dokumentasi resmi — supaya
 * error setup AICore tidak bocor ke user). Kalau DOWNLOADABLE, unduh sekali di sini (ini model
 * kecil khusus prompt, berbeda dari model translate ML Kit biasa). Kalau UNAVAILABLE (device
 * tidak didukung) atau error apa pun, status jadi UNAVAILABLE — FallbackCopilotEngine yang
 * membungkus kelas ini akan otomatis pindah ke PlaceholderCopilotEngine.
 *
 * CATATAN KEJUJURAN: sama seperti ContextAwareTranslationEngine — ditulis mengikuti dokumentasi
 * resmi Prompt API Google per Jan 2026, HANYA berjalan di perangkat yang didukung AICore, dan
 * belum pernah dikompilasi/dites di device nyata (tidak ada Android SDK/internet di sandbox
 * pembuatan). Kalau saran balasan terasa lambat/aneh di perangkat yang benar-benar mendukung
 * Gemini Nano, itu tempat pertama yang perlu diperiksa manual.
 */
class GeminiNanoCopilotEngine : AIEngine {

    private val model by lazy { Generation.getClient() }

    override var status: AIEngineStatus = AIEngineStatus.IDLE
        private set

    override suspend fun load() {
        if (status == AIEngineStatus.READY) return
        status = AIEngineStatus.LOADING
        status = try {
            when (model.checkStatus()) {
                FeatureStatus.AVAILABLE -> AIEngineStatus.READY

                FeatureStatus.DOWNLOADABLE -> {
                    var completed = false
                    model.download().collect { d ->
                        if (d is DownloadStatus.DownloadCompleted) completed = true
                    }
                    if (completed) AIEngineStatus.READY else AIEngineStatus.UNAVAILABLE
                }

                // Sedang diunduh (mis. dipicu sesi/proses lain) — jangan tunggu di sini, biar
                // FallbackCopilotEngine pakai placeholder dulu untuk sesi ini.
                FeatureStatus.DOWNLOADING -> AIEngineStatus.UNAVAILABLE

                else -> AIEngineStatus.UNAVAILABLE // FeatureStatus.UNAVAILABLE
            }
        } catch (e: Exception) {
            AIEngineStatus.UNAVAILABLE
        }
    }

    override fun unload() {
        // Jangan timpa UNAVAILABLE: kalau device memang tidak didukung, tidak perlu coba lagi
        // tiap kali Copilot di-toggle off/on dalam sesi yang sama.
        if (status != AIEngineStatus.UNAVAILABLE) status = AIEngineStatus.IDLE
    }

    override suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>,
        targetLanguageTag: String
    ): List<SuggestedReply> {
        if (status != AIEngineStatus.READY) return emptyList()
        status = AIEngineStatus.GENERATING
        val suggestions = try {
            val contextBlock = recentContext.takeLast(6).joinToString("\n") { "- $it" }
            val prompt = """
                Ini percakapan yang sedang diterjemahkan live. Giliran-giliran sebelumnya:
                $contextBlock

                Pesan lawan bicara barusan: "$incomingTranslatedText"

                Beri TEPAT 3 saran balasan singkat (maksimal 12 kata masing-masing), dalam
                bahasa yang sama dengan pesan barusan, terdengar natural/mengalir seperti
                obrolan sungguhan (bukan kaku atau template), dengan isi berbeda-beda:
                1) jawaban singkat/langsung yang relevan dengan isi pesan, 2) tanggapan
                natural/santai yang menyambung topik obrolan, 3) SATU pertanyaan balik
                (tanya balik) yang relevan untuk melanjutkan percakapan. Balas HANYA 3 baris
                berisi saran itu saja — tanpa nomor, tanpa tanda kutip, tanpa penjelasan atau
                label nada.
            """.trimIndent()

            val response = model.generateContent(prompt)
            response.candidates.firstOrNull()?.text
                ?.lines()
                ?.map { it.trim().trimStart('-', '*', '•').trim().trim('"') }
                ?.filter { it.isNotBlank() }
                ?.take(3)
                ?.map { SuggestedReply(it, ReplyTone.NATURAL) }
                ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
        status = AIEngineStatus.READY
        return suggestions
    }
}
