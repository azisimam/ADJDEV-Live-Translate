package com.adjdev.livetranslate.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7FDBFF),
    background = Color(0xFF14141C),
    surface = Color(0xFF1C1C28)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF0074D9),
    background = Color(0xFFF7F7FA),
    surface = Color(0xFFFFFFFF)
)

@Composable
fun ADJDEVLiveTranslateTheme(darkTheme: Boolean = true, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
