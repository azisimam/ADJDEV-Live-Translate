package com.adjdev.livetranslate.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Bubble kecil saat panel diminimalkan. Tap untuk membuka kembali panel penuh. */
@Composable
fun OverlayBubble(onTap: () -> Unit) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(Color(0xCC1E1E2E))
            .clickable(onClick = onTap),
        contentAlignment = Alignment.Center
    ) {
        Text("\u25C9", color = Color(0xFF7FDBFF), style = MaterialTheme.typography.titleLarge)
    }
}
