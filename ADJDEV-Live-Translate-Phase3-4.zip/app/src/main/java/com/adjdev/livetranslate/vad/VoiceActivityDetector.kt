package com.adjdev.livetranslate.vad

import com.adjdev.livetranslate.audio.AudioChunk

/** Hasil evaluasi VAD untuk satu chunk audio. */
enum class VoiceState { SILENCE, SPEECH }

/**
 * Kontrak Voice Activity Detection. Implementasi harus sangat murah secara CPU
 * karena dipanggil untuk SETIAP chunk audio yang masuk (bisa puluhan kali/detik).
 */
interface VoiceActivityDetector {
    /** Evaluasi satu chunk. Stateful: implementasi boleh menyimpan histori internal singkat. */
    fun evaluate(chunk: AudioChunk): VoiceState

    /** Reset state internal (dipanggil saat translator distop/dimulai ulang). */
    fun reset()
}

/** Konfigurasi threshold VAD, disimpan di settings agar dapat disesuaikan pengguna. */
data class VadConfig(
    val energyThreshold: Double = 500.0,       // ambang RMS untuk dianggap "ada suara"
    val silenceTimeoutMs: Long = 800L,         // jeda diam sebelum kalimat dianggap selesai
    val minSpeechDurationMs: Long = 150L       // suara terlalu pendek diabaikan (noise klik, dsb)
)
