package com.adjdev.livetranslate.audio

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.annotation.RequiresPermission
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.Dispatchers

/**
 * Sumber audio dari microphone perangkat.
 * Hanya boleh start() ketika pengguna secara eksplisit mengaktifkan toggle MIC ON.
 * Pemanggil (TranslationPipeline) bertanggung jawab menjamin ini.
 */
class MicAudioSource(private val context: Context) : AudioSource {

    companion object {
        const val SAMPLE_RATE_HZ = 16_000 // standar untuk sebagian besar STT engine
        private val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    @Volatile
    override var isCapturing: Boolean = false
        private set

    private var audioRecord: AudioRecord? = null

    @RequiresPermission(Manifest.permission.RECORD_AUDIO)
    override fun start(): Flow<AudioChunk> = callbackFlow {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            close(SecurityException("RECORD_AUDIO permission belum diberikan"))
            return@callbackFlow
        }

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE_HZ, CHANNEL_CONFIG, AUDIO_FORMAT
        ).coerceAtLeast(1024)
        // Buffer sengaja dibuat kecil (bukan berlipat-lipat) agar latency rendah
        // dan RAM tidak membengkak, sesuai prinsip performance di spesifikasi.
        val bufferSize = minBufferSize * 2

        val record = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION, // mengaktifkan AEC/NS bila tersedia di HW
            SAMPLE_RATE_HZ, CHANNEL_CONFIG, AUDIO_FORMAT, bufferSize
        )

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            close(IllegalStateException("Gagal inisialisasi AudioRecord"))
            return@callbackFlow
        }

        audioRecord = record
        record.startRecording()
        isCapturing = true

        val readBuffer = ShortArray(bufferSize / 2)
        var running = true
        while (running) {
            val read = record.read(readBuffer, 0, readBuffer.size)
            if (read > 0) {
                val chunk = readBuffer.copyOf(read)
                val sent = trySend(AudioChunk(chunk, SAMPLE_RATE_HZ, AudioSourceType.MICROPHONE))
                if (sent.isFailure) running = false
            } else {
                running = false
            }
        }

        awaitClose { internalStop() }
    }.flowOn(Dispatchers.IO)

    override fun stop() {
        internalStop()
    }

    private fun internalStop() {
        isCapturing = false
        audioRecord?.let {
            try {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) it.stop()
            } catch (_: Exception) {
                // AudioRecord bisa throw jika sudah dalam kondisi tidak valid; abaikan saat cleanup.
            } finally {
                it.release()
            }
        }
        audioRecord = null
    }
}
