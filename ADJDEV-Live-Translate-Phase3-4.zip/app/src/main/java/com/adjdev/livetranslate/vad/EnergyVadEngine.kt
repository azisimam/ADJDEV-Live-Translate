package com.adjdev.livetranslate.vad

import com.adjdev.livetranslate.audio.AudioChunk
import kotlin.math.sqrt

/**
 * Implementasi VAD berbasis energi (RMS) sederhana untuk Phase 1.
 * Sangat ringan (tanpa model ML), cocok untuk perangkat kelas menengah.
 *
 * Catatan arsitektur: kelas ini diganti tanpa mengubah pipeline dengan mengimplementasikan
 * VoiceActivityDetector lain (mis. Silero VAD via TFLite) di Phase 4 jika akurasi kurang.
 */
class EnergyVadEngine(private val config: VadConfig = VadConfig()) : VoiceActivityDetector {

    private var lastSpeechAtMs: Long = 0L
    private var speechStartedAtMs: Long = 0L
    private var inSpeech: Boolean = false

    override fun evaluate(chunk: AudioChunk): VoiceState {
        val rms = rms(chunk.samples)
        val now = System.currentTimeMillis()

        return if (rms >= config.energyThreshold) {
            if (!inSpeech) {
                inSpeech = true
                speechStartedAtMs = now
            }
            lastSpeechAtMs = now
            VoiceState.SPEECH
        } else {
            if (inSpeech && (now - lastSpeechAtMs) < config.silenceTimeoutMs) {
                // Masih dianggap dalam kalimat yang sama (jeda sesaat, mis. antar kata)
                VoiceState.SPEECH
            } else {
                inSpeech = false
                VoiceState.SILENCE
            }
        }
    }

    override fun reset() {
        lastSpeechAtMs = 0L
        speechStartedAtMs = 0L
        inSpeech = false
    }

    private fun rms(samples: ShortArray): Double {
        if (samples.isEmpty()) return 0.0
        var sum = 0.0
        for (s in samples) sum += (s.toDouble() * s.toDouble())
        return sqrt(sum / samples.size)
    }
}
