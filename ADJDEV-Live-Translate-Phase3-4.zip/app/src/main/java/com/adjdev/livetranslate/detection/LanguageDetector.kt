package com.adjdev.livetranslate.detection

interface LanguageDetector {
    /** Mengembalikan kode bahasa BCP-47 (mis. "en", "id"), atau null jika tidak yakin. */
    suspend fun detect(text: String): String?
}
