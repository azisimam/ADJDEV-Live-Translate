package com.adjdev.livetranslate.audio

import java.io.ByteArrayOutputStream

/**
 * Bungkus raw PCM 16-bit mono jadi file WAV standar (44-byte header) di memori.
 * Groq/OpenAI-compatible audio transcription API butuh file audio beneran (bukan raw PCM
 * mentah) — WAV dipilih karena paling sederhana, tanpa perlu encoder codec apa pun.
 */
object WavEncoder {

    fun encode(pcm: ShortArray, sampleRateHz: Int): ByteArray {
        val dataSize = pcm.size * 2 // 16-bit = 2 byte per sample
        val out = ByteArrayOutputStream(44 + dataSize)

        fun writeInt(v: Int) {
            out.write(v and 0xFF); out.write((v shr 8) and 0xFF)
            out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF)
        }
        fun writeShort(v: Int) {
            out.write(v and 0xFF); out.write((v shr 8) and 0xFF)
        }

        out.write("RIFF".toByteArray())
        writeInt(36 + dataSize)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        writeInt(16) // ukuran sub-chunk fmt
        writeShort(1) // PCM
        writeShort(1) // mono
        writeInt(sampleRateHz)
        writeInt(sampleRateHz * 2) // byte rate = sampleRate * channels * bitsPerSample/8
        writeShort(2) // block align
        writeShort(16) // bits per sample
        out.write("data".toByteArray())
        writeInt(dataSize)

        val buffer = java.nio.ByteBuffer.allocate(dataSize)
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
        pcm.forEach { buffer.putShort(it) }
        out.write(buffer.array())

        return out.toByteArray()
    }
}
