package com.adjdev.livetranslate.text

import android.icu.text.Transliterator
import android.os.Build

/**
 * Romanisasi aksara non-Latin (Mandarin, Jepang, Korea, Arab, Thai, dll) jadi tulisan Latin
 * yang bisa dibaca, KHUSUS dipakai untuk Suggested Replies — bukan untuk teks translation
 * utama (batasan sesuai permintaan awal user). Diperluas dari sebelumnya "cuma Mandarin →
 * pinyin" jadi general: aksara APA PUN yang bukan Latin sekarang dapat romanisasi.
 *
 * Pakai ID transliterator "Any-Latin" bawaan ICU Android (tersedia sejak API 24, minSdk
 * project ini 26) — ini mesin serba-guna ICU yang otomatis mendeteksi aksara sumber & pakai
 * aturan romanisasi yang sesuai (Han->pinyin, Hiragana/Katakana->romaji, Hangul->
 * romanisasi Korea, Arabic->Latin, dst) TANPA perlu tahu bahasa asalnya secara eksplisit —
 * lebih simpel & lebih luas cakupannya daripada "Han-Latin" yang dipakai versi sebelumnya
 * (yang cuma benar untuk Mandarin, dan malah salah nembak Kanji Jepang).
 */
object PinyinUtils {

    private val transliterator: Transliterator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            runCatching { Transliterator.getInstance("Any-Latin") }.getOrNull()
        } else null
    }

    /** Deteksi kasar: ada karakter di luar Latin/angka/tanda baca umum ASCII. */
    fun containsNonLatinScript(text: String): Boolean =
        text.any { c -> c.code > 0x2FF && !c.isWhitespace() }

    /** Null kalau teks sudah full Latin, atau ICU transliterator tidak tersedia di device. */
    fun pinyinOrNull(text: String): String? {
        if (!containsNonLatinScript(text)) return null
        val t = transliterator ?: return null
        return runCatching { t.transliterate(text) }.getOrNull()?.takeIf { it != text }
    }
}
