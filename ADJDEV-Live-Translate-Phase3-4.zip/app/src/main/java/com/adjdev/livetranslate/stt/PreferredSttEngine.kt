package com.adjdev.livetranslate.stt

import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * PRIORITAS: SpeechRecognizer bawaan Android (`local`) DICOBA DULU — gratis, 0 delay upload,
 * bisa offline, sesuai prinsip local-first spesifikasi §1/§6. Groq (`cloud`) HANYA dipakai
 * sebagai fallback RUNTIME kalau `local` beneran gagal di sesi itu (error nyata: mic
 * direbut app lain, bahasa tidak didukung device, dst — BUKAN untuk akhir kalimat normal,
 * yang oleh AndroidSpeechRecognizerEngine sudah ditutup tanpa exception).
 *
 * Kenapa bukan cuma "local.isAvailable" check statis lalu berhenti di situ: di sebagian
 * device (mis. sebagian ROM Xiaomi/MIUI — riwayat panjang soal ini ada di README),
 * `SpeechRecognizer.isRecognitionAvailable()` mengembalikan true PADAHAL sesi sungguhan
 * selalu gagal ("Speech recognition unavailable" untuk SEMUA bahasa). Static check saja
 * tidak cukup — makanya fallback dicek di RUNTIME (tiap sesi), bukan cuma sekali di awal.
 * Hasilnya: di device yang local-nya beneran jalan, Groq tidak pernah tersentuh (gratis,
 * cepat, sesuai saran); di device yang local-nya rusak/tidak lengkap (kasus HP kamu),
 * otomatis jatuh ke Groq tanpa perlu ubah setting apa pun.
 */
class PreferredSttEngine(
    private val cloud: GroqWhisperSttEngine,
    private val local: AndroidSpeechRecognizerEngine
) : SpeechRecognizerEngine {

    override val isAvailable: Boolean get() = local.isAvailable || cloud.isAvailable

    override fun startListening(languageTag: String?): Flow<TranscriptResult> = callbackFlow {
        var usedCloudFallback = false
        try {
            local.startListening(languageTag).collect { trySend(it) }
        } catch (localError: Exception) {
            if (cloud.isAvailable) {
                usedCloudFallback = true
                try {
                    cloud.startListening(languageTag).collect { trySend(it) }
                } catch (cloudError: Exception) {
                    close(cloudError)
                    return@callbackFlow
                }
            } else {
                close(localError)
                return@callbackFlow
            }
        }
        awaitClose {
            local.stopListening()
            if (usedCloudFallback) cloud.stopListening()
        }
    }

    override fun stopListening() {
        local.stopListening()
        cloud.stopListening()
    }
}
