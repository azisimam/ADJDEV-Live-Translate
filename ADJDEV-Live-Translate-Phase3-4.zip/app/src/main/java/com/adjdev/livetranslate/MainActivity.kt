package com.adjdev.livetranslate

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.adjdev.livetranslate.audio.SystemAudioSource
import com.adjdev.livetranslate.overlay.OverlayService
import com.adjdev.livetranslate.settings.TranslationMode
import com.adjdev.livetranslate.translation.LanguageCatalog
import com.adjdev.livetranslate.ui.theme.ADJDEVLiveTranslateTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ADJDEVLiveTranslateTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    // Navigasi sesederhana mungkin (tanpa library Navigation) karena app ini
                    // cuma punya 2 layar: cukup boolean state di root.
                    var showSettings by remember { mutableStateOf(false) }
                    if (showSettings) {
                        SettingsScreen(viewModel, onBack = { showSettings = false })
                    } else {
                        MainScreen(viewModel, onOpenSettings = { showSettings = true })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel, onOpenSettings: () -> Unit) {
    val context = LocalContext.current

    val micOn by viewModel.settings.micOn.collectAsState(initial = true)
    val systemAudioOn by viewModel.settings.systemAudioOn.collectAsState(initial = false)
    val autoDetect by viewModel.settings.autoDetect.collectAsState(initial = true)
    val mode by viewModel.settings.translationMode.collectAsState(initial = TranslationMode.LIGHT)
    val sourceLanguage by viewModel.settings.sourceLanguage.collectAsState(initial = "auto")
    val targetLanguage by viewModel.settings.targetLanguage.collectAsState(initial = "id")
    val remoteUrl by viewModel.settings.remoteCopilotUrl.collectAsState(initial = null)

    var isRunning by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    val systemAudioSupported = SystemAudioSource.isSupported

    val recordAudioPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    // Alur izin capture audio sistem (MediaProjection) — dialog sistem diminta lewat launcher
    // ini SAAT user menekan "Start Translator" dengan toggle System Audio ON, lalu resultCode
    // + data dikirim ke OverlayService lewat extras Intent supaya service yang membuat
    // MediaProjection-nya sendiri lewat MediaProjectionManager.getMediaProjection(...).
    val projectionManager = remember {
        context.getSystemService(MediaProjectionManager::class.java)
    }
    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            startTranslatorService(context, projectionResultCode = result.resultCode, projectionData = result.data)
            isRunning = true
        } else {
            // User menolak dialog capture sistem: tetap jalankan translator tapi hanya
            // dengan Microphone, System Audio otomatis dimatikan lagi untuk sesi ini.
            viewModel.setSystemAudioOn(false)
            startTranslatorService(context, projectionResultCode = null, projectionData = null)
            isRunning = true
        }
    }

    if (showHelp) {
        HelpDialog(systemAudioSupported = systemAudioSupported, onDismiss = { showHelp = false })
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ADJDEV Live Translate", style = MaterialTheme.typography.headlineSmall)
            Row {
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Pengaturan")
                }
                IconButton(onClick = { showHelp = true }) {
                    Icon(Icons.Filled.HelpOutline, contentDescription = "Bantuan & keterangan")
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (isRunning) "\uD83D\uDFE2 Translator Active" else "\u26AA Translator Idle")
        }

        LanguagePickerSection(
            viewModel = viewModel,
            sourceLanguage = sourceLanguage,
            targetLanguage = targetLanguage,
            autoDetect = autoDetect
        )

        HorizontalDivider()

        Text("Input", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(selected = micOn, onClick = { viewModel.setMicOn(!micOn) }, label = { Text("\uD83C\uDF99 Microphone") })
            FilterChip(
                selected = systemAudioOn,
                onClick = { viewModel.setSystemAudioOn(!systemAudioOn) },
                enabled = systemAudioSupported,
                label = { Text("\uD83D\uDD0A System Audio") }
            )
        }
        if (!systemAudioSupported) {
            Text(
                "Butuh Android 10+ — tidak tersedia di perangkat ini.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        HorizontalDivider()

        Text("Mode", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == TranslationMode.LIGHT, onClick = { viewModel.setMode(TranslationMode.LIGHT) }, label = { Text("\uD83D\uDFE2 LIGHT") })
            FilterChip(selected = mode == TranslationMode.SMART, onClick = { viewModel.setMode(TranslationMode.SMART) }, label = { Text("\uD83D\uDFE1 SMART") })
            FilterChip(selected = mode == TranslationMode.COPILOT, onClick = { viewModel.setMode(TranslationMode.COPILOT) }, label = { Text("\uD83D\uDD34 COPILOT") })
        }
        if (mode == TranslationMode.COPILOT || mode == TranslationMode.SMART) {
            Text(
                "Urutan otomatis: Gemini Nano \u2192 Remote (VPS) \u2192 rule-based. " +
                    (if (remoteUrl.isNullOrBlank()) "Remote (VPS) belum dikonfigurasi \u2014 " else "") +
                    "Atur di \u2699\uFE0F Pengaturan, atau ketuk \u2753 untuk detail.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        HorizontalDivider()

        Button(
            onClick = {
                val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                    context, Manifest.permission.RECORD_AUDIO
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (!hasMic) {
                    recordAudioPermission.launch(Manifest.permission.RECORD_AUDIO)
                    return@Button
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val hasNotif = androidx.core.content.ContextCompat.checkSelfPermission(
                        context, Manifest.permission.POST_NOTIFICATIONS
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!hasNotif) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (!Settings.canDrawOverlays(context)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    overlayPermissionLauncher.launch(intent)
                    return@Button
                }

                if (systemAudioOn && systemAudioSupported && projectionManager != null) {
                    projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
                    return@Button
                }

                startTranslatorService(context, projectionResultCode = null, projectionData = null)
                isRunning = true
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isRunning
        ) { Text("Start Translator") }

        OutlinedButton(
            onClick = {
                context.startService(Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
                isRunning = false
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = isRunning
        ) { Text("Stop Translator") }
    }
}

/**
 * Layar Pengaturan terpisah (dibuka lewat ikon \u2699\uFE0F di header MainScreen) — isinya
 * konfigurasi yang jarang diubah (Remote AI VPS) supaya tidak bikin layar utama panjang.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Kembali")
            }
            Text("Pengaturan", style = MaterialTheme.typography.headlineSmall)
        }

        HorizontalDivider()
        // Ditaruh SEBELUM Remote AI (Copilot) karena STT itu prasyarat dasar (tanpa mic
        // jalan, fitur AI apa pun tidak relevan) — urutan pentingnya duluan.
        CloudSttSection(viewModel)

        HorizontalDivider()
        RemoteCopilotSection(viewModel)
    }
}

/**
 * Picker bahasa sumber/target + tombol swap arah + tombol download model terjemahan lebih
 * awal (supaya kalimat pertama tidak nunggu download saat translator sudah jalan).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguagePickerSection(
    viewModel: MainViewModel,
    sourceLanguage: String,
    targetLanguage: String,
    autoDetect: Boolean
) {
    val scope = rememberCoroutineScope()
    var downloadStatus by remember { mutableStateOf<String?>(null) }
    var isDownloading by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LanguageDropdown(
                modifier = Modifier.weight(1f),
                selectedTag = if (autoDetect) "auto" else sourceLanguage,
                includeAuto = true,
                label = "Dari",
                onSelect = { tag ->
                    if (tag == "auto") {
                        viewModel.setAutoDetect(true)
                    } else {
                        viewModel.setAutoDetect(false)
                        viewModel.setSourceLanguage(tag)
                    }
                }
            )
            IconButton(onClick = { viewModel.swapLanguages(sourceLanguage, targetLanguage) }) {
                Icon(Icons.Filled.SwapHoriz, contentDescription = "Balik arah terjemahan")
            }
            LanguageDropdown(
                modifier = Modifier.weight(1f),
                selectedTag = targetLanguage,
                includeAuto = false,
                label = "Ke",
                onSelect = { tag -> viewModel.setTargetLanguage(tag) }
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                enabled = !isDownloading && !autoDetect,
                onClick = {
                    isDownloading = true
                    downloadStatus = null
                    scope.launch {
                        val ok = viewModel.downloadLanguagePair(sourceLanguage, targetLanguage)
                        isDownloading = false
                        downloadStatus = if (ok) "\u2705 Model siap (offline)" else "\u274C Gagal — cek koneksi internet"
                    }
                }
            ) {
                Text(if (isDownloading) "Mengunduh..." else "Download Model Bahasa")
            }
        }
        if (autoDetect) {
            Text(
                "Download model butuh bahasa sumber pasti (bukan AUTO) — pilih bahasa dulu di 'Dari'.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        downloadStatus?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguageDropdown(
    modifier: Modifier = Modifier,
    selectedTag: String,
    includeAuto: Boolean,
    label: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val options = remember(includeAuto) {
        buildList {
            if (includeAuto) add(LanguageCatalog.LanguageOption("auto", "\uD83C\uDF10 Auto-detect"))
            addAll(LanguageCatalog.ALL)
        }
    }
    val currentLabel = if (selectedTag == "auto") "\uD83C\uDF10 Auto-detect" else LanguageCatalog.displayNameFor(selectedTag)

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }, modifier = modifier) {
        OutlinedTextField(
            value = currentLabel,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option.displayName) },
                    onClick = {
                        onSelect(option.tag)
                        expanded = false
                    }
                )
            }
        }
    }
}

private fun startTranslatorService(
    context: android.content.Context,
    projectionResultCode: Int?,
    projectionData: Intent?
) {
    val intent = Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_START)
    if (projectionResultCode != null && projectionData != null) {
        intent.putExtra(OverlayService.EXTRA_PROJECTION_RESULT_CODE, projectionResultCode)
        intent.putExtra(OverlayService.EXTRA_PROJECTION_DATA, projectionData)
    }
    context.startForegroundService(intent)
}

/**
 * Semua teks penjelasan panjang yang sebelumnya nempel di alur utama (bikin scroll jadi
 * panjang) dipindah ke sini, dibuka lewat ikon \u2753 di header. Alur utama jadi cuma kontrol +
 * hint sebaris pendek.
 */
@Composable
private fun HelpDialog(systemAudioSupported: Boolean, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bantuan & Keterangan") },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                HelpSection(
                    title = "System Audio",
                    body = if (!systemAudioSupported) {
                        "Butuh Android 10 (Q) ke atas dan tidak tersedia di perangkat ini."
                    } else {
                        "Menangkap audio yang diputar aplikasi lain (video/musik/game), BUKAN " +
                            "audio panggilan VoIP. Dialog izin capture layar/audio muncul saat " +
                            "kamu menekan Start Translator dengan toggle ini aktif. Untuk " +
                            "translate suara lawan bicara di panggilan telepon/VoIP, tetap " +
                            "pakai mode Microphone + loudspeaker."
                    }
                )
                HelpSection(
                    title = "Mode LIGHT / SMART / COPILOT",
                    body = "LIGHT: terjemahan cepat biasa. SMART: terjemahan yang " +
                        "mempertimbangkan konteks percakapan (pakai Gemini Nano kalau device " +
                        "mendukung, fallback ke terjemahan biasa kalau tidak). COPILOT: " +
                        "menambahkan saran balasan (Suggested Replies), dicoba berurutan lewat " +
                        "beberapa \"tier\" — lihat bagian AI Copilot di bawah."
                )
                HelpSection(
                    title = "AI Copilot (Suggested Replies) — urutan tier",
                    body = "1) Gemini Nano on-device via AICore — kalau device flagship yang " +
                        "didukung (mis. Pixel 8+, Galaxy S24+), tidak butuh apa pun tambahan. " +
                        "2) Remote (VPS milik kamu sendiri) — kalau URL sudah diisi di " +
                        "Pengaturan, transcript dikirim lewat jaringan ke server itu (bukan " +
                        "pihak ketiga). 3) Rule-based — jaring pengaman terakhir, selalu " +
                        "berhasil walau saranya generik."
                )
                HelpSection(
                    title = "Remote AI (VPS)",
                    body = "Diatur lewat \u2699\uFE0F Pengaturan. Isi URL server LLM di VPS " +
                        "kamu sendiri (mis. llama.cpp server, Ollama, atau vLLM yang expose " +
                        "endpoint OpenAI-compatible \"/v1/chat/completions\"), contoh: " +
                        "http://203.0.113.5:8080 — tanpa path, tanpa garis miring di akhir " +
                        "(boleh juga diisi sampai \"...:8080/v1\" kalau itu yang kamu pakai " +
                        "buat curl test — app ini otomatis mendeteksi biar tidak dobel jadi " +
                        "\"/v1/v1/chat/completions\"). API Key opsional (isi kalau server kamu " +
                        "butuh Authorization Bearer token). Nama Model opsional — kebanyakan " +
                        "server single-model mengabaikan field ini. Kosongkan URL untuk " +
                        "melewati tier ini sepenuhnya. Catatan: server VPS pribadi biasanya " +
                        "belum punya HTTPS, jadi http:// polos sengaja diizinkan " +
                        "(usesCleartextTraffic) — kalau VPS-nya diakses lewat internet publik " +
                        "(bukan cuma VPN/LAN pribadi), sangat disarankan pasang reverse proxy " +
                        "TLS gratis (mis. Caddy) di depannya."
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}

@Composable
private fun HelpSection(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Text(body, style = MaterialTheme.typography.bodySmall)
    }
}

/**
 * Kontrol untuk RemoteCopilotEngine (tier 2 COPILOT) — VPS milik user sendiri. Field disimpan
 * lokal dulu di Compose state, ditulis ke DataStore lewat tombol "Simpan" (bukan tiap keystroke)
 * supaya tidak nulis DataStore berkali-kali saat user masih mengetik.
 */
@Composable
private fun RemoteCopilotSection(viewModel: MainViewModel) {
    val savedUrl by viewModel.settings.remoteCopilotUrl.collectAsState(initial = null)
    val savedApiKey by viewModel.settings.remoteCopilotApiKey.collectAsState(initial = null)
    val savedModelName by viewModel.settings.remoteCopilotModelName.collectAsState(initial = "local-model")

    var urlInput by remember(savedUrl) { mutableStateOf(savedUrl ?: "") }
    var apiKeyInput by remember(savedApiKey) { mutableStateOf(savedApiKey ?: "") }
    var modelNameInput by remember(savedModelName) { mutableStateOf(savedModelName) }
    var showApiKey by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Remote AI (VPS sendiri, opsional)", style = MaterialTheme.typography.titleMedium)
        Text(
            if (savedUrl.isNullOrBlank()) {
                "Belum dikonfigurasi — tier ini dilewati. Ketuk \u2753 untuk cara setup."
            } else {
                "\u2705 Aktif: $savedUrl"
            },
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = urlInput,
            onValueChange = { urlInput = it; saved = false },
            label = { Text("URL VPS (mis. http://203.0.113.5:8080)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = apiKeyInput,
            onValueChange = { apiKeyInput = it; saved = false },
            label = { Text("API Key (opsional)") },
            singleLine = true,
            visualTransformation = if (showApiKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                TextButton(onClick = { showApiKey = !showApiKey }) {
                    Text(if (showApiKey) "Sembunyikan" else "Lihat", style = MaterialTheme.typography.labelSmall)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = modelNameInput,
            onValueChange = { modelNameInput = it; saved = false },
            label = { Text("Nama Model (opsional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                viewModel.setRemoteCopilotUrl(urlInput.trim().ifBlank { null })
                viewModel.setRemoteCopilotApiKey(apiKeyInput.trim().ifBlank { null })
                viewModel.setRemoteCopilotModelName(modelNameInput.trim().ifBlank { "local-model" })
                saved = true
            }) { Text("Simpan") }
            if (saved) {
                Text("\u2705 Tersimpan", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/**
 * Kontrol untuk GroqWhisperSttEngine — solusi STT cloud yang cepat & akurat, TANPA butuh
 * setting apa pun di luar app (beda dari on-device recognition yang tergantung komponen OS
 * seperti Android System Intelligence, yang ternyata tidak selalu tersedia — lihat riwayat
 * panjang troubleshooting soal ini). Kosongkan API key untuk kembali ke SpeechRecognizer
 * bawaan Android seperti sebelumnya (fallback otomatis, bukan error).
 */
@Composable
private fun CloudSttSection(viewModel: MainViewModel) {
    val savedApiKey by viewModel.settings.cloudSttApiKey.collectAsState(initial = null)
    var apiKeyInput by remember(savedApiKey) { mutableStateOf(savedApiKey ?: "") }
    var showApiKey by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Cloud Speech-to-Text (Groq, opsional)", style = MaterialTheme.typography.titleMedium)
        Text(
            if (savedApiKey.isNullOrBlank()) {
                "Belum diisi — pakai SpeechRecognizer bawaan Android (kualitas tergantung " +
                    "device). Kalau muncul \"Speech recognition unavailable\" terus, isi API " +
                    "key gratis dari console.groq.com di sini — jauh lebih cepat & akurat, " +
                    "termasuk untuk Bahasa Indonesia."
            } else {
                "\u2705 Aktif — mic sekarang pakai Groq Whisper (cloud, butuh internet)."
            },
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = apiKeyInput,
            onValueChange = { apiKeyInput = it; saved = false },
            label = { Text("Groq API Key") },
            singleLine = true,
            visualTransformation = if (showApiKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                TextButton(onClick = { showApiKey = !showApiKey }) {
                    Text(if (showApiKey) "Sembunyikan" else "Lihat", style = MaterialTheme.typography.labelSmall)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                viewModel.setCloudSttApiKey(apiKeyInput.trim().ifBlank { null })
                saved = true
            }) { Text("Simpan") }
            if (saved) {
                Text("\u2705 Tersimpan", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}



