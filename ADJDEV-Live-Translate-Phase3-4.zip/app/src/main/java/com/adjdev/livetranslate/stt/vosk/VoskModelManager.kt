package com.adjdev.livetranslate.stt.vosk

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

/**
 * Model resmi yang tersedia untuk STT System Audio (Phase 3.1: integrasi Vosk).
 *
 * CATATAN KEJUJURAN PENTING (jangan dihapus): per pengecekan katalog resmi
 * https://alphacephei.com/vosk/models (Agustus 2026), Vosk TIDAK punya model Bahasa
 * Indonesia resmi. Daftar [SUPPORTED] di bawah sudah diperluas dari cuma English ke
 * beberapa bahasa umum lain yang PUNYA model kecil resmi (Mandarin, Jepang, Korea,
 * Prancis, Jerman, Spanyol, Arab, Hindi, Vietnam) — tapi Indonesia tetap tidak ada.
 *
 * Implikasi buat use case app ini: System Audio STT bisa mentranskripsi audio dalam
 * bahasa-bahasa di atas. Kalau lawan bicara berbahasa Indonesia, mode System Audio tetap
 * bisa diaktifkan tapi transkrip tidak akan muncul untuk audio berbahasa itu — TIDAK ada
 * fallback diam-diam ke model lain yang salah.
 */
object VoskModelCatalog {
    data class ModelInfo(
        val languageTag: String,
        val displayName: String,
        val downloadUrl: String,
        val approxSizeMb: Int
    )

    val SUPPORTED: Map<String, ModelInfo> = listOf(
        ModelInfo(
            languageTag = "en",
            displayName = "English (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip",
            approxSizeMb = 40
        ),
        // Ditambahkan atas permintaan user (butuh Mandarin untuk fitur pinyin di Suggested
        // Replies) — dan ini KEBETULAN salah satu dari sedikit bahasa yang punya model kecil
        // resmi di katalog Vosk, jadi aman ditambahkan tanpa isu lisensi/kualitas tak jelas.
        ModelInfo(
            languageTag = "zh",
            displayName = "Mandarin / Chinese (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-cn-0.22.zip",
            approxSizeMb = 42
        ),
        ModelInfo(
            languageTag = "ja",
            displayName = "Japanese (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-ja-0.22.zip",
            approxSizeMb = 48
        ),
        ModelInfo(
            languageTag = "ko",
            displayName = "Korean (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-ko-0.22.zip",
            approxSizeMb = 82
        ),
        ModelInfo(
            languageTag = "fr",
            displayName = "French (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-fr-0.22.zip",
            approxSizeMb = 41
        ),
        ModelInfo(
            languageTag = "de",
            displayName = "German (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-de-0.15.zip",
            approxSizeMb = 45
        ),
        ModelInfo(
            languageTag = "es",
            displayName = "Spanish (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip",
            approxSizeMb = 39
        ),
        ModelInfo(
            languageTag = "ar",
            displayName = "Arabic (MGB2)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-ar-mgb2-0.4.zip",
            approxSizeMb = 318
        ),
        ModelInfo(
            languageTag = "hi",
            displayName = "Hindi (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip",
            approxSizeMb = 42
        ),
        ModelInfo(
            languageTag = "vi",
            displayName = "Vietnamese (small)",
            downloadUrl = "https://alphacephei.com/vosk/models/vosk-model-small-vn-0.4.zip",
            approxSizeMb = 32
        )
        // "id" (Bahasa Indonesia) SENGAJA TIDAK ADA — lihat catatan kejujuran di atas kelas
        // ini, katalog resmi Vosk memang belum punya model Indonesia. Kalau audio sumbernya
        // Bahasa Indonesia, System Audio tetap bisa diaktifkan (capture audio mentah jalan),
        // tapi transkrip tidak akan muncul untuk bahasa itu. Opsi realistis untuk menutup gap
        // ini TANPA menunggu Vosk merilis model resmi: pakai Whisper (mendukung Indonesian
        // dengan baik) lewat server sendiri di VPS yang sudah ada — arsitekturnya mirip
        // RemoteCopilotEngine, belum dikerjakan, tanya dulu ke Claude kalau mau ini dibangun.
    ).associateBy { it.languageTag }
}

sealed class ModelPrepStatus {
    data object AlreadyReady : ModelPrepStatus()
    data class Downloading(val bytesDownloaded: Long, val totalBytes: Long) : ModelPrepStatus()
    data object Extracting : ModelPrepStatus()
    data object Ready : ModelPrepStatus()
    data class Failed(val message: String) : ModelPrepStatus()
    data class Unsupported(val languageTag: String) : ModelPrepStatus()
}

/**
 * Unduh sekali + unzip model Vosk ke penyimpanan internal app (`filesDir/vosk-models/<tag>`,
 * bukan penyimpanan eksternal — jadi tidak perlu izin storage tambahan). Idempotent: kalau
 * folder model untuk [languageTag] sudah ada & tidak kosong, langsung emit AlreadyReady tanpa
 * mengunduh ulang.
 */
class VoskModelManager(private val context: Context) {

    fun modelDir(languageTag: String): File =
        File(context.filesDir, "vosk-models/$languageTag")

    fun isModelReady(languageTag: String): Boolean {
        val dir = modelDir(languageTag)
        // Vosk butuh folder model berisi minimal am/, conf/, graph/ — cek kasar salah satu
        // penanda supaya folder setengah-unduh (proses sebelumnya mati di tengah) tidak
        // dianggap valid.
        return dir.isDirectory && File(dir, "conf").isDirectory && File(dir, "am").isDirectory
    }

    fun prepare(languageTag: String): Flow<ModelPrepStatus> = flow {
        val info = VoskModelCatalog.SUPPORTED[languageTag]
        if (info == null) {
            emit(ModelPrepStatus.Unsupported(languageTag))
            return@flow
        }

        if (isModelReady(languageTag)) {
            emit(ModelPrepStatus.AlreadyReady)
            return@flow
        }

        val targetDir = modelDir(languageTag)
        val tmpZip = File(context.cacheDir, "vosk-download-$languageTag.zip")

        // FIX crash "Flow exception transparency is violated": sebelumnya emit(Failed(...))
        // dipanggil langsung di dalam blok `catch` — Kotlin Flow SENGAJA melarang itu ("Emissions
        // from 'catch' blocks are prohibited", lihat pesan errornya sendiri) karena bisa
        // menyembunyikan exception asli. Di sini exception cuma DITANGKAP jadi variabel biasa,
        // emit-nya baru terjadi belakangan di luar try/catch — flow builder tetap 1 sumber emit.
        val failureMessage: String? = try {
            downloadWithProgress(info.downloadUrl, tmpZip) { downloaded, total ->
                emit(ModelPrepStatus.Downloading(downloaded, total))
            }
            emit(ModelPrepStatus.Extracting)
            targetDir.deleteRecursively()
            targetDir.mkdirs()
            unzipStrippingTopLevel(tmpZip, targetDir)
            null
        } catch (e: Exception) {
            targetDir.deleteRecursively()
            e.message ?: "Gagal mengunduh model bahasa."
        } finally {
            tmpZip.delete()
        }

        if (failureMessage != null) {
            emit(ModelPrepStatus.Failed(failureMessage))
        } else {
            emit(ModelPrepStatus.Ready)
        }
    }.flowOn(Dispatchers.IO)

    /**
     * FIX crash yang sama, penyebab kedua: sebelumnya method ini dibungkus
     * `withContext(Dispatchers.IO)` sendiri, padahal flow{} pemanggilnya SUDAH dijalankan di
     * Dispatchers.IO lewat `.flowOn(Dispatchers.IO)` di atas. Nested withContext(IO) di dalam
     * IO itu membuat coroutine context "baru" (job berbeda) di mata SafeCollector Flow, jadi
     * saat [onProgress] (lambda yang isinya emit()) dipanggil dari sini, konteksnya tidak lagi
     * identik dengan konteks tempat flow di-collect — persis error "Flow was collected in [...]
     * but emission happened in [...]" di stack trace crash report. Fix: TIDAK ada withContext
     * di sini sama sekali; blocking I/O di bawah ini memang otomatis jalan di thread
     * Dispatchers.IO karena diwariskan dari flow pemanggilnya.
     */
    private suspend fun downloadWithProgress(
        url: String,
        target: File,
        onProgress: suspend (downloaded: Long, total: Long) -> Unit
    ) {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 15_000
        }
        connection.connect()
        if (connection.responseCode != HttpURLConnection.HTTP_OK) {
            throw IllegalStateException("Unduh model gagal (HTTP ${connection.responseCode}).")
        }
        val total = connection.contentLengthLong
        connection.inputStream.use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var downloaded = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    downloaded += read
                    onProgress(downloaded, total)
                }
            }
        }
    }

    /**
     * Zip Vosk resmi berisi satu folder root (mis. "vosk-model-small-en-us-0.15/...") —
     * di-strip di sini supaya [targetDir] langsung berisi am/, conf/, graph/ dst tanpa
     * folder pembungkus (constructor org.vosk.Model butuh path ke folder yang isinya
     * langsung file-file model itu).
     */
    private fun unzipStrippingTopLevel(zipFile: File, targetDir: File) {
        ZipInputStream(zipFile.inputStream().buffered()).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val name = entry.name
                val withoutRoot = name.substringAfter('/', missingDelimiterValue = "")
                if (withoutRoot.isNotEmpty()) {
                    val outFile = File(targetDir, withoutRoot)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        outFile.outputStream().use { out -> zis.copyTo(out) }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
