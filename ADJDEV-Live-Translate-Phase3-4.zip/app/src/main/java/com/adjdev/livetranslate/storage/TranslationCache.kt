package com.adjdev.livetranslate.storage

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONObject

private val Context.cacheDataStore by preferencesDataStore(name = "adjdev_live_translate_cache")

/**
 * Cache LRU untuk frasa yang sering diterjemahkan. In-memory untuk akses cepat di fast path
 * (spesifikasi #11: tidak boleh menunggu I/O), dan di-persist ke DataStore secara asinkron
 * di background agar cache bertahan lintas restart aplikasi (Phase 2).
 *
 * Dibatasi ukurannya (maxEntries) agar tidak membengkakkan RAM maupun storage (spesifikasi #16).
 */
class TranslationCache(
    private val context: Context? = null,
    private val maxEntries: Int = 200
) {
    companion object {
        private val CACHE_KEY = stringPreferencesKey("lru_cache_json")
    }

    private val map = object : LinkedHashMap<String, String>(maxEntries, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean {
            return size > maxEntries
        }
    }

    private val persistScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    init {
        if (context != null) {
            persistScope.launch { loadFromDisk() }
        }
    }

    @Synchronized
    fun get(sourceLang: String, targetLang: String, text: String): String? =
        map[key(sourceLang, targetLang, text)]

    fun put(sourceLang: String, targetLang: String, text: String, translated: String) {
        synchronized(this) { map[key(sourceLang, targetLang, text)] = translated }
        schedulePersist()
    }

    fun clear() {
        synchronized(this) { map.clear() }
        schedulePersist()
    }

    private fun key(sourceLang: String, targetLang: String, text: String) =
        "$sourceLang|$targetLang|${text.trim().lowercase()}"

    private suspend fun loadFromDisk() {
        val ctx = context ?: return
        runCatching {
            val json = ctx.cacheDataStore.data.first()[CACHE_KEY] ?: return
            val obj = JSONObject(json)
            synchronized(this) {
                obj.keys().forEach { k -> map[k] = obj.getString(k) }
            }
        }
    }

    // Persist dilakukan secara debounced-sederhana: setiap put/clear menjadwalkan satu
    // write di background, tidak pernah memblokir fast path translation.
    private fun schedulePersist() {
        val ctx = context ?: return
        persistScope.launch {
            val snapshot = synchronized(this@TranslationCache) { LinkedHashMap(map) }
            val obj = JSONObject()
            snapshot.forEach { (k, v) -> obj.put(k, v) }
            runCatching {
                ctx.cacheDataStore.edit { it[CACHE_KEY] = obj.toString() }
            }
        }
    }
}
