package com.adjdev.livetranslate.translation

sealed class TranslationOutcome {
    data class Success(val translatedText: String) : TranslationOutcome()
    data class Failure(val message: String) : TranslationOutcome()
}

/**
 * Kontrak mesin terjemahan. Implementasi Phase 1 memakai ML Kit Translate (on-device,
 * model diunduh sekali per pasangan bahasa lalu berjalan offline). Diabstraksi agar
 * dapat diganti ke model NMT kustom (TFLite/ONNX) di Phase 4 tanpa mengubah pipeline.
 */
interface TranslationEngine {
    suspend fun translate(
        text: String,
        sourceLanguageTag: String,
        targetLanguageTag: String
    ): TranslationOutcome

    /**
     * Sama seperti translate(), tapi boleh memakai `context` (baris-baris giliran percakapan
     * sebelumnya, urutan lama->baru) untuk menjaga konsistensi istilah/kata ganti orang/nada
     * bicara — dasar mode SMART (Phase 3). Default: abaikan context, delegasikan ke translate()
     * biasa. Engine yang tidak punya mekanisme context injection (mis. ML Kit Translate, NMT
     * klasik satu-kalimat) TIDAK PERLU meng-override ini.
     */
    suspend fun translateWithContext(
        text: String,
        sourceLanguageTag: String,
        targetLanguageTag: String,
        context: List<String>
    ): TranslationOutcome = translate(text, sourceLanguageTag, targetLanguageTag)

    /** Pastikan model untuk pasangan bahasa ini sudah terpasang di perangkat. */
    suspend fun ensureModelDownloaded(sourceLanguageTag: String, targetLanguageTag: String): Boolean

    fun release()
}
