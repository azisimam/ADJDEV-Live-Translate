package com.adjdev.livetranslate.translation

import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.prompt.Generation

/**
 * Implementasi SUNGGUHAN mode SMART (Phase 3) — sebelumnya (Phase 2) context percakapan
 * hanya dicatat tapi tidak pernah mempengaruhi hasil terjemahan, karena ML Kit Translate
 * adalah NMT klasik yang menerjemahkan satu kalimat berdiri sendiri dan TIDAK mendukung
 * context injection sama sekali (lihat catatan lama di README).
 *
 * Solusinya: untuk mode SMART, translateWithContext() mengirim beberapa giliran percakapan
 * terakhir sebagai bagian PROMPT ke Gemini Nano on-device (ML Kit GenAI Prompt API,
 * com.google.mlkit:genai-prompt) — model generatif kecil ini BISA menerima instruksi +
 * context, tidak seperti model NMT ML Kit Translate biasa. Hasilnya: istilah, kata ganti
 * orang, dan nada bicara bisa lebih konsisten antar giliran.
 *
 * FALLBACK BERLAPIS (translation adalah fast path, tidak boleh pernah diam/gagal total):
 *  1. Gemini Nano AVAILABLE di perangkat & generate sukses -> pakai hasil itu.
 *  2. Apa pun selain itu (UNAVAILABLE/belum diunduh/exception/output kosong) -> otomatis
 *     jatuh ke [fallback] (ML Kit Translate biasa, translate() tanpa context) — sama seperti
 *     mode LIGHT/COPILOT.
 * Mode LIGHT dan COPILOT TETAP memakai translate() biasa (tidak lewat sini sama sekali),
 * sesuai spesifikasi #11: fast path tidak boleh tergantung proses AI.
 *
 * SENGAJA TIDAK memicu unduhan Gemini Nano otomatis (beda dengan ensureModelDownloaded()
 * untuk ML Kit Translate yang memang kecil ~30MB): model Gemini Nano jauh lebih besar dan
 * kalau device berstatus DOWNLOADABLE, memaksa unduh diam-diam di tengah live conversation
 * user bisa menghabiskan kuota tanpa izin. Untuk perangkat begitu, SMART otomatis berperilaku
 * sama seperti LIGHT (fallback) sampai fitur benar-benar AVAILABLE.
 *
 * CATATAN KEJUJURAN: ditulis mengikuti dokumentasi resmi Prompt API Google per Jan 2026
 * (developers.google.com/ml-kit/genai/prompt/android/get-started). API ini masih beta/alpha
 * dan HANYA berjalan di perangkat yang didukung AICore (sebagian flagship 2024+ — Pixel,
 * Galaxy S25/S26, sebagian Oppo/Honor/Poco terbaru; lihat daftar resmi ML Kit GenAI). Target
 * spesifikasi awal (kelas menengah, mis. Redmi Note 13 4G) kemungkinan besar TIDAK termasuk,
 * sehingga checkStatus() akan UNAVAILABLE dan SMART otomatis berperilaku sama seperti LIGHT
 * di perangkat itu — bukan bug, memang begitu desainnya. Belum pernah dikompilasi/dites di
 * device nyata (sandbox pembuatan tidak punya Android SDK/internet, sama seperti Phase 1/2).
 */
class ContextAwareTranslationEngine(
    private val fallback: TranslationEngine = MlKitTranslationEngine()
) : TranslationEngine {

    private val model by lazy { Generation.getClient() }

    // Cache hasil pengecekan supaya tidak checkStatus() di setiap kalimat (biaya IPC ke AICore).
    // null = belum pernah dicek pada sesi translator ini.
    private var nanoAvailable: Boolean? = null

    override suspend fun translate(
        text: String,
        sourceLanguageTag: String,
        targetLanguageTag: String
    ): TranslationOutcome = fallback.translate(text, sourceLanguageTag, targetLanguageTag)

    override suspend fun translateWithContext(
        text: String,
        sourceLanguageTag: String,
        targetLanguageTag: String,
        context: List<String>
    ): TranslationOutcome {
        if (context.isEmpty() || !ensureNanoAvailable()) {
            return fallback.translate(text, sourceLanguageTag, targetLanguageTag)
        }
        return try {
            val contextBlock = context.takeLast(6).joinToString("\n") { "- $it" }
            val prompt = """
                Terjemahkan HANYA kalimat terakhir di bawah ini dari bahasa "$sourceLanguageTag"
                ke bahasa "$targetLanguageTag". Baris "Konteks" di bawah cuma referensi supaya
                istilah, kata ganti orang, dan nada bicara konsisten dengan giliran sebelumnya —
                JANGAN menerjemahkan ulang atau menyebut ulang baris konteks itu di jawabanmu.

                Konteks (giliran-giliran sebelumnya, lama ke baru):
                $contextBlock

                Kalimat yang perlu diterjemahkan sekarang:
                "$text"

                Balas HANYA dengan hasil terjemahannya saja, satu baris, tanpa tanda kutip,
                tanpa penjelasan tambahan.
            """.trimIndent()

            val response = model.generateContent(prompt)
            val translated = response.candidates.firstOrNull()?.text
                ?.trim()
                ?.trim('"', '“', '”')

            if (translated.isNullOrBlank()) {
                fallback.translate(text, sourceLanguageTag, targetLanguageTag)
            } else {
                TranslationOutcome.Success(translated)
            }
        } catch (e: Exception) {
            // Diam-diam jatuh ke fallback — fast path tidak boleh terganggu oleh kegagalan AI.
            fallback.translate(text, sourceLanguageTag, targetLanguageTag)
        }
    }

    private suspend fun ensureNanoAvailable(): Boolean {
        nanoAvailable?.let { return it }
        val available = try {
            model.checkStatus() == FeatureStatus.AVAILABLE
        } catch (e: Exception) {
            false
        }
        nanoAvailable = available
        return available
    }

    override suspend fun ensureModelDownloaded(
        sourceLanguageTag: String,
        targetLanguageTag: String
    ): Boolean = fallback.ensureModelDownloaded(sourceLanguageTag, targetLanguageTag)

    override fun release() {
        fallback.release()
        nanoAvailable = null // re-cek Gemini Nano lagi di sesi translator berikutnya
    }
}
