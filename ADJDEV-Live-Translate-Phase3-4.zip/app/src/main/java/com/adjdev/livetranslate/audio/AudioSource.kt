package com.adjdev.livetranslate.audio

import kotlinx.coroutines.flow.Flow

/**
 * Kontrak umum untuk sumber audio (mic / system audio).
 * Implementasi HARUS berhenti total (release resource) saat stop() dipanggil,
 * dan tidak boleh membaca audio ketika source dinonaktifkan (lihat prinsip Anti Self-Capture).
 */
interface AudioSource {

    /** Sedang aktif menangkap audio atau tidak. */
    val isCapturing: Boolean

    /**
     * Mulai capture. Mengembalikan Flow dari potongan audio PCM 16-bit mono.
     * Flow ini harus cold: tidak melakukan apa pun sebelum di-collect,
     * dan berhenti membaca hardware saat collector di-cancel.
     */
    fun start(): Flow<AudioChunk>

    /** Hentikan capture dan lepaskan seluruh resource (AudioRecord, dsb). */
    fun stop()
}

/** Satu potongan audio mentah beserta metadata minimum yang dibutuhkan VAD/STT. */
data class AudioChunk(
    val samples: ShortArray,
    val sampleRateHz: Int,
    val source: AudioSourceType
) {
    override fun equals(other: Any?): Boolean = this === other
    override fun hashCode(): Int = System.identityHashCode(this)
}

enum class AudioSourceType { MICROPHONE, SYSTEM_AUDIO }
