package com.adjdev.livetranslate.detection

import com.google.mlkit.nl.languageid.LanguageIdentification
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Deteksi bahasa on-device via ML Kit Language ID. Model berukuran kecil (~kB),
 * berjalan sepenuhnya di perangkat setelah terpasang bersama library — tidak
 * memerlukan koneksi internet saat runtime.
 */
class MlKitLanguageDetector : LanguageDetector {

    private val identifier = LanguageIdentification.getClient()

    override suspend fun detect(text: String): String? = suspendCancellableCoroutine { cont ->
        if (text.isBlank()) {
            cont.resume(null)
            return@suspendCancellableCoroutine
        }
        identifier.identifyLanguage(text)
            .addOnSuccessListener { code ->
                cont.resume(if (code == "und") null else code)
            }
            .addOnFailureListener {
                cont.resume(null)
            }
    }
}
