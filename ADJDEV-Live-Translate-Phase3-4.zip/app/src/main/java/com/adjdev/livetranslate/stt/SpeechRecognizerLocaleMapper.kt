package com.adjdev.livetranslate.stt

/**
 * android.speech.SpeechRecognizer (lewat RecognizerIntent.EXTRA_LANGUAGE) di banyak perangkat
 * TIDAK menerima kode bahasa pendek polos (mis. "ja", "zh") — butuh locale BCP-47 lengkap
 * (mis. "ja-JP", "zh-CN"). Sebelumnya kode pendek dari LanguageCatalog dikirim apa adanya,
 * yang kemungkinan besar penyebab "Speech recognition unavailable." muncul untuk semua bahasa
 * selain default sistem.
 *
 * CATATAN: kalau "Speech recognition unavailable." masih muncul SETELAH fix ini untuk SEMUA
 * bahasa (termasuk English), itu tanda masalahnya BUKAN di sini — kemungkinan besar recognizer
 * on-device tidak tersedia (device belum download model offline-nya lewat Settings > System >
 * Languages > On-device speech recognition) DAN recognizer cloud fallback tidak dapat internet
 * (mis. mode pesawat, seperti terlihat di screenshot laporan bug). Cek dua hal itu dulu di HP.
 */
object SpeechRecognizerLocaleMapper {

    private val OVERRIDES = mapOf(
        "en" to "en-US",
        "id" to "id-ID",
        "zh" to "zh-CN",
        "ja" to "ja-JP",
        "ko" to "ko-KR",
        "fr" to "fr-FR",
        "de" to "de-DE",
        "es" to "es-ES",
        "pt" to "pt-PT",
        "it" to "it-IT",
        "nl" to "nl-NL",
        "ru" to "ru-RU",
        "ar" to "ar-SA",
        "hi" to "hi-IN",
        "vi" to "vi-VN",
        "th" to "th-TH",
        "ms" to "ms-MY",
        "tr" to "tr-TR",
        "pl" to "pl-PL"
    )

    /** tag null (auto-detect) diteruskan apa adanya — biar SpeechRecognizer pakai default sistem. */
    fun toRecognizerLocale(tag: String?): String? {
        if (tag == null) return null
        // Kalau sudah ada '-' (berarti sudah locale lengkap atau tag rusak macam "ja-Latn"),
        // ambil cuma subtag bahasa dan re-map — jangan kirim mentah-mentah.
        val primary = tag.substringBefore('-')
        return OVERRIDES[primary] ?: primary
    }
}
