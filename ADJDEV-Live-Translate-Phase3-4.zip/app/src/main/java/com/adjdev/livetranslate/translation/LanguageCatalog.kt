package com.adjdev.livetranslate.translation

/**
 * Daftar bahasa yang ditawarkan di language picker UI. Kode diambil dari yang didukung
 * ML Kit Translate (com.google.mlkit.nl.translate.TranslateLanguage) — dipakai sebagai string
 * biasa di sini (bukan import langsung ke TranslateLanguage) supaya file ini tetap ringan
 * dibaca & tidak bikin MainActivity/UI layer bergantung ke ML Kit secara langsung.
 *
 * Ini BUKAN daftar lengkap 59 bahasa yang didukung ML Kit — dikurasi ke bahasa yang paling
 * mungkin dipakai (termasuk semua yang juga punya model Vosk untuk System Audio, plus
 * beberapa bahasa besar lain). Gampang ditambah kalau perlu.
 */
object LanguageCatalog {
    data class LanguageOption(val tag: String, val displayName: String)

    val ALL: List<LanguageOption> = listOf(
        LanguageOption("id", "Bahasa Indonesia"),
        LanguageOption("en", "English"),
        LanguageOption("zh", "中文 (Chinese)"),
        LanguageOption("ja", "日本語 (Japanese)"),
        LanguageOption("ko", "한국어 (Korean)"),
        LanguageOption("ar", "العربية (Arabic)"),
        LanguageOption("hi", "हिन्दी (Hindi)"),
        LanguageOption("vi", "Tiếng Việt (Vietnamese)"),
        LanguageOption("th", "ไทย (Thai)"),
        LanguageOption("ms", "Bahasa Melayu (Malay)"),
        LanguageOption("fr", "Français (French)"),
        LanguageOption("de", "Deutsch (German)"),
        LanguageOption("es", "Español (Spanish)"),
        LanguageOption("pt", "Português (Portuguese)"),
        LanguageOption("it", "Italiano (Italian)"),
        LanguageOption("nl", "Nederlands (Dutch)"),
        LanguageOption("ru", "Русский (Russian)"),
        LanguageOption("tr", "Türkçe (Turkish)"),
        LanguageOption("pl", "Polski (Polish)")
    )

    fun displayNameFor(tag: String): String =
        ALL.firstOrNull { it.tag == tag }?.displayName ?: tag.uppercase()
}
