package com.adjdev.livetranslate

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.livetranslate.settings.SettingsRepository
import com.adjdev.livetranslate.settings.TranslationMode
import com.adjdev.livetranslate.translation.MlKitTranslationEngine
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val settings = SettingsRepository(application.applicationContext)

    // Instance terpisah dari yang dipakai TranslationPipeline di OverlayService — ML Kit
    // Translate menyimpan model yang sudah diunduh di storage internal per app (bukan per
    // instance Translator), jadi aman punya instance sendiri di sini khusus untuk tombol
    // "Download" di UI, terlepas translator sedang berjalan atau tidak.
    private val downloadOnlyTranslationEngine = MlKitTranslationEngine()

    fun setMicOn(value: Boolean) = viewModelScope.launch { settings.setMicOn(value) }
    fun setSystemAudioOn(value: Boolean) = viewModelScope.launch { settings.setSystemAudioOn(value) }
    fun setAutoDetect(value: Boolean) = viewModelScope.launch { settings.setAutoDetect(value) }
    fun setTargetLanguage(tag: String) = viewModelScope.launch { settings.setTargetLanguage(tag) }
    fun setSourceLanguage(tag: String) = viewModelScope.launch { settings.setSourceLanguage(tag) }
    fun setMode(mode: TranslationMode) = viewModelScope.launch { settings.setTranslationMode(mode) }
    fun setRemoteCopilotUrl(value: String?) = viewModelScope.launch { settings.setRemoteCopilotUrl(value) }
    fun setRemoteCopilotApiKey(value: String?) = viewModelScope.launch { settings.setRemoteCopilotApiKey(value) }
    fun setCloudSttApiKey(value: String?) = viewModelScope.launch { settings.setCloudSttApiKey(value) }
    fun setRemoteCopilotModelName(value: String) = viewModelScope.launch { settings.setRemoteCopilotModelName(value) }

    /** Unduh model terjemahan untuk satu pasangan bahasa lebih awal (sebelum mulai bicara). */
    suspend fun downloadLanguagePair(sourceTag: String, targetTag: String): Boolean =
        downloadOnlyTranslationEngine.ensureModelDownloaded(sourceTag, targetTag)

    /** Balik arah terjemahan: source <-> target. Otomatis mematikan auto-detect (spesifikasi
     * jelas: setelah swap, arah sudah eksplisit dipilih user, bukan lagi "AUTO"). */
    fun swapLanguages(currentSource: String, currentTarget: String) = viewModelScope.launch {
        val effectiveSource = if (currentSource == "auto") "en" else currentSource
        settings.setSourceLanguage(currentTarget)
        settings.setTargetLanguage(effectiveSource)
        settings.setAutoDetect(false)
    }
}
