package com.adjdev.livetranslate.translation

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Menerjemahkan secara on-device via ML Kit Translate. Model per pasangan bahasa
 * (~30MB) diunduh sekali (butuh internet saat itu saja, idealnya via WiFi — lihat
 * DownloadConditions), lalu seluruh proses terjemahan berjalan lokal di perangkat.
 *
 * Client di-cache per pasangan bahasa agar tidak membuat objek Translator baru
 * (dan memuat ulang model) untuk setiap kalimat, sesuai prinsip hemat RAM/CPU.
 */
class MlKitTranslationEngine : TranslationEngine {

    private val clientCache = LinkedHashMap<String, Translator>()
    private val maxCachedClients = 3 // batasi agar tidak menahan banyak model di RAM sekaligus

    override suspend fun ensureModelDownloaded(
        sourceLanguageTag: String,
        targetLanguageTag: String
    ): Boolean = suspendCancellableCoroutine { cont ->
        val client = clientFor(sourceLanguageTag, targetLanguageTag) ?: run {
            cont.resume(false)
            return@suspendCancellableCoroutine
        }
        // Sebelumnya .requireWifi() — kalau perangkat sedang di data seluler, task ini
        // menggantung tanpa sukses/gagal sampai WiFi tersedia, dan translate() yang dipanggil
        // sebelum model siap gagal dengan pesan "Translation model files not found" (persis
        // bug yang dilaporkan). Sekarang tanpa syarat WiFi; unduhan ~30MB per pasangan bahasa
        // tetap hanya terjadi sekali.
        val conditions = DownloadConditions.Builder().build()
        client.downloadModelIfNeeded(conditions)
            .addOnSuccessListener { cont.resume(true) }
            .addOnFailureListener { cont.resume(false) }
    }

    override suspend fun translate(
        text: String,
        sourceLanguageTag: String,
        targetLanguageTag: String
    ): TranslationOutcome = suspendCancellableCoroutine { cont ->
        val client = clientFor(sourceLanguageTag, targetLanguageTag)
        if (client == null) {
            cont.resume(TranslationOutcome.Failure("Bahasa tidak didukung: $sourceLanguageTag -> $targetLanguageTag"))
            return@suspendCancellableCoroutine
        }
        client.translate(text)
            .addOnSuccessListener { result -> cont.resume(TranslationOutcome.Success(result)) }
            .addOnFailureListener { e ->
                cont.resume(TranslationOutcome.Failure(e.message ?: "Local model unavailable."))
            }
    }

    private fun clientFor(sourceLanguageTag: String, targetLanguageTag: String): Translator? {
        // Sanitasi defensif: ambil cuma subtag bahasa utama (sebelum '-' pertama). Ini
        // menutup bug dari build sebelumnya di mana tag rusak semacam "ja-Latn" (bukan "ja"
        // polos) sempat terkirim ke sini dan bikin TranslateLanguage.fromLanguageTag() gagal
        // resolve -> translate/download selalu gagal untuk pasangan bahasa itu. Apa pun
        // sumber tag-nya (picker, locale Android, dll), fungsi ini sekarang tahan terhadap
        // subtag script/region ekstra.
        val srcCode = TranslateLanguage.fromLanguageTag(sourceLanguageTag.substringBefore('-')) ?: return null
        val tgtCode = TranslateLanguage.fromLanguageTag(targetLanguageTag.substringBefore('-')) ?: return null
        val key = "$srcCode-$tgtCode"

        clientCache[key]?.let { return it }

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(srcCode)
            .setTargetLanguage(tgtCode)
            .build()
        val client = Translation.getClient(options)

        if (clientCache.size >= maxCachedClients) {
            val oldestKey = clientCache.keys.first()
            clientCache.remove(oldestKey)?.close()
        }
        clientCache[key] = client
        return client
    }

    override fun release() {
        clientCache.values.forEach { it.close() }
        clientCache.clear()
    }
}
