package com.adjdev.livetranslate.stt.vosk

import com.adjdev.livetranslate.audio.AudioChunk
import com.adjdev.livetranslate.stt.TranscriptResult
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/**
 * Kontrak STT berbasis PCM streaming — BEDA dari [com.adjdev.livetranslate.stt.SpeechRecognizerEngine]
 * yang mengasumsikan engine memegang mic sendiri (android.speech.SpeechRecognizer). Di sini
 * caller (TranslationPipeline) yang menyodorkan AudioChunk satu per satu lewat [accept] —
 * cocok untuk audio yang sumbernya BUKAN mic langsung, mis. SystemAudioSource.
 */
interface PcmSttEngine {
    val isReady: Boolean

    /** Muat model untuk [languageTag]. Wajib sudah di-download (lihat VoskModelManager). */
    fun start(languageTag: String): Boolean

    /**
     * Sodorkan satu chunk audio. Return null kalau belum ada hasil baru (masih partial sama
     * seperti sebelumnya, atau chunk sunyi). isFinal=true berarti Vosk mendeteksi akhir
     * kalimat (endpointing internal) — chunk dari kalimat sebelumnya sudah "ditutup", sama
     * konsepnya seperti hasil final dari android.speech.SpeechRecognizer.
     */
    fun accept(chunk: AudioChunk): TranscriptResult?

    fun stop()
}

/**
 * Implementasi [PcmSttEngine] pakai Vosk (org.vosk:vosk-android, lihat build.gradle.kts).
 * CATATAN KEJUJURAN (sama seperti GeminiNanoCopilotEngine/ContextAwareTranslationEngine):
 * ditulis mengikuti API publik Vosk Android per dokumentasi resmi Agustus 2026, belum pernah
 * dikompilasi/dites di device nyata (tidak ada Android SDK/emulator di sandbox pembuatan kode
 * ini). Titik pertama yang perlu dicek manual kalau ada crash: constructor Model(path) di
 * thread mana ia dipanggil (Vosk merekomendasikan bukan main thread untuk load model karena
 * bisa makan waktu >1 detik) dan apakah proguard-rules.pro perlu -keep untuk org.vosk.* saat
 * isMinifyEnabled (release build) — lihat proguard-rules.pro.
 *
 * Sample rate WAJIB sama persis dengan yang dipakai saat model dilatih Vosk untuk model
 * wideband kecil (16000 Hz) — kebetulan ini juga SAMPLE_RATE_HZ yang sudah dipakai
 * SystemAudioSource, jadi tidak perlu resampling.
 */
class VoskPcmSttEngine(private val modelManager: VoskModelManager) : PcmSttEngine {

    companion object {
        private const val SAMPLE_RATE_HZ = 16_000f
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null

    // Vosk partialResult() balikin JSON walau isinya belum berubah — dibandingkan ke nilai
    // terakhir supaya TranscriptResult tidak di-emit berulang untuk teks partial yang sama
    // (TranslationPipeline men-debounce translate dari partial text tiap kali state berubah).
    private var lastPartialText: String = ""

    override val isReady: Boolean get() = recognizer != null

    override fun start(languageTag: String): Boolean {
        stop()
        if (!modelManager.isModelReady(languageTag)) return false
        return try {
            val loadedModel = Model(modelManager.modelDir(languageTag).absolutePath)
            val rec = Recognizer(loadedModel, SAMPLE_RATE_HZ)
            model = loadedModel
            recognizer = rec
            lastPartialText = ""
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    override fun accept(chunk: AudioChunk): TranscriptResult? {
        val rec = recognizer ?: return null
        val bytes = shortsToLittleEndianBytes(chunk.samples)
        val isFinalSentence = try {
            rec.acceptWaveForm(bytes, bytes.size)
        } catch (e: Exception) {
            return null
        }

        return if (isFinalSentence) {
            lastPartialText = ""
            val text = extractText(rec.result, key = "text")
            if (text.isBlank()) null else TranscriptResult(text = text, isFinal = true)
        } else {
            val partial = extractText(rec.partialResult, key = "partial")
            if (partial.isBlank() || partial == lastPartialText) {
                null
            } else {
                lastPartialText = partial
                TranscriptResult(text = partial, isFinal = false)
            }
        }
    }

    override fun stop() {
        // Ambil sisa hasil yang mungkin masih "mengambang" di buffer internal Vosk sebelum
        // dilepas — tapi diamkan hasilnya (bukan tanggung jawab stop() untuk emit; caller yang
        // mau flush terakhir bisa panggil accept() dgn chunk kosong sebelum stop kalau perlu).
        runCatching { recognizer?.close() }
        runCatching { model?.close() }
        recognizer = null
        model = null
        lastPartialText = ""
    }

    private fun extractText(json: String, key: String): String = try {
        JSONObject(json).optString(key, "").trim()
    } catch (e: Exception) {
        ""
    }

    /**
     * Vosk (JNI/Kaldi) mengharapkan PCM 16-bit little-endian mentah sebagai ByteArray, bukan
     * ShortArray Kotlin — AudioChunk.samples dari AudioRecord juga little-endian secara default
     * di Android, jadi konversinya murni reinterpretasi byte, bukan resampling.
     */
    private fun shortsToLittleEndianBytes(samples: ShortArray): ByteArray {
        val out = ByteArrayOutputStream(samples.size * 2)
        val dos = DataOutputStream(out)
        for (s in samples) {
            dos.writeByte(s.toInt() and 0xFF)
            dos.writeByte((s.toInt() shr 8) and 0xFF)
        }
        return out.toByteArray()
    }
}
