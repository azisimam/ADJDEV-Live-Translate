package com.adjdev.livetranslate.stt

import com.adjdev.livetranslate.audio.AudioSource
import com.adjdev.livetranslate.audio.WavEncoder
import com.adjdev.livetranslate.vad.EnergyVadEngine
import com.adjdev.livetranslate.vad.VoiceActivityDetector
import com.adjdev.livetranslate.vad.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * STT via Groq Whisper API (endpoint OpenAI-compatible "/v1/audio/transcriptions", model
 * whisper-large-v3-turbo). Dipilih sebagai solusi utama untuk device yang TIDAK punya
 * on-device speech recognition lengkap (banyak device non-Pixel, termasuk sebagian besar
 * ROM Xiaomi/MIUI) — lihat riwayat troubleshooting panjang soal "Speech recognition
 * unavailable" di semua bahasa.
 *
 * Kenapa ini, bukan Vosk (yang sudah dipakai System Audio): Vosk TIDAK punya model Bahasa
 * Indonesia resmi (lihat catatan di VoskModelManager), padahal itu bahasa utama use case app
 * ini. Whisper (basis Groq) multibahasa kuat termasuk Indonesian, dan Groq API gratis 2000
 * request/hari tanpa kartu kredit, jauh lebih cepat dari real-time (~228x).
 *
 * ARSITEKTUR BEDA dari AndroidSpeechRecognizerEngine: Whisper API itu BATCH (kirim satu
 * potongan audio utuh, terima satu transkrip utuh) — TIDAK ada partial/incremental result
 * seperti SpeechRecognizer. Jadi kelas ini pakai MicAudioSource + VAD sendiri (BUKAN
 * konflik dengan SpeechRecognizer lagi karena kita TIDAK memakainya sama sekali di jalur
 * ini): rekam PCM selama VAD bilang SPEECH, begitu SILENCE terdeteksi cukup lama anggap
 * kalimat selesai, upload, emit hasilnya sebagai TranscriptResult(isFinal = true).
 * Konsekuensinya: overlay tidak update kata-per-kata saat masih bicara (partial kosong terus),
 * baru muncul sekali di akhir kalimat — trade-off yang wajar untuk STT berbasis cloud batch.
 *
 * BELUM PERNAH DITES ke API sungguhan (sandbox pembuatan kode ini tidak ada akses internet).
 * Skema request/response mengikuti dokumentasi resmi Groq per Agustus 2026.
 */
class GroqWhisperSttEngine(
    private val micSource: AudioSource,
    private val apiKeyProvider: () -> String?,
    private val vad: VoiceActivityDetector = EnergyVadEngine()
) : SpeechRecognizerEngine {

    companion object {
        private const val ENDPOINT = "https://api.groq.com/openai/v1/audio/transcriptions"
        private const val MODEL = "whisper-large-v3-turbo"
        // Dinaikkan dari 400 -> 600: potongan audio pendek (400-600ms) yang sebagian besar
        // cuma noise latar/napas ternyata masih cukup sering bikin Whisper "berhalusinasi"
        // (lihat MIN_RMS_TO_UPLOAD di bawah untuk penjelasan lengkap fenomena ini).
        private const val MIN_UTTERANCE_MS = 600L
        private const val SILENCE_TO_FLUSH_MS = 900L

        // FIX BUG "Thank you." muncul sendiri padahal tidak ada yang bicara: ini fenomena
        // BERDOKUMENTASI LUAS di komunitas Whisper — model dilatih dari jutaan video
        // (termasuk captioned videos) yang banyak diakhiri frasa umum ("Thank you.", "Thanks
        // for watching!", "Bye.", dst), jadi kalau dikasih audio nyaris hening/cuma noise
        // lemah, Whisper kadang "mengarang" salah satu frasa umum itu alih-alih bilang
        // "tidak ada ucapan". VAD kita sendiri (EnergyVadEngine) kadang masih meloloskan
        // noise lemah/napas sebagai SPEECH di boundary sebelum benar-benar SILENCE — jadi
        // BUKAN cuma soal VAD, perlu jaring pengaman kedua di sini: threshold RMS lebih
        // ketat KHUSUS sebelum upload (independen dari threshold VAD live per-chunk), dan
        // daftar frasa halusinasi umum yang dibuang kalau muncul dari audio nyaris hening.
        private const val MIN_RMS_TO_UPLOAD = 300.0
        private val KNOWN_HALLUCINATION_PHRASES = setOf(
            "thank you.", "thank you", "thanks for watching!", "thanks for watching",
            "bye.", "bye", "you", ".", "subtitles by the amara.org community",
            "terima kasih.", "terima kasih telah menonton"
        )
    }

    override val isAvailable: Boolean get() = !apiKeyProvider().isNullOrBlank()

    override fun startListening(languageTag: String?): Flow<TranscriptResult> = callbackFlow {
        if (!isAvailable) {
            close(IllegalStateException("Speech recognition unavailable: Groq API key belum diisi di Pengaturan."))
            return@callbackFlow
        }

        vad.reset()
        val buffer = mutableListOf<Short>()
        var speechStartedAtMs = 0L
        var lastSpeechAtMs = 0L
        var inSpeech = false

        suspend fun flushIfNeeded(force: Boolean = false) {
            if (buffer.isEmpty()) return
            val durationMs = buffer.size * 1000L / MicAudioSourceSampleRate
            if (!force && durationMs < MIN_UTTERANCE_MS) {
                buffer.clear()
                return
            }
            val pcm = buffer.toShortArray()
            val overallRms = rmsOf(pcm)
            buffer.clear()

            // Jaring pengaman pertama: buang SEBELUM upload kalau audio-nya nyaris hening
            // secara keseluruhan (bukan cuma per-chunk seperti VAD live) — hemat kuota Groq
            // sekalian, tidak perlu round-trip ke server buat audio yang jelas bukan ucapan.
            if (overallRms < MIN_RMS_TO_UPLOAD) return

            val result = runCatching {
                transcribe(pcm, MicAudioSourceSampleRate, languageTag, apiKeyProvider())
            }
            result.onFailure { e ->
                // FIX BUG: sebelumnya error di sini (network gagal, API key salah, response
                // aneh, dll) DITELAN DIAM-DIAM — trySend TranscriptResult kosong yang tidak
                // pernah ditampilkan di mana pun, jadi user tidak lihat apa pun sama sekali
                // meski API key salah/expired atau tidak ada internet. Sekarang close(e)
                // supaya errornya keluar lewat jalur yang sama seperti AndroidSpeechRecognizerEngine
                // (TranslationPipeline.startMic() loop menangkap & menampilkan e.message di
                // overlay), lalu loop otomatis retry sesi baru (delay 300ms, lihat startMic()).
                close(e)
                return
            }
            val text = result.getOrNull()
            // Jaring pengaman kedua: kalaupun lolos filter RMS di atas tapi audionya masih
            // relatif lemah (di bawah 2x MIN_RMS_TO_UPLOAD) DAN hasilnya persis salah satu
            // frasa halusinasi umum, buang juga — kombinasi "audio lemah" + "frasa generik
            // umum" adalah sinyal kuat halusinasi, bukan ucapan sungguhan.
            val looksLikeHallucination = text != null &&
                text.trim().lowercase() in KNOWN_HALLUCINATION_PHRASES &&
                overallRms < MIN_RMS_TO_UPLOAD * 2
            if (!text.isNullOrBlank() && !looksLikeHallucination) {
                trySend(TranscriptResult(text, isFinal = true, languageHint = languageTag))
            }
        }

        try {
            micSource.start().collect { chunk ->
                val now = System.currentTimeMillis()
                when (vad.evaluate(chunk)) {
                    VoiceState.SPEECH -> {
                        if (!inSpeech) { inSpeech = true; speechStartedAtMs = now }
                        lastSpeechAtMs = now
                        buffer.addAll(chunk.samples.toList())
                    }
                    VoiceState.SILENCE -> {
                        if (inSpeech && (now - lastSpeechAtMs) >= SILENCE_TO_FLUSH_MS) {
                            inSpeech = false
                            flushIfNeeded()
                        }
                    }
                }
            }
        } catch (e: Exception) {
            close(e)
            return@callbackFlow
        }

        awaitClose { micSource.stop() }
    }.flowOn(Dispatchers.IO)

    override fun stopListening() {
        micSource.stop()
    }

    private suspend fun transcribe(
        pcm: ShortArray,
        sampleRateHz: Int,
        languageTag: String?,
        apiKey: String?
    ): String? = withContext(Dispatchers.IO) {
        val wavBytes = WavEncoder.encode(pcm, sampleRateHz)
        val boundary = "----ADJDEV${UUID.randomUUID()}"
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }

        conn.outputStream.use { out ->
            writeFormField(out, boundary, "model", MODEL)
            // "language" param Whisper pakai kode ISO-639-1 pendek (mis. "id", "en") — cocok
            // dengan skema tag yang sudah dipakai di seluruh app ini (LanguageCatalog).
            if (!languageTag.isNullOrBlank() && languageTag != "auto") {
                writeFormField(out, boundary, "language", languageTag)
            }
            writeFormField(out, boundary, "response_format", "json")
            writeFileField(out, boundary, "file", "audio.wav", "audio/wav", wavBytes)
            out.write("--$boundary--\r\n".toByteArray())
        }

        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""

        if (code !in 200..299) {
            val hint = when (code) {
                401 -> "Speech recognition unavailable: Groq API key salah/kadaluarsa — cek lagi di Pengaturan."
                429 -> "Speech recognition unavailable: kuota gratis Groq harian habis, coba lagi nanti."
                in 500..599 -> "Speech recognition unavailable: server Groq lagi bermasalah, coba lagi sesaat."
                else -> "Speech recognition unavailable: Groq STT gagal ($code)."
            }
            throw IllegalStateException("$hint\n$body")
        }
        JSONObject(body).optString("text").trim().ifBlank { null }
    }

    private fun writeFormField(out: OutputStream, boundary: String, name: String, value: String) {
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
        out.write("$value\r\n".toByteArray())
    }

    private fun writeFileField(
        out: OutputStream, boundary: String, name: String, filename: String,
        contentType: String, data: ByteArray
    ) {
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"$name\"; filename=\"$filename\"\r\n".toByteArray())
        out.write("Content-Type: $contentType\r\n\r\n".toByteArray())
        out.write(data)
        out.write("\r\n".toByteArray())
    }

    /** RMS keseluruhan buffer — dipakai sebagai jaring pengaman anti-halusinasi sebelum upload. */
    private fun rmsOf(samples: ShortArray): Double {
        if (samples.isEmpty()) return 0.0
        var sum = 0.0
        for (s in samples) sum += s.toDouble() * s.toDouble()
        return kotlin.math.sqrt(sum / samples.size)
    }
}

// Dipisah biar tidak hard-code angka 16000 berulang kali di file ini — samakan dengan
// MicAudioSource.SAMPLE_RATE_HZ tanpa membuat dependency melingkar lewat companion object.
private const val MicAudioSourceSampleRate = 16_000
