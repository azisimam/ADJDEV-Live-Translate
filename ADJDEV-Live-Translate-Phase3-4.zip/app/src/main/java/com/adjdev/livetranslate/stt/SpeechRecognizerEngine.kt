package com.adjdev.livetranslate.stt

import kotlinx.coroutines.flow.Flow

/** Hasil transkripsi, bisa partial (masih berjalan) atau final (kalimat selesai). */
data class TranscriptResult(
    val text: String,
    val isFinal: Boolean,
    val languageHint: String? = null
)

/**
 * Kontrak STT streaming. Implementasi WAJIB mendukung hasil partial (incremental)
 * agar overlay bisa diperbarui saat pengguna masih berbicara (lihat spesifikasi #10).
 */
interface SpeechRecognizerEngine {

    val isAvailable: Boolean

    /** Mulai sesi pengenalan suara baru. Emit TranscriptResult partial lalu final. */
    fun startListening(languageTag: String? = null): Flow<TranscriptResult>

    /** Hentikan sesi & lepaskan resource. */
    fun stopListening()
}
