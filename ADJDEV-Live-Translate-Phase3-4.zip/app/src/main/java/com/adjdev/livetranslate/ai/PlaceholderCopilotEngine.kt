package com.adjdev.livetranslate.ai

import kotlinx.coroutines.delay
import kotlin.random.Random

/**
 * Mesin COPILOT rule-based — dipakai sebagai fallback [FallbackCopilotEngine] saat device
 * tidak didukung Gemini Nano/AICore (mayoritas perangkat kelas menengah ke bawah, mis.
 * target spesifikasi Redmi Note 13 4G — AICore hanya tersedia di sebagian flagship seperti
 * Pixel 8+/Galaxy S24+). Karena di perangkat seperti itu ini BUKAN fallback langka melainkan
 * jalur yang HAMPIR SELALU aktif untuk mode COPILOT, engine ini ditulis untuk terasa senatural
 * mungkin lewat heuristik teks (bukan model generatif) — bukan lagi 3 baris statis yang sama
 * setiap saat:
 *
 *  1. Deteksi kasar jenis kalimat lawan bicara (sapaan, terima kasih, pamit, pertanyaan
 *     ya/tidak, pertanyaan open-ended/5W1H, atau pernyataan biasa) — mendukung ID & EN
 *     sekaligus karena field `incomingTranslatedText` bisa berisi salah satu tergantung
 *     arah terjemahan.
 *  2. Menarik "topik" (kata kunci) dari kalimat + 1-2 giliran terakhir di recentContext,
 *     supaya salah satu saran bisa menyinggung isi obrolan, bukan generik.
 *  3. Memilih dari pool variasi (bukan 1 kalimat tetap per kategori) via Random, supaya
 *     saran tidak terasa mengulang kata yang sama tiap kali muncul.
 *  4. Selalu menyertakan SATU saran "tanya balik" (pertanyaan lanjutan yang relevan) di
 *     samping saran singkat & saran natural, sesuai permintaan: bukan cuma jawaban searah.
 *
 * Ini tetap BUKAN AI generatif sungguhan — kalau perangkat pengguna nanti mendukung AICore,
 * GeminiNanoCopilotEngine yang akan dipakai lewat FallbackCopilotEngine, kelas ini tidak
 * tersentuh. TODO jangka panjang (belum dikerjakan): model kecil quantized on-device
 * (MediaPipe LLM Inference + Gemma, atau llama.cpp/GGUF) untuk perangkat yang tidak
 * didukung AICore.
 */
class PlaceholderCopilotEngine : AIEngine {

    override var status: AIEngineStatus = AIEngineStatus.IDLE
        private set

    override suspend fun load() {
        if (status == AIEngineStatus.READY) return
        status = AIEngineStatus.LOADING
        delay(120) // simulasi biaya "load" agar transisi idle->loading terlihat di UI
        status = AIEngineStatus.READY
    }

    override fun unload() {
        status = AIEngineStatus.IDLE
    }

    override suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>,
        targetLanguageTag: String
    ): List<SuggestedReply> {
        if (status != AIEngineStatus.READY) return emptyList()
        // JUJUR: template rule-based di bawah ini HANYA ditulis dalam Bahasa Indonesia.
        // Sebelumnya bug — tetap dipaksakan tampil dalam Indonesia meski target bahasa lain
        // (mis. Chinese), jadi kelihatan "tidak sesuai". Sekarang: kalau target bukan
        // Indonesia, engine ini jujur bilang tidak bisa bantu (list kosong) daripada kasih
        // saran dalam bahasa yang salah — FallbackCopilotEngine tidak treat ini sebagai
        // UNAVAILABLE permanen, jadi tetap dicoba lagi di giliran berikutnya kalau-kalau
        // target berubah balik ke Indonesia.
        if (targetLanguageTag != "id") return emptyList()
        status = AIEngineStatus.GENERATING
        delay(150) // simulasi latency generate, cukup kecil supaya tidak terasa lag di overlay

        val suggestions = try {
            buildSuggestions(incomingTranslatedText, recentContext)
        } catch (e: Exception) {
            emptyList()
        }

        status = AIEngineStatus.READY
        return suggestions
    }

    // ---------------------------------------------------------------------------------------
    // Heuristik
    // ---------------------------------------------------------------------------------------

    private enum class Intent { GREETING, THANKS, FAREWELL, YES_NO_QUESTION, OPEN_QUESTION, STATEMENT }

    private fun buildSuggestions(text: String, recentContext: List<String>): List<SuggestedReply> {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return emptyList()

        val lower = trimmed.lowercase()
        val intent = detectIntent(lower)
        val topic = extractTopic(trimmed, recentContext)

        val direct = pick(directPool(intent))
        val natural = pick(naturalPool(intent, topic))
        val followUp = pick(followUpPool(intent, topic))

        // Jaga agar 3 saran tidak identik persis (bisa terjadi kalau topic null & pool kecil).
        val result = linkedSetOf(
            SuggestedReply(direct, ReplyTone.SHORT),
            SuggestedReply(natural, ReplyTone.CASUAL),
            SuggestedReply(followUp, ReplyTone.NATURAL)
        ).toMutableList()

        if (result.size < 3) {
            val fillerPool = naturalPool(Intent.STATEMENT, topic) + followUpPool(Intent.STATEMENT, topic)
            for (filler in fillerPool.shuffled()) {
                if (result.size >= 3) break
                val candidate = SuggestedReply(filler, ReplyTone.NATURAL)
                if (result.none { it.text.equals(candidate.text, ignoreCase = true) }) result.add(candidate)
            }
        }

        return result.take(3)
    }

    private fun pick(pool: List<String>): String = pool[Random.nextInt(pool.size)]

    private fun detectIntent(lower: String): Intent {
        val greetingWords = listOf("hai", "halo", "hello", "hi ", "hey", "selamat pagi", "selamat siang", "selamat sore", "selamat malam")
        val thanksWords = listOf("terima kasih", "makasih", "thanks", "thank you")
        val farewellWords = listOf("sampai jumpa", "dadah", "bye", "goodbye", "see you", "sampai nanti")
        val isQuestion = lower.trimEnd().endsWith("?")
        val yesNoStarters = listOf(
            "apakah", "apa kamu", "apa kau", "apa anda", "bisakah", "bisa kah", "bolehkah", "boleh kah", "maukah",
            "do you", "does ", "did you", "is it", "is this", "is that", "are you", "are they", "can you",
            "could you", "will you", "would you", "have you", "has ", "did "
        )
        val whWords = listOf(
            "dimana", "di mana", "kemana", "ke mana", "kapan", "mengapa", "kenapa", "siapa", "apa ", "bagaimana",
            "berapa", "where", "when", "why", "who", "what", "how", "which"
        )

        return when {
            greetingWords.any { lower.contains(it) } -> Intent.GREETING
            thanksWords.any { lower.contains(it) } -> Intent.THANKS
            farewellWords.any { lower.contains(it) } -> Intent.FAREWELL
            isQuestion && whWords.any { lower.startsWith(it) || lower.contains(" $it") } -> Intent.OPEN_QUESTION
            isQuestion && yesNoStarters.any { lower.startsWith(it) } -> Intent.YES_NO_QUESTION
            isQuestion -> Intent.YES_NO_QUESTION
            else -> Intent.STATEMENT
        }
    }

    /** Kata umum yang diabaikan saat menarik "topik" dari kalimat (ID + EN, minimal). */
    private val stopwords = setOf(
        "yang", "dan", "atau", "itu", "ini", "di", "ke", "dari", "untuk", "dengan", "pada", "saya", "kamu",
        "kau", "anda", "kita", "kami", "mereka", "dia", "adalah", "akan", "sudah", "belum", "tidak", "juga",
        "saja", "ya", "apa", "apakah", "bagaimana", "kenapa", "mengapa", "dimana", "kapan", "siapa", "berapa",
        "the", "a", "an", "is", "are", "was", "were", "to", "of", "in", "on", "for", "with", "and", "or",
        "you", "i", "we", "they", "he", "she", "it", "do", "does", "did", "will", "would", "can", "could",
        "what", "where", "when", "why", "who", "how", "that", "this", "your", "my"
    )

    private fun extractTopic(text: String, recentContext: List<String>): String? {
        val candidates = (listOf(text) + recentContext.takeLast(2))
            .flatMap { it.split(Regex("[^\\p{L}\\p{N}']+")) }
            .map { it.trim().trim('\'') }
            .filter { it.length > 3 && it.lowercase() !in stopwords }

        // Prioritaskan kata dari kalimat barusan (bukan context lama), lalu kata terpanjang
        // sebagai proxy sederhana untuk "kata benda/kata kunci" tanpa perlu NLP tagger.
        val fromCurrent = text.split(Regex("[^\\p{L}\\p{N}']+"))
            .map { it.trim().trim('\'') }
            .filter { it.length > 3 && it.lowercase() !in stopwords }

        val topicWord = fromCurrent.maxByOrNull { it.length } ?: candidates.maxByOrNull { it.length }
        return topicWord?.lowercase()
    }

    private fun directPool(intent: Intent): List<String> = when (intent) {
        Intent.GREETING -> listOf("Hai juga!", "Halo, apa kabar?", "Hei, senang dengar kabarmu.")
        Intent.THANKS -> listOf("Sama-sama.", "Santai aja.", "Tidak masalah.")
        Intent.FAREWELL -> listOf("Sampai jumpa!", "Oke, hati-hati ya.", "Dadah, sampai nanti.")
        Intent.YES_NO_QUESTION -> listOf("Ya, betul.", "Hmm, belum yakin.", "Kurang lebih begitu.")
        Intent.OPEN_QUESTION -> listOf("Sebentar, saya pikirkan dulu.", "Boleh, saya coba jawab.", "Baik, saya jelaskan singkat.")
        Intent.STATEMENT -> listOf("Oke, dimengerti.", "Baik, saya catat.", "Noted, terima kasih infonya.")
    }

    private fun naturalPool(intent: Intent, topic: String?): List<String> {
        val topicPhrase = topic?.let { " soal $it" } ?: ""
        return when (intent) {
            Intent.GREETING -> listOf("Kabar baik nih, kamu gimana?", "Baik-baik aja, makasih udah nanya.")
            Intent.THANKS -> listOf("Kapan aja, senang bisa bantu.", "Iya, sama-sama ya.")
            Intent.FAREWELL -> listOf("Iya, jaga diri ya.", "Oke, ditunggu kabar selanjutnya.")
            Intent.YES_NO_QUESTION -> listOf(
                "Kayaknya iya$topicPhrase, tapi coba dicek lagi.",
                "Belum tahu pasti$topicPhrase, mau saya cek dulu?"
            )
            Intent.OPEN_QUESTION -> listOf(
                "Kalau soal itu, saya rasa tergantung situasinya.",
                "Menurut saya begini$topicPhrase — tapi bisa dikoreksi kalau salah."
            )
            Intent.STATEMENT -> listOf(
                "Menarik juga$topicPhrase, boleh cerita lebih lanjut?",
                "Oke, aku ngerti maksudnya$topicPhrase."
            )
        }
    }

    private fun followUpPool(intent: Intent, topic: String?): List<String> {
        val topicPhrase = topic?.let { " tentang $it" } ?: ""
        return when (intent) {
            Intent.GREETING -> listOf("Ada rencana apa hari ini?", "Lagi sibuk apa sekarang?")
            Intent.THANKS -> listOf("Ada lagi yang bisa dibantu?", "Masih ada yang perlu dibahas?")
            Intent.FAREWELL -> listOf("Kita lanjut ngobrol kapan lagi?", "Nanti dihubungi lagi ya?")
            Intent.YES_NO_QUESTION -> listOf("Kenapa kamu tanya begitu$topicPhrase?", "Ada alasan khusus di baliknya?")
            Intent.OPEN_QUESTION -> listOf("Ada contoh konkretnya$topicPhrase?", "Maksudnya lebih ke arah mana ya?")
            Intent.STATEMENT -> listOf("Boleh diceritakan lebih detail$topicPhrase?", "Terus, gimana kelanjutannya?")
        }
    }
}
