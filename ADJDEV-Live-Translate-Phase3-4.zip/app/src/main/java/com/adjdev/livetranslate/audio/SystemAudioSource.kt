package com.adjdev.livetranslate.audio

import android.content.Context
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn

/**
 * Capture audio yang sedang diputar oleh aplikasi lain, menggunakan
 * AudioPlaybackCapture API (API 29+). Ini BUKAN capture panggilan suara
 * (WhatsApp/Telegram call audio biasanya menggunakan usage VOICE_COMMUNICATION
 * yang secara sengaja dikecualikan Android dari playback capture demi privasi).
 *
 * Cocok untuk: video/audio yang diputar aplikasi lain (browser, media player, game).
 * Tidak cocok untuk: audio panggilan VoIP pihak lain — untuk kasus itu, gunakan mode Mic
 * sambil speaker lawan bicara di-loudspeaker-kan, atau gunakan Mic + System audio bersamaan.
 *
 * MediaProjection instance harus didapat dari izin yang diminta MainActivity/OverlayService
 * lewat MediaProjectionManager, lalu diteruskan ke sini. Kelas ini TIDAK meminta izin sendiri.
 */
class SystemAudioSource(
    private val context: Context,
    private val mediaProjection: MediaProjection
) : AudioSource {

    companion object {
        const val SAMPLE_RATE_HZ = 16_000
        val isSupported: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
    }

    @Volatile
    override var isCapturing: Boolean = false
        private set

    private var audioRecord: AudioRecord? = null

    override fun start(): Flow<AudioChunk> = callbackFlow {
        if (!isSupported) {
            close(UnsupportedOperationException("System audio capture unavailable for this application. Try Microphone mode."))
            return@callbackFlow
        }

        val captureConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
            .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME)
            .addMatchingUsage(android.media.AudioAttributes.USAGE_UNKNOWN)
            .build()

        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE_HZ)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE_HZ, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(1024)

        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(format)
                .setBufferSizeInBytes(minBufferSize * 2)
                .setAudioPlaybackCaptureConfig(captureConfig)
                .build()
        } catch (e: Exception) {
            close(IllegalStateException("System audio capture is unavailable for this application. Try Microphone mode.", e))
            return@callbackFlow
        }

        if (record.state != AudioRecord.STATE_INITIALIZED) {
            record.release()
            close(IllegalStateException("System audio capture is unavailable for this application. Try Microphone mode."))
            return@callbackFlow
        }

        audioRecord = record
        record.startRecording()
        isCapturing = true

        val readBuffer = ShortArray(minBufferSize)
        var running = true
        while (running) {
            val read = record.read(readBuffer, 0, readBuffer.size)
            if (read > 0) {
                val chunk = readBuffer.copyOf(read)
                val sent = trySend(AudioChunk(chunk, SAMPLE_RATE_HZ, AudioSourceType.SYSTEM_AUDIO))
                if (sent.isFailure) running = false
            } else {
                running = false
            }
        }

        awaitClose { internalStop() }
    }.flowOn(Dispatchers.IO)

    override fun stop() = internalStop()

    private fun internalStop() {
        isCapturing = false
        audioRecord?.let {
            try {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) it.stop()
            } catch (_: Exception) {
            } finally {
                it.release()
            }
        }
        audioRecord = null
    }
}
