# ADJDEV Live Translate - proguard rules
# ML Kit menggunakan reflection untuk beberapa komponen; tambahkan keep rules di sini
# jika ditemukan crash setelah minify pada build release.

# Vosk (JNI ke libvosk.so) & JNA — keep supaya nama kelas/metode yang dipanggil lewat native
# code tidak di-obfuscate/dihapus R8 (belum pernah dites di release build minified,
# lihat catatan kejujuran di VoskPcmSttEngine.kt — ini rule standar yang direkomendasikan
# komunitas Vosk-Android, tapi tetap perlu diverifikasi manual di device kalau ada crash).
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-keepclassmembers class * extends com.sun.jna.Structure { public *; }
