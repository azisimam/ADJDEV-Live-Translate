plugins {
    id("com.android.application") version "8.5.2" apply false
    // Dinaikkan dari 1.9.24 -> 2.2.0: genai-prompt:1.0.0-beta2 dan genai-common:1.0.0-beta3
    // (dependency Phase 3, lihat app/build.gradle.kts) di-compile dengan metadata Kotlin 2.2.0.
    // Compiler Kotlin 1.9.x hanya bisa membaca metadata sampai 2.0.0 -> build gagal di
    // compileDebugKotlin dengan pesan "was compiled with an incompatible version of Kotlin".
    id("org.jetbrains.kotlin.android") version "2.2.0" apply false
    // WAJIB sejak Kotlin 2.0+: compiler Compose tidak lagi dibundel via
    // composeOptions.kotlinCompilerExtensionVersion di app/build.gradle.kts (mekanisme lama,
    // K1-only) — sekarang lewat plugin Gradle terpisah ini, versinya harus SAMA dengan Kotlin
    // di atas.
    id("org.jetbrains.kotlin.plugin.compose") version "2.2.0" apply false
}
