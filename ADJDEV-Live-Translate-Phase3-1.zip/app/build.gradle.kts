plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.adjdev.livetranslate"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.adjdev.livetranslate"
        minSdk = 26 // butuh 26+ untuk overlay & foreground service yang stabil
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-phase1"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
    // composeOptions { kotlinCompilerExtensionVersion = ... } DIHAPUS: mekanisme itu K1-only.
    // Sejak Kotlin 2.0+, versi compiler Compose ditentukan otomatis oleh plugin
    // "org.jetbrains.kotlin.plugin.compose" (lihat root build.gradle.kts) mengikuti versi
    // Kotlin project ini — tidak perlu diset manual lagi di sini.

    packaging {
        resources.excludes.add("/META-INF/{AL2.0,LGPL2.1}")
    }
}

dependencies {
    // Core & lifecycle
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.savedstate:savedstate-ktx:1.2.1")

    // Compose (BOM)
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.compose.material:material-icons-extended:1.6.8")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // DataStore untuk settings lokal (bukan cloud db)
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // ML Kit on-device: translation & language identification (offline setelah model diunduh sekali)
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")

    // ML Kit GenAI Prompt API — Gemini Nano on-device via AICore (Phase 3: mode SMART yang
    // benar-benar context-aware + COPILOT dengan suggested replies sungguhan, bukan lagi
    // rule-based). Beta, hanya berjalan di perangkat yang didukung AICore — lihat catatan
    // kejujuran di ContextAwareTranslationEngine.kt / GeminiNanoCopilotEngine.kt. Aman
    // ditambahkan di semua perangkat: di perangkat tak didukung, checkStatus() otomatis
    // UNAVAILABLE dan pipeline jatuh ke perilaku Phase 2 (ML Kit Translate biasa + placeholder).
    implementation("com.google.mlkit:genai-prompt:1.0.0-beta2")
}
