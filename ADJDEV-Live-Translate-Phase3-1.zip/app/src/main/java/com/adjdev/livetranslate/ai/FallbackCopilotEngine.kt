package com.adjdev.livetranslate.ai

/**
 * Composite untuk mode COPILOT: coba [primary] (Gemini Nano sungguhan) dulu; kalau device
 * tidak didukung AICore atau gagal apa pun saat load(), otomatis & permanen (untuk sesi
 * translator berjalan ini) pindah ke [fallback] (PlaceholderCopilotEngine rule-based) supaya
 * fitur Suggested Replies tetap ada, bukan mati total, di perangkat kelas menengah yang belum
 * didukung Gemini Nano. Pipeline/UI (`TranslationPipeline`, `OverlayScreen`) tidak perlu tahu
 * mana yang sedang aktif — cukup pakai kontrak `AIEngine` seperti biasa.
 */
class FallbackCopilotEngine(
    private val primary: AIEngine = GeminiNanoCopilotEngine(),
    private val fallback: AIEngine = PlaceholderCopilotEngine()
) : AIEngine {

    private var usingFallback = false

    override val status: AIEngineStatus
        get() = if (usingFallback) fallback.status else primary.status

    override suspend fun load() {
        if (usingFallback) {
            fallback.load()
            return
        }
        primary.load()
        if (primary.status == AIEngineStatus.UNAVAILABLE) {
            usingFallback = true
            fallback.load()
        }
    }

    override fun unload() {
        primary.unload()
        fallback.unload()
    }

    override suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>
    ): List<SuggestedReply> = if (usingFallback) {
        fallback.generateSuggestions(incomingTranslatedText, recentContext)
    } else {
        primary.generateSuggestions(incomingTranslatedText, recentContext)
    }
}
