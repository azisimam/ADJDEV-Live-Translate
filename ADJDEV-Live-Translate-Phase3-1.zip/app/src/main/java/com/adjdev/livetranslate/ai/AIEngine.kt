package com.adjdev.livetranslate.ai

/** Status siklus hidup model AI Copilot, sesuai spesifikasi §6 (idle -> load -> generate). */
enum class AIEngineStatus { IDLE, LOADING, READY, GENERATING, UNAVAILABLE }

data class SuggestedReply(val text: String, val tone: ReplyTone)

enum class ReplyTone { SHORT, CASUAL, FORMAL, NATURAL }

/**
 * Kontrak mesin AI untuk mode COPILOT (suggested replies). Diabstraksi agar implementasi
 * bisa ditukar dari placeholder rule-based (Phase 3 awal) ke model lokal quantized sungguhan
 * (mis. via MediaPipe LLM Inference API / llama.cpp JNI) tanpa mengubah pipeline.
 *
 * Siklus hidup WAJIB ikut pola idle/unload saat tidak dipakai (spesifikasi §6, §18):
 * model (atau resource-nya) hanya "dimuat" saat Copilot benar-benar diaktifkan, dan
 * dilepas saat idle untuk menghemat RAM/baterai.
 */
interface AIEngine {
    val status: AIEngineStatus

    /** Muat model/resource. No-op jika sudah READY. */
    suspend fun load()

    /** Lepas model/resource dari RAM. Dipanggil saat Copilot dinonaktifkan atau translator OFF. */
    fun unload()

    /**
     * Hasilkan beberapa saran balasan dari transcript terakhir + context percakapan.
     * INI ADALAH AI PATH (spesifikasi §11): boleh butuh waktu, TIDAK PERNAH memblokir
     * hasil translation yang sudah tampil lebih dulu di overlay.
     */
    suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>
    ): List<SuggestedReply>
}
