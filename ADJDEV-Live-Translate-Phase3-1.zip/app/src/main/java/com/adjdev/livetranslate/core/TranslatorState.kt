package com.adjdev.livetranslate.core

import com.adjdev.livetranslate.ai.SuggestedReply

/** Status pipeline realtime, dikonsumsi oleh overlay & UI utama. */
data class TranslatorState(
    val isRunning: Boolean = false,
    val micOn: Boolean = false,
    val systemAudioOn: Boolean = false,
    val partialSourceText: String = "",
    val lastSourceText: String = "",
    val lastTranslatedText: String = "",
    val detectedLanguage: String? = null,
    val errorMessage: String? = null,
    // AI Path (Copilot, §11): diisi belakangan setelah translation tampil, tidak pernah
    // ditunggu oleh fast path. Kosong kalau mode bukan COPILOT atau AI belum selesai.
    val suggestedReplies: List<SuggestedReply> = emptyList()
)
