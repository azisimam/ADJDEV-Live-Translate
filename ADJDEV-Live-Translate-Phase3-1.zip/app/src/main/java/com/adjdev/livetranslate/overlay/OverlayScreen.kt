package com.adjdev.livetranslate.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adjdev.livetranslate.core.TranslatorState

/**
 * Panel overlay utama: menampilkan teks sumber (termasuk partial/incremental) dan
 * hasil terjemahan, plus kontrol cepat. Suggested replies (Copilot) sengaja TIDAK
 * ada di Phase 1 — akan ditambahkan sebagai section terpisah di Phase 3.
 */
@Composable
fun OverlayScreen(
    state: TranslatorState,
    opacity: Float,
    fontSizeSp: Int,
    onToggleMic: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    onClearConversation: () -> Unit = {}
) {
    Column(
        modifier = Modifier
            .widthIn(min = 240.dp, max = 320.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xE6161622))
            .padding(12.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Text(
                text = "\uD83C\uDF10 " + (state.detectedLanguage?.uppercase() ?: "AUTO") + " \u2192 ID",
                color = Color.White,
                style = MaterialTheme.typography.labelLarge
            )
            Row {
                IconButton(onClick = onMinimize) {
                    Icon(Icons.Filled.RemoveCircle, contentDescription = "Minimize", tint = Color.White)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White)
                }
            }
        }

        val sourceDisplay = state.partialSourceText.ifBlank { state.lastSourceText }
        if (sourceDisplay.isNotBlank()) {
            Text(
                text = sourceDisplay,
                color = Color(0xFFAAAAAA),
                fontSize = fontSizeSp.sp,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        if (state.lastTranslatedText.isNotBlank()) {
            Text(
                text = state.lastTranslatedText,
                color = Color.White,
                fontSize = (fontSizeSp + 2).sp
            )
        }

        state.errorMessage?.let {
            Text(
                text = it,
                color = Color(0xFFFF6B6B),
                fontSize = (fontSizeSp - 2).sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        if (state.suggestedReplies.isNotEmpty()) {
            Text(
                text = "\uD83E\uDD16 Suggested Replies",
                color = Color(0xFF999999),
                fontSize = (fontSizeSp - 1).sp,
                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                state.suggestedReplies.forEachIndexed { index, reply ->
                    Text(
                        text = "${index + 1}. ${reply.text}",
                        color = Color(0xFFDDE8FF),
                        fontSize = fontSizeSp.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(top = 10.dp)
        ) {
            IconButton(onClick = onToggleMic) {
                Icon(
                    imageVector = if (state.micOn) Icons.Filled.Mic else Icons.Filled.MicOff,
                    contentDescription = "Toggle mic",
                    tint = if (state.micOn) Color(0xFF7FDBFF) else Color(0xFF666666)
                )
            }
            IconButton(onClick = onClearConversation) {
                Icon(
                    imageVector = Icons.Filled.DeleteSweep,
                    contentDescription = "Clear Conversation",
                    tint = Color(0xFF999999)
                )
            }
        }
    }
}
