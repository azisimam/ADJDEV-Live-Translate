package com.adjdev.livetranslate.core

import com.adjdev.livetranslate.ai.AIEngine
import com.adjdev.livetranslate.ai.AIEngineStatus
import com.adjdev.livetranslate.conversation.ConversationContextStore
import com.adjdev.livetranslate.conversation.ConversationTurn
import com.adjdev.livetranslate.detection.LanguageDetector
import com.adjdev.livetranslate.stt.SpeechRecognizerEngine
import com.adjdev.livetranslate.storage.TranslationCache
import com.adjdev.livetranslate.translation.TranslationEngine
import com.adjdev.livetranslate.translation.TranslationOutcome
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Menghubungkan: STT (loop mandiri) -> Deteksi bahasa -> Cache/Translation -> state.
 *
 * FAST PATH murni (spesifikasi #11): tidak ada langkah AI/Copilot di kelas ini sama sekali.
 * Mode SMART/COPILOT (context, suggestions) dibangun sebagai layer terpisah di atas
 * hasil finalTranscript yang di-emit dari sini (Phase 3), agar jalur realtime translation
 * TIDAK PERNAH menunggu proses AI.
 *
 * CATATAN ARSITEKTUR (Phase 2 -> Phase 3 fix): sebelumnya VAD memakai AudioRecord terpisah
 * (MicAudioSource) berjalan BERSAMAAN dengan android.speech.SpeechRecognizer yang juga
 * membuka mic sendiri. Di banyak perangkat, dua konsumen mic sekaligus membuat
 * SpeechRecognizer gagal mendapat audio (gagal diam-diam lewat onError, tanpa transcript
 * ataupun pesan error yang terlihat). Karena itu untuk STT berbasis SpeechRecognizer bawaan
 * Android, VAD custom TIDAK dipakai lagi sebagai gate mic — sebagai gantinya sesi STT
 * dijalankan berulang (loop) dan SpeechRecognizer sendiri yang menangani deteksi mulai/akhir
 * bicara secara internal. EnergyVadEngine/MicAudioSource tetap disimpan di codebase untuk
 * dipakai nanti oleh STT engine berbasis raw-PCM (Vosk/whisper.cpp) yang BISA berbagi satu
 * AudioRecord tap tanpa konflik.
 */
class TranslationPipeline(
    private val sttEngine: SpeechRecognizerEngine,
    private val languageDetector: LanguageDetector,
    private val translationEngine: TranslationEngine,
    private val cache: TranslationCache,
    val conversationContext: ConversationContextStore = ConversationContextStore(),
    private val aiEngine: AIEngine? = null
) {
    private val scope = CoroutineScope(SupervisorJob())
    private var sttJob: Job? = null

    private val _state = MutableStateFlow(TranslatorState())
    val state: StateFlow<TranslatorState> = _state.asStateFlow()

    private var targetLanguageTag: String = "id"
    private var autoDetect: Boolean = true
    private var fixedSourceLanguageTag: String? = null
    private var copilotEnabled: Boolean = false

    fun configure(targetLanguageTag: String, autoDetect: Boolean, sourceLanguageTag: String?) {
        this.targetLanguageTag = targetLanguageTag
        this.autoDetect = autoDetect
        this.fixedSourceLanguageTag = sourceLanguageTag
    }

    /**
     * Aktif/nonaktifkan mode COPILOT. Mengikuti pola idle/load di spesifikasi §6: model
     * baru dimuat saat benar-benar diaktifkan, dilepas lagi saat dinonaktifkan agar tidak
     * resident di RAM secara sia-sia.
     */
    fun setCopilotEnabled(enabled: Boolean) {
        copilotEnabled = enabled
        if (aiEngine == null) return
        if (enabled) {
            scope.launch { aiEngine.load() }
        } else {
            aiEngine.unload()
            _state.value = _state.value.copy(suggestedReplies = emptyList())
        }
    }

    /**
     * Mulai pipeline mic: menjalankan sesi SpeechRecognizer berulang (auto-restart) selama
     * mic ON. SpeechRecognizer sendiri yang mendeteksi mulai/akhir bicara secara internal —
     * lihat catatan arsitektur di atas kelas ini.
     */
    fun startMic() {
        if (sttJob?.isActive == true) return
        _state.value = _state.value.copy(isRunning = true, micOn = true, errorMessage = null)

        // WAJIB di Dispatchers.Main: android.speech.SpeechRecognizer harus dibuat & dipakai
        // dari thread yang punya Looper (biasanya main thread).
        sttJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                try {
                    sttEngine.startListening(fixedSourceLanguageTag).collect { result ->
                        if (result.isFinal) {
                            handleFinalTranscript(result.text)
                        } else {
                            _state.value = _state.value.copy(partialSourceText = result.text)
                        }
                    }
                } catch (e: Exception) {
                    _state.value = _state.value.copy(errorMessage = e.message ?: "Speech recognition unavailable.")
                }
                // Jeda singkat sebelum sesi baru, agar tidak busy-loop kalau error terus-menerus
                // (mis. izin dicabut, atau recognizer sedang sibuk).
                delay(300)
            }
        }
    }

    private suspend fun handleFinalTranscript(text: String) {
        if (text.isBlank()) return

        val sourceLang = if (autoDetect) {
            languageDetector.detect(text) ?: "en"
        } else {
            fixedSourceLanguageTag ?: "en"
        }

        val cached = cache.get(sourceLang, targetLanguageTag, text)
        if (cached != null) {
            emitTranslated(text, cached, sourceLang)
            return
        }

        when (val outcome = translationEngine.translate(text, sourceLang, targetLanguageTag)) {
            is TranslationOutcome.Success -> {
                cache.put(sourceLang, targetLanguageTag, text, outcome.translatedText)
                emitTranslated(text, outcome.translatedText, sourceLang)
            }
            is TranslationOutcome.Failure -> {
                _state.value = _state.value.copy(errorMessage = outcome.message)
            }
        }
    }

    private fun emitTranslated(source: String, translated: String, detectedLang: String) {
        // Dicatat sebagai groundwork mode SMART (Phase 3); fast path di atas tidak menunggu ini.
        conversationContext.addTurn(ConversationTurn(source, translated, detectedLang))
        _state.value = _state.value.copy(
            partialSourceText = "",
            lastSourceText = source,
            lastTranslatedText = translated,
            detectedLanguage = detectedLang,
            errorMessage = null,
            suggestedReplies = emptyList() // reset dulu, AI Path akan mengisinya belakangan
        )
        triggerAiPathIfEnabled(translated)
    }

    /**
     * AI PATH (spesifikasi §11): dijalankan sebagai coroutine terpisah setelah translation
     * SUDAH tampil di overlay (lihat emitTranslated di atas). Kalau AI belum selesai atau
     * gagal, translation tetap terlihat normal — tidak ada yang menunggu baris ini.
     */
    private fun triggerAiPathIfEnabled(translatedText: String) {
        if (!copilotEnabled || aiEngine == null) return
        scope.launch {
            if (aiEngine.status == AIEngineStatus.IDLE) aiEngine.load()
            val recentContext = conversationContext.recentTurns().map { it.translatedText }
            val suggestions = aiEngine.generateSuggestions(translatedText, recentContext)
            _state.value = _state.value.copy(suggestedReplies = suggestions)
        }
    }

    /** Dipanggil dari tombol "Clear Conversation" di overlay/settings (spesifikasi §4/§15). */
    fun clearConversation() = conversationContext.clear()

    fun setContextLimit(maxTurns: Int) = conversationContext.setMaxTurns(maxTurns)

    fun stopMic() {
        sttJob?.cancel()
        sttEngine.stopListening()
        _state.value = _state.value.copy(micOn = false, partialSourceText = "")
    }

    /** Hentikan seluruh pipeline & lepaskan semua resource (dipanggil saat translator OFF). */
    fun stopAll() {
        stopMic()
        translationEngine.release()
        aiEngine?.unload()
        _state.value = TranslatorState()
        scope.cancel()
    }
}
