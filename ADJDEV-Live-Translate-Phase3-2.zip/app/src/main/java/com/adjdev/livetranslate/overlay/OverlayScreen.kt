package com.adjdev.livetranslate.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.RemoveCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.adjdev.livetranslate.core.SystemAudioSttStatus
import com.adjdev.livetranslate.core.TranslatorState

/**
 * Panel overlay utama: menampilkan teks sumber (termasuk partial/incremental) dan
 * hasil terjemahan, plus kontrol cepat. Suggested replies (Copilot) sengaja TIDAK
 * ada di Phase 1 — akan ditambahkan sebagai section terpisah di Phase 3.
 */
@Composable
fun OverlayScreen(
    state: TranslatorState,
    opacity: Float,
    fontSizeSp: Int,
    // Lebar panel dalam dp, dikontrol via resize handle di pojok kanan-bawah (Phase 2:
    // resize overlay via gesture). Nilainya dimiliki & di-drive oleh OverlayService (bukan
    // di sini) karena drag-nya ditangani di level View.OnTouchListener bersama drag-to-move,
    // supaya kedua gesture (geser vs resize) tidak berebut event dengan Compose.
    widthDp: Int,
    onToggleMic: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    onClearConversation: () -> Unit = {}
) {
    Box {
    Column(
        modifier = Modifier
            .width(widthDp.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xE6161622))
            .padding(12.dp)
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            Text(
                text = "\uD83C\uDF10 " + (state.configuredSourceLanguage?.uppercase()
                    ?: state.detectedLanguage?.uppercase() ?: "AUTO") + " \u2192 ID",
                color = Color.White,
                style = MaterialTheme.typography.labelLarge
            )
            Row {
                IconButton(onClick = onMinimize) {
                    Icon(Icons.Filled.RemoveCircle, contentDescription = "Minimize", tint = Color.White)
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "Close", tint = Color.White)
                }
            }
        }

        // Selama masih partial (user belum berhenti bicara), tampilkan partialTranslatedText
        // yang di-debounce (Phase 2: streaming translation) alih-alih hanya teks sumber mentah;
        // begitu transcript final datang, pindah ke lastSourceText/lastTranslatedText yang pasti.
        val isPartial = state.partialSourceText.isNotBlank()
        val sourceDisplay = state.partialSourceText.ifBlank { state.lastSourceText }
        val translatedDisplay = if (isPartial) state.partialTranslatedText else state.lastTranslatedText

        if (sourceDisplay.isNotBlank()) {
            Text(
                text = sourceDisplay,
                color = Color(0xFFAAAAAA),
                fontSize = fontSizeSp.sp,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        if (translatedDisplay.isNotBlank()) {
            Text(
                text = translatedDisplay,
                // Warna sedikit diredupkan selagi partial, untuk menandakan belum final —
                // tanpa perlu indikator/spinner terpisah yang bisa mengganggu overlay kecil.
                color = if (isPartial) Color(0xFFCFE0FF) else Color.White,
                fontSize = (fontSizeSp + 2).sp
            )
        }

        state.errorMessage?.let {
            Text(
                text = it,
                color = Color(0xFFFF6B6B),
                fontSize = (fontSizeSp - 2).sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        // Status transkripsi System Audio (Phase 3.1: Vosk) — beda pesan per status persis,
        // sengaja jujur: tidak menjanjikan teks yang tidak akan muncul (lihat SystemAudioSttStatus).
        if (state.systemAudioOn) {
            Text(
                text = systemAudioStatusLabel(state.systemAudioSttStatus),
                color = Color(0xFF999999),
                fontSize = (fontSizeSp - 2).sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (state.suggestedReplies.isNotEmpty()) {
            Text(
                text = "\uD83E\uDD16 Suggested Replies",
                color = Color(0xFF999999),
                fontSize = (fontSizeSp - 1).sp,
                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
            )
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                state.suggestedReplies.forEachIndexed { index, reply ->
                    Column(modifier = Modifier.padding(vertical = 2.dp)) {
                        // Teks siap-kirim, dalam bahasa lawan bicara (lihat
                        // TranslationPipeline.triggerAiPathIfEnabled).
                        Text(
                            text = "${index + 1}. ${reply.text}",
                            color = Color(0xFFDDE8FF),
                            fontSize = fontSizeSp.sp
                        )
                        // Terjemahan Indonesia dari saran di atas, biar user tahu artinya
                        // sebelum mengirim. Tidak ditampilkan kalau lawan bicara sama-sama ID.
                        reply.translation?.let { translation ->
                            Text(
                                text = translation,
                                color = Color(0xFF9AA6B8),
                                fontSize = (fontSizeSp - 2).sp,
                                modifier = Modifier.padding(start = 14.dp, top = 1.dp)
                            )
                        }
                        // Pinyin — cuma muncul kalau reply.text mengandung aksara Han (mis.
                        // Mandarin). Lihat PinyinUtils & catatan di TranslationPipeline.
                        reply.pinyin?.let { pinyin ->
                            Text(
                                text = pinyin,
                                color = Color(0xFF7FDBFF),
                                fontSize = (fontSizeSp - 2).sp,
                                modifier = Modifier.padding(start = 14.dp, top = 1.dp)
                            )
                        }
                    }
                }
            }
        } else if (state.copilotErrorMessage != null) {
            // FIX "suggested replies nggak muncul sama sekali tanpa penjelasan": sebelumnya
            // kalau AI Path gagal (mis. server VPS nolak nama model yang salah, HTTP error,
            // timeout), bagian ini SAMA SEKALI tidak dirender — user tidak tahu itu error atau
            // memang belum sempat jalan. Sekarang alasannya ditampilkan apa adanya (lihat
            // RemoteCopilotEngine.lastError), supaya kegagalan konfigurasi (kayak kasus nama
            // model "local-model" vs nama model asli di server) kelihatan dari overlay
            // langsung, tanpa perlu ngecek logcat/adb.
            Text(
                text = "\uD83E\uDD16 Suggested Replies gagal: ${state.copilotErrorMessage}",
                color = Color(0xFFE0A24C),
                fontSize = (fontSizeSp - 2).sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.padding(top = 10.dp)
        ) {
            IconButton(onClick = onToggleMic) {
                Icon(
                    imageVector = if (state.micOn) Icons.Filled.Mic else Icons.Filled.MicOff,
                    contentDescription = "Toggle mic",
                    tint = if (state.micOn) Color(0xFF7FDBFF) else Color(0xFF666666)
                )
            }
            IconButton(onClick = onClearConversation) {
                Icon(
                    imageVector = Icons.Filled.DeleteSweep,
                    contentDescription = "Clear Conversation",
                    tint = Color(0xFF999999)
                )
            }
        }
    }

        // Indikator visual saja — sengaja TANPA pointerInput/drag gesture di sini. Drag
        // resize-nya ditangkap di OverlayService.attachDragAndResizeHandling() (level View),
        // supaya tidak berebut event dengan drag-to-move window yang juga di level View.
        Icon(
            imageVector = Icons.Filled.OpenInFull,
            contentDescription = "Resize",
            tint = Color(0x66FFFFFF),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(4.dp)
                .size(14.dp)
        )
    }
}

/** Pesan status System Audio yang jujur per kondisi — lihat SystemAudioSttStatus. */
private fun systemAudioStatusLabel(status: SystemAudioSttStatus): String = when (status) {
    is SystemAudioSttStatus.Idle ->
        "\uD83D\uDD0A System Audio aktif"
    is SystemAudioSttStatus.DownloadingModel ->
        "\uD83D\uDD0A Mengunduh model bahasa (${status.progressPercent}%)\u2026 sekali saja"
    is SystemAudioSttStatus.PreparingModel ->
        "\uD83D\uDD0A Menyiapkan model bahasa\u2026"
    is SystemAudioSttStatus.Transcribing ->
        "\uD83D\uDD0A System Audio aktif \u2014 mentranskripsi"
    is SystemAudioSttStatus.Unsupported ->
        "\uD83D\uDD0A System Audio aktif, tapi bahasa \"${status.languageTag}\" belum punya model STT (baru English yang didukung)"
    is SystemAudioSttStatus.Error ->
        "\uD83D\uDD0A System Audio aktif, transkripsi gagal: ${status.message}"
}
