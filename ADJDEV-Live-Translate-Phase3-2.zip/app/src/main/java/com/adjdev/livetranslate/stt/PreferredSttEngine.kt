package com.adjdev.livetranslate.stt

import kotlinx.coroutines.flow.Flow

/**
 * Pilih otomatis: Groq (cloud, cepat & akurat, butuh API key + internet) kalau API key sudah
 * diisi di Pengaturan, atau fallback ke SpeechRecognizer bawaan Android (bisa online/offline
 * tergantung device — lihat riwayat panjang soal ini di README). TIDAK ada setting tambahan
 * di luar app yang dibutuhkan untuk pilihan mana pun: Groq cukup API key di dalam app,
 * fallback-nya sudah otomatis bawaan OS.
 *
 * Dicek ULANG setiap startListening() (bukan sekali di awal) — kalau user baru isi API key
 * Groq di tengah sesi translator berjalan, sesi STT BERIKUTNYA (bukan yang sedang jalan)
 * otomatis pindah ke Groq tanpa perlu restart translator.
 */
class PreferredSttEngine(
    private val cloud: GroqWhisperSttEngine,
    private val fallback: AndroidSpeechRecognizerEngine
) : SpeechRecognizerEngine {

    override val isAvailable: Boolean get() = cloud.isAvailable || fallback.isAvailable

    override fun startListening(languageTag: String?): Flow<TranscriptResult> =
        if (cloud.isAvailable) cloud.startListening(languageTag) else fallback.startListening(languageTag)

    override fun stopListening() {
        cloud.stopListening()
        fallback.stopListening()
    }
}
