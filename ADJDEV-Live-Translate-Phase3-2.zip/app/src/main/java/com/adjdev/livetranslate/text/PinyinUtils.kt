package com.adjdev.livetranslate.text

import android.icu.text.Transliterator
import android.os.Build

/**
 * Transliterasi Han (aksara Mandarin) ke pinyin latin, KHUSUS dipakai untuk Suggested
 * Replies (spesifikasi user: "kalau ada huruf asing sertakan latin, misal Mandarin sertakan
 * pinyin, hanya pada suggested replies" — bukan untuk teks translation utama).
 *
 * Pakai android.icu.text.Transliterator bawaan framework Android (tersedia sejak API 24,
 * minSdk project ini 26) — TIDAK perlu dependency pinyin pihak ketiga. ID transliterator
 * "Han-Latin" adalah salah satu yang paling umum & stabil di ICU, hasilnya pinyin dengan
 * angka nada (mis. "ni3 hao3") — cukup untuk konteks "biar user bisa baca", bukan untuk
 * linguistik presisi tinggi.
 */
object PinyinUtils {

    // Range Unicode untuk CJK Unified Ideographs (mencakup mayoritas karakter Mandarin
    // umum). Cukup untuk deteksi "apakah teks ini mengandung aksara Han", bukan untuk
    // membedakan Mandarin dari Jepang/Korea yang juga memakai sebagian aksara Han yang sama
    // — tapi untuk konteks Suggested Replies (bahasa sudah diketahui dari arah terjemahan),
    // ini cukup andal.
    private val HAN_RANGE = '\u4E00'..'\u9FFF'

    private val transliterator: Transliterator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            runCatching { Transliterator.getInstance("Han-Latin") }.getOrNull()
        } else null
    }

    fun containsHanScript(text: String): Boolean = text.any { it in HAN_RANGE }

    /** Null kalau teks tidak mengandung aksara Han, atau ICU transliterator tidak tersedia. */
    fun pinyinOrNull(text: String): String? {
        if (!containsHanScript(text)) return null
        val t = transliterator ?: return null
        return runCatching { t.transliterate(text) }.getOrNull()
    }
}
