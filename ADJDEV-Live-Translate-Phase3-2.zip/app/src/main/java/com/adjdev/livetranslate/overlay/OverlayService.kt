package com.adjdev.livetranslate.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import androidx.compose.ui.platform.ComposeView
import com.adjdev.livetranslate.MainActivity
import com.adjdev.livetranslate.ai.FallbackCopilotEngine
import com.adjdev.livetranslate.ai.RemoteCopilotEngine
import com.adjdev.livetranslate.ai.GeminiNanoCopilotEngine
import com.adjdev.livetranslate.audio.SystemAudioSource
import com.adjdev.livetranslate.core.TranslationPipeline
import com.adjdev.livetranslate.core.TranslatorState
import com.adjdev.livetranslate.detection.MlKitLanguageDetector
import com.adjdev.livetranslate.settings.SettingsRepository
import com.adjdev.livetranslate.settings.TranslationMode
import com.adjdev.livetranslate.stt.AndroidSpeechRecognizerEngine
import com.adjdev.livetranslate.stt.GroqWhisperSttEngine
import com.adjdev.livetranslate.stt.PreferredSttEngine
import com.adjdev.livetranslate.stt.vosk.VoskModelManager
import com.adjdev.livetranslate.stt.vosk.VoskPcmSttEngine
import com.adjdev.livetranslate.storage.TranslationCache
import com.adjdev.livetranslate.translation.ContextAwareTranslationEngine
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Satu Foreground Service yang bertanggung jawab atas:
 *  1. Menjalankan TranslationPipeline (audio -> VAD -> STT -> translation).
 *  2. Menampilkan floating overlay (panel penuh atau bubble minimized) via WindowManager.
 *
 * Service ini TIDAK melakukan apa pun ketika translator OFF: stopSelf() dipanggil
 * dan seluruh resource (audio, overlay view, pipeline) dilepas (spesifikasi #14/#18).
 */
class OverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    companion object {
        const val ACTION_START = "com.adjdev.livetranslate.action.START"
        const val ACTION_STOP = "com.adjdev.livetranslate.action.STOP"

        // Token izin MediaProjection (System Audio), diteruskan MainActivity lewat extras
        // Intent SAAT ACTION_START — bukan disimpan lintas proses. Lihat catatan di
        // MainActivity.projectionLauncher soal kenapa dialognya diminta di Activity, bukan
        // di sini: MediaProjectionManager.createScreenCaptureIntent() WAJIB dari context
        // Activity, Service tidak bisa memicu dialog sistem itu sendiri.
        const val EXTRA_PROJECTION_RESULT_CODE = "com.adjdev.livetranslate.extra.PROJECTION_RESULT_CODE"
        const val EXTRA_PROJECTION_DATA = "com.adjdev.livetranslate.extra.PROJECTION_DATA"

        private const val NOTIFICATION_CHANNEL_ID = "adjdev_live_translate_channel"
        private const val NOTIFICATION_ID = 1001

        // Batas & area sentuh resize handle (Phase 2: resize overlay via gesture).
        private const val DEFAULT_OVERLAY_WIDTH_DP = 280
        private const val MIN_OVERLAY_WIDTH_DP = 220
        private const val MAX_OVERLAY_WIDTH_DP = 400
        private const val RESIZE_HANDLE_DP = 28
    }

    /** Mode pointer aktif untuk satu sesi sentuh: geser window vs resize lebar panel. */
    private enum class TouchMode { NONE, PENDING_MOVE, MOVE, PENDING_RESIZE, RESIZE }

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore = ViewModelStore()
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private lateinit var windowManager: WindowManager
    private var overlayComposeView: ComposeView? = null
    private var overlayLayoutParams: WindowManager.LayoutParams? = null
    private var isMinimized = false
    // Dimiliki service (bukan lokal ke Composable) karena diubah langsung dari
    // View.OnTouchListener saat resize berlangsung — lihat attachDragAndResizeHandling().
    private var overlayWidthDp by mutableStateOf(DEFAULT_OVERLAY_WIDTH_DP)

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var pipeline: TranslationPipeline
    // Dibaca oleh GroqWhisperSttEngine lewat lambda `{ cloudSttApiKey }` (bukan snapshot
    // sekali di awal) — kalau user isi/hapus API key di Settings sambil translator jalan,
    // sesi STT berikutnya langsung kepakai tanpa perlu restart. Sama pola dengan
    // localLlmEnabled yang dulu pernah ada di sini.
    @Volatile
    private var cloudSttApiKey: String? = null

    private var mediaProjection: MediaProjection? = null
    private var systemAudioSource: SystemAudioSource? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * WAJIB (Android 10+): mendaftarkan callback ini SEBELUM memakai MediaProjection untuk
     * apa pun (mis. AudioPlaybackCaptureConfiguration), atau tergantung versi OS bisa
     * SecurityException/IllegalStateException. Kalau proyeksi di-stop dari luar (user
     * mencabut izin lewat notifikasi capture sistem), kita HARUS ikut menghentikan capture
     * di sini juga — bukan cuma percaya toggle System Audio di Settings.
     */
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopSystemAudioCapture()
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        settingsRepository = SettingsRepository(applicationContext)

        // Phase 3.1: model manager & engine Vosk untuk transkripsi System Audio sungguhan.
        // Lihat catatan kejujuran di VoskModelCatalog soal bahasa yang didukung (baru "en").
        val voskModelManager = VoskModelManager(applicationContext)

        pipeline = TranslationPipeline(
            sttEngine = PreferredSttEngine(
                cloud = GroqWhisperSttEngine(
                    micSource = com.adjdev.livetranslate.audio.MicAudioSource(applicationContext),
                    apiKeyProvider = { cloudSttApiKey }
                ),
                fallback = AndroidSpeechRecognizerEngine(applicationContext)
            ),
            languageDetector = MlKitLanguageDetector(),
            // ContextAwareTranslationEngine: mode LIGHT/COPILOT tetap pakai translate() ML Kit
            // biasa (fast path tidak berubah). Mode SMART memakai translateWithContext() ->
            // Gemini Nano kalau perangkat mendukung, otomatis fallback ke ML Kit kalau tidak.
            translationEngine = ContextAwareTranslationEngine(),
            cache = TranslationCache(context = applicationContext),
            // FallbackCopilotEngine: rantai tier — Gemini Nano -> Remote (VPS user, kalau
            // URL diisi) -> PlaceholderCopilotEngine rule-based (selalu berhasil). Tier
            // "model AI lokal on-device" (LiteRT-LM) DIHAPUS — terbukti crash native di RAM
            // 4GB, lihat catatan di FallbackCopilotEngine.kt.
            aiEngine = FallbackCopilotEngine(
                tiers = listOf(
                    GeminiNanoCopilotEngine(),
                    RemoteCopilotEngine(settingsRepository)
                )
            ),
            systemAudioSttEngine = VoskPcmSttEngine(voskModelManager),
            systemAudioModelManager = voskModelManager
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEverything()
                return START_NOT_STICKY
            }
            else -> startEverything(intent)
        }
        return START_STICKY
    }

    private fun startEverything(startIntent: Intent?) {
        // Token MediaProjection sudah didapat & divalidasi (RESULT_OK) di MainActivity SEBELUM
        // service ini dipanggil — di sinilah baru boleh benar-benar dibuat objek MediaProjection
        // dan dideklarasikan tipe foreground service "mediaProjection", sesuai syarat Android 14+
        // (tidak boleh deklarasi tipe itu tanpa token izin valid di tangan).
        val resultCode = startIntent?.getIntExtra(EXTRA_PROJECTION_RESULT_CODE, Int.MIN_VALUE)
            ?.takeIf { it != Int.MIN_VALUE }
        @Suppress("DEPRECATION")
        val resultData = startIntent?.getParcelableExtra<Intent>(EXTRA_PROJECTION_DATA)
        val hasProjectionToken = resultCode != null && resultData != null

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val serviceType = if (hasProjectionToken) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            }
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), serviceType)
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
        lifecycleRegistry.currentState = Lifecycle.State.RESUMED

        if (hasProjectionToken) {
            // FIX RACE CONDITION: sebelumnya startSystemAudioCapture() dipanggil di sini
            // (synchronous) SEBELUM collector setSystemAudioLanguageTag() di bawah sempat
            // jalan (collectLatest di coroutine terpisah, perlu waktu untuk emit pertama
            // kali) — jadi systemAudioLanguageTag di TranslationPipeline masih nyangkut di
            // default "en" saat startSystemAudio() membaca & meng-capture nilainya. Sekarang
            // baca nilai TERKINI secara eksplisit (.first(), bukan nunggu collector) SEBELUM
            // memulai capture, supaya bahasa yang dipilih di picker benar-benar kepakai sejak
            // detik pertama, bukan cuma untuk sesi System Audio berikutnya.
            lifecycleScope.launch {
                val auto = settingsRepository.autoDetect.first()
                val source = settingsRepository.sourceLanguage.first()
                pipeline.setSystemAudioLanguageTag(if (auto) "en" else source)
                startSystemAudioCapture(resultCode!!, resultData!!)
            }
        } else {
            lifecycleScope.launch { settingsRepository.setSystemAudioOn(false) }
        }

        lifecycleScope.launch {
            // Muat sekali di awal (bukan collectLatest terus-menerus) karena selama resize
            // berlangsung nilainya di-drive langsung oleh touch listener, bukan oleh DataStore.
            overlayWidthDp = settingsRepository.overlayWidth.first()
        }

        showOverlayPanel()

        lifecycleScope.launch {
            val target = settingsRepository.targetLanguage
            val auto = settingsRepository.autoDetect
            val source = settingsRepository.sourceLanguage
            // Ambil snapshot konfigurasi awal lalu pantau perubahan target/auto-detect secara live.
            kotlinx.coroutines.flow.combine(target, auto, source) { t, a, s ->
                Triple(t, a, if (a) null else s)
            }.collectLatest { (t, a, s) ->
                pipeline.configure(targetLanguageTag = t, autoDetect = a, sourceLanguageTag = s)
            }
        }

        // FIX: sebelumnya setSystemAudioLanguageTag() TIDAK PERNAH dipanggil — Vosk (System
        // Audio) selalu diam-diam pakai model Inggris apa pun bahasa yang dipilih di picker,
        // menghasilkan transkrip ngawur untuk audio berbahasa lain (mis. Mandarin/Jepang
        // "didengar" pakai model akustik Inggris). Vosk butuh model per-bahasa eksplisit —
        // tidak punya mode auto-detect offline seperti ML Kit — jadi kalau user masih di mode
        // Auto-detect, System Audio fallback ke "en" (satu-satunya asumsi masuk akal), dan
        // begitu user pilih bahasa eksplisit di picker "Dari", itu yang dipakai Vosk juga.
        lifecycleScope.launch {
            kotlinx.coroutines.flow.combine(
                settingsRepository.sourceLanguage,
                settingsRepository.autoDetect
            ) { source, auto -> if (auto) "en" else source }
                .collectLatest { tag -> pipeline.setSystemAudioLanguageTag(tag) }
        }

        lifecycleScope.launch {
            settingsRepository.micOn.collectLatest { micOn ->
                if (micOn) pipeline.startMic() else pipeline.stopMic()
            }
        }

        lifecycleScope.launch {
            settingsRepository.contextMessageLimit.collectLatest { limit ->
                pipeline.setContextLimit(limit)
            }
        }

        lifecycleScope.launch {
            settingsRepository.translationMode.collectLatest { mode ->
                pipeline.setCopilotEnabled(mode == TranslationMode.COPILOT)
                pipeline.setSmartModeEnabled(mode == TranslationMode.SMART)
            }
        }

        lifecycleScope.launch {
            settingsRepository.cloudSttApiKey.collectLatest { key -> cloudSttApiKey = key }
        }
    }

    private fun stopEverything() {
        stopSystemAudioCapture()
        pipeline.stopAll()
        removeOverlay()
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /**
     * Bikin MediaProjection dari token yang sudah divalidasi MainActivity, lalu mulai capture
     * lewat SystemAudioSource. Sejak Phase 3.1, audio yang tertangkap BENAR-BENAR ditranskripsi
     * (via Vosk, lihat TranslationPipeline.startSystemAudio() & VoskPcmSttEngine) — bukan lagi
     * sekadar di-drain. state.systemAudioSttStatus mencerminkan progres itu apa adanya
     * (mengunduh model / menyiapkan / mentranskripsi / bahasa belum didukung / error), supaya
     * overlay tidak menjanjikan transkrip yang tidak akan muncul.
     */
    private fun startSystemAudioCapture(resultCode: Int, resultData: Intent) {
        val manager = getSystemService(MediaProjectionManager::class.java) ?: return
        val projection = try {
            manager.getMediaProjection(resultCode, resultData)
        } catch (e: Exception) {
            null
        } ?: return

        projection.registerCallback(projectionCallback, mainHandler)
        mediaProjection = projection

        val source = SystemAudioSource(applicationContext, projection)
        systemAudioSource = source
        pipeline.startSystemAudio(source)
        lifecycleScope.launch { settingsRepository.setSystemAudioOn(true) }
    }

    private fun stopSystemAudioCapture() {
        pipeline.stopSystemAudio()
        systemAudioSource = null
        mediaProjection?.let {
            runCatching { it.unregisterCallback(projectionCallback) }
            runCatching { it.stop() }
        }
        mediaProjection = null
        lifecycleScope.launch { settingsRepository.setSystemAudioOn(false) }
    }

    private fun showOverlayPanel() {
        removeOverlay()
        isMinimized = false

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                val state by pipeline.state.collectAsState()
                val opacity by settingsRepository.overlayOpacity.collectAsState(initial = 0.92f)
                val fontSize by settingsRepository.overlayFontSize.collectAsState(initial = 14)

                if (isMinimized) {
                    OverlayBubble(onTap = { toggleMinimize() })
                } else {
                    OverlayScreen(
                        state = state,
                        opacity = opacity,
                        fontSizeSp = fontSize,
                        widthDp = overlayWidthDp,
                        onToggleMic = { toggleMic(state) },
                        onMinimize = { toggleMinimize() },
                        onClose = { stopEverything() },
                        onClearConversation = { pipeline.clearConversation() }
                    )
                }
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 200
        }

        windowManager.addView(composeView, params)
        overlayComposeView = composeView
        overlayLayoutParams = params
        attachDragAndResizeHandling(composeView, params)
    }

    /**
     * Satu touch listener yang menangani DUA gesture pada window overlay:
     *  1. Drag-to-move + snap-to-edge (Phase 1) — sentuh & geser di area mana pun.
     *  2. Resize lebar panel (Phase 2) — sentuh & geser mulai dari kotak kecil di
     *     pojok kanan-bawah (`RESIZE_HANDLE_DP`), ditandai ikon di `OverlayScreen`.
     *
     * Keduanya sengaja ditangani di level View (bukan pointerInput Compose di dalam
     * handle) supaya tidak berebut event dengan drag-to-move yang juga di level View —
     * kalau resize pakai gesture detector Compose terpisah, ACTION_MOVE-nya bisa lebih
     * dulu "dimakan" sebagai drag-to-move begitu melewati touch slop.
     *
     * Klik singkat (gerakan < touchSlop) tetap diteruskan sebagai tap normal ke Compose
     * (mis. tombol minimize/mic) karena FLAG_NOT_FOCUSABLE membuat event tap tetap sampai
     * ke child view saat tidak dianggap sebagai drag/resize.
     */
    private fun attachDragAndResizeHandling(view: ComposeView, params: WindowManager.LayoutParams) {
        var startTouchX = 0f
        var startTouchY = 0f
        var startX = 0
        var startY = 0
        var startWidthDp = DEFAULT_OVERLAY_WIDTH_DP
        var mode = TouchMode.NONE
        // FIX: sebelumnya 16f piksel MENTAH (bukan disesuaikan density layar) — di HP density
        // tinggi (umum di 2024+), ini jauh LEBIH KECIL dari standar getaran tangan wajar saat
        // tap, jadi tap singkat pun sering salah kedeteksi sebagai mulai drag -> ACTION_UP
        // ikut "dimakan" touch listener ini (consumed=true) sebelum sempat sampai ke tombol
        // Compose di bawahnya (mis. tombol minimize "−") -> tombol terasa "tidak berfungsi".
        // ViewConfiguration.scaledTouchSlop() memberi nilai piksel yang sudah disesuaikan
        // density & sesuai standar sistem Android untuk membedakan tap vs drag.
        val touchSlopPx = android.view.ViewConfiguration.get(this).scaledTouchSlop.toFloat()
        val density = resources.displayMetrics.density
        val handlePx = RESIZE_HANDLE_DP * density

        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startTouchX = event.rawX
                    startTouchY = event.rawY
                    startX = params.x
                    startY = params.y
                    startWidthDp = overlayWidthDp
                    // event.x/y relatif ke view (bukan rawX/rawY layar) — pas untuk cek
                    // apakah jari mulai dari kotak resize di pojok kanan-bawah.
                    val startedOnHandle = !isMinimized &&
                        event.x >= v.width - handlePx && event.y >= v.height - handlePx
                    mode = if (startedOnHandle) TouchMode.PENDING_RESIZE else TouchMode.PENDING_MOVE
                    false // biarkan Compose tetap memproses tap di bawahnya
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - startTouchX
                    val dy = event.rawY - startTouchY
                    val pastSlop = kotlin.math.abs(dx) > touchSlopPx || kotlin.math.abs(dy) > touchSlopPx

                    when (mode) {
                        TouchMode.PENDING_RESIZE -> if (pastSlop) mode = TouchMode.RESIZE
                        TouchMode.PENDING_MOVE -> if (pastSlop) mode = TouchMode.MOVE
                        else -> {}
                    }

                    when (mode) {
                        TouchMode.RESIZE -> {
                            val deltaDp = (dx / density).toInt()
                            overlayWidthDp = (startWidthDp + deltaDp)
                                .coerceIn(MIN_OVERLAY_WIDTH_DP, MAX_OVERLAY_WIDTH_DP)
                        }
                        TouchMode.MOVE -> {
                            params.x = (startX + dx).toInt()
                            params.y = (startY + dy).toInt()
                            runCatching { windowManager.updateViewLayout(view, params) }
                        }
                        else -> {}
                    }
                    mode == TouchMode.MOVE || mode == TouchMode.RESIZE
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val consumed = mode == TouchMode.MOVE || mode == TouchMode.RESIZE
                    when (mode) {
                        TouchMode.MOVE -> snapToNearestEdge(view, params)
                        TouchMode.RESIZE -> lifecycleScope.launch {
                            settingsRepository.setOverlayWidth(overlayWidthDp)
                        }
                        else -> {}
                    }
                    mode = TouchMode.NONE
                    consumed
                }
                else -> false
            }
        }
    }

    private fun snapToNearestEdge(view: ComposeView, params: WindowManager.LayoutParams) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(metrics)
        val screenWidth = metrics.widthPixels
        val viewWidth = view.width.takeIf { it > 0 } ?: 320
        val centerX = params.x + viewWidth / 2
        val targetX = if (centerX < screenWidth / 2) 0 else screenWidth - viewWidth

        val animator = ValueAnimator.ofInt(params.x, targetX).apply {
            duration = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                params.x = it.animatedValue as Int
                runCatching { windowManager.updateViewLayout(view, params) }
            }
        }
        animator.start()
    }

    private fun toggleMinimize() {
        isMinimized = !isMinimized
        showOverlayPanel()
    }

    private fun toggleMic(current: TranslatorState) {
        lifecycleScope.launch { settingsRepository.setMicOn(!current.micOn) }
    }

    private fun removeOverlay() {
        overlayComposeView?.let {
            runCatching { windowManager.removeView(it) }
        }
        overlayComposeView = null
    }

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "ADJDEV Live Translate",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Status penerjemahan realtime sedang aktif" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Translator Active")
            .setContentText("Menerjemahkan percakapan secara realtime")
            .setOngoing(true)
            .setContentIntent(contentIntent)
            .addAction(0, "Stop", stopIntent)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        removeOverlay()
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        super.onDestroy()
    }
}
