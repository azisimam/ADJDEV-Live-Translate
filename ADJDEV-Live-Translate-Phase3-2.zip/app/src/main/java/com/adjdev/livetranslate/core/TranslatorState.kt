package com.adjdev.livetranslate.core

import com.adjdev.livetranslate.ai.SuggestedReply

/** Status pipeline realtime, dikonsumsi oleh overlay & UI utama. */
data class TranslatorState(
    val isRunning: Boolean = false,
    val micOn: Boolean = false,
    val systemAudioOn: Boolean = false,
    // Status transkripsi System Audio (Phase 3.1: integrasi Vosk) — beda dari systemAudioOn
    // (yang cuma berarti "capture PCM aktif"). Lihat VoskModelManager.ModelPrepStatus.
    val systemAudioSttStatus: SystemAudioSttStatus = SystemAudioSttStatus.Idle,
    val partialSourceText: String = "",
    // Terjemahan "live" dari partialSourceText, di-debounce (Phase 2). Best-effort — kalau
    // gagal/telat, tidak memblokir apa pun; final translation tetap datang dari handleFinalTranscript.
    val partialTranslatedText: String = "",
    val lastSourceText: String = "",
    val lastTranslatedText: String = "",
    val detectedLanguage: String? = null,
    val errorMessage: String? = null,
    // Diisi langsung dari TranslationPipeline.configure() (bukan nunggu translate sukses) —
    // null kalau mode Auto-detect, berisi kode bahasa kalau user pilih eksplisit. Overlay
    // header pakai ini SEBAGAI PRIORITAS di atas `detectedLanguage`.
    val configuredSourceLanguage: String? = null,
    // AI Path (Copilot, §11): diisi belakangan setelah translation tampil, tidak pernah
    // ditunggu oleh fast path. Kosong kalau mode bukan COPILOT atau AI belum selesai.
    val suggestedReplies: List<SuggestedReply> = emptyList(),
    // Diagnostik saat suggestedReplies kosong padahal COPILOT aktif — sebelumnya kegagalan di
    // sini (mis. VPS balas error, model name salah) diam-diam total. Null = belum ada percobaan
    // AI Path SEJAK translation terakhir, ATAU percobaan terakhir berhasil (suggestedReplies
    // terisi). Lihat TranslationPipeline.triggerAiPathIfEnabled & AIEngine.lastError.
    val copilotErrorMessage: String? = null
)

/** Ditampilkan overlay supaya user tahu persis kenapa transkrip System Audio belum muncul. */
sealed class SystemAudioSttStatus {
    data object Idle : SystemAudioSttStatus()
    data class DownloadingModel(val progressPercent: Int) : SystemAudioSttStatus()
    data object PreparingModel : SystemAudioSttStatus()
    data object Transcribing : SystemAudioSttStatus()
    data class Unsupported(val languageTag: String) : SystemAudioSttStatus()
    data class Error(val message: String) : SystemAudioSttStatus()
}
