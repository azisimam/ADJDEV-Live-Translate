package com.adjdev.livetranslate

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.adjdev.livetranslate.ai.local.LocalLlmModelManager
import com.adjdev.livetranslate.audio.SystemAudioSource
import com.adjdev.livetranslate.overlay.OverlayService
import com.adjdev.livetranslate.settings.TranslationMode
import com.adjdev.livetranslate.ui.theme.ADJDEVLiveTranslateTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ADJDEVLiveTranslateTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen(viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current

    val micOn by viewModel.settings.micOn.collectAsState(initial = true)
    val systemAudioOn by viewModel.settings.systemAudioOn.collectAsState(initial = false)
    val autoDetect by viewModel.settings.autoDetect.collectAsState(initial = true)
    val mode by viewModel.settings.translationMode.collectAsState(initial = TranslationMode.LIGHT)
    val localLlmEnabled by viewModel.settings.localLlmEnabled.collectAsState(initial = false)

    var isRunning by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    val systemAudioSupported = SystemAudioSource.isSupported

    val recordAudioPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    // Alur izin capture audio sistem (MediaProjection) — dialog sistem diminta lewat launcher
    // ini SAAT user menekan "Start Translator" dengan toggle System Audio ON, lalu resultCode
    // + data dikirim ke OverlayService lewat extras Intent supaya service yang membuat
    // MediaProjection-nya sendiri lewat MediaProjectionManager.getMediaProjection(...).
    val projectionManager = remember {
        context.getSystemService(MediaProjectionManager::class.java)
    }
    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            startTranslatorService(context, projectionResultCode = result.resultCode, projectionData = result.data)
            isRunning = true
        } else {
            // User menolak dialog capture sistem: tetap jalankan translator tapi hanya
            // dengan Microphone, System Audio otomatis dimatikan lagi untuk sesi ini.
            viewModel.setSystemAudioOn(false)
            startTranslatorService(context, projectionResultCode = null, projectionData = null)
            isRunning = true
        }
    }

    if (showHelp) {
        HelpDialog(systemAudioSupported = systemAudioSupported, onDismiss = { showHelp = false })
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ADJDEV Live Translate", style = MaterialTheme.typography.headlineSmall)
            IconButton(onClick = { showHelp = true }) {
                Icon(Icons.Filled.HelpOutline, contentDescription = "Bantuan & keterangan")
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (isRunning) "\uD83D\uDFE2 Translator Active" else "\u26AA Translator Idle")
        }

        Text("Language: AUTO", style = MaterialTheme.typography.bodyMedium)

        HorizontalDivider()

        Text("Input", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(selected = micOn, onClick = { viewModel.setMicOn(!micOn) }, label = { Text("\uD83C\uDF99 Microphone") })
            FilterChip(
                selected = systemAudioOn,
                onClick = { viewModel.setSystemAudioOn(!systemAudioOn) },
                enabled = systemAudioSupported,
                label = { Text("\uD83D\uDD0A System Audio") }
            )
        }
        if (!systemAudioSupported) {
            Text(
                "Butuh Android 10+ — tidak tersedia di perangkat ini.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        HorizontalDivider()

        Text("Mode", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == TranslationMode.LIGHT, onClick = { viewModel.setMode(TranslationMode.LIGHT) }, label = { Text("\uD83D\uDFE2 LIGHT") })
            FilterChip(selected = mode == TranslationMode.SMART, onClick = { viewModel.setMode(TranslationMode.SMART) }, label = { Text("\uD83D\uDFE1 SMART") })
            FilterChip(selected = mode == TranslationMode.COPILOT, onClick = { viewModel.setMode(TranslationMode.COPILOT) }, label = { Text("\uD83D\uDD34 COPILOT") })
        }
        if (mode == TranslationMode.COPILOT || mode == TranslationMode.SMART) {
            Text(
                "Urutan otomatis: Gemini Nano \u2192 Remote (VPS) \u2192 Model lokal (kalau " +
                    "diaktifkan) \u2192 rule-based. Ketuk \u2753 di pojok kanan atas untuk detail.",
                style = MaterialTheme.typography.bodySmall
            )
        }

        if (mode == TranslationMode.COPILOT) {
            HorizontalDivider()
            RemoteCopilotSection(viewModel)

            HorizontalDivider()
            LocalLlmModelSection(
                localLlmEnabled = localLlmEnabled,
                onLocalLlmEnabledChange = { viewModel.setLocalLlmEnabled(it) }
            )
        }

        HorizontalDivider()

        Button(
            onClick = {
                val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                    context, Manifest.permission.RECORD_AUDIO
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (!hasMic) {
                    recordAudioPermission.launch(Manifest.permission.RECORD_AUDIO)
                    return@Button
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val hasNotif = androidx.core.content.ContextCompat.checkSelfPermission(
                        context, Manifest.permission.POST_NOTIFICATIONS
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!hasNotif) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (!Settings.canDrawOverlays(context)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    overlayPermissionLauncher.launch(intent)
                    return@Button
                }

                if (systemAudioOn && systemAudioSupported && projectionManager != null) {
                    projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
                    return@Button
                }

                startTranslatorService(context, projectionResultCode = null, projectionData = null)
                isRunning = true
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isRunning
        ) { Text("Start Translator") }

        OutlinedButton(
            onClick = {
                context.startService(Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
                isRunning = false
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = isRunning
        ) { Text("Stop Translator") }
    }
}

private fun startTranslatorService(
    context: android.content.Context,
    projectionResultCode: Int?,
    projectionData: Intent?
) {
    val intent = Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_START)
    if (projectionResultCode != null && projectionData != null) {
        intent.putExtra(OverlayService.EXTRA_PROJECTION_RESULT_CODE, projectionResultCode)
        intent.putExtra(OverlayService.EXTRA_PROJECTION_DATA, projectionData)
    }
    context.startForegroundService(intent)
}

/**
 * Semua teks penjelasan panjang yang sebelumnya nempel di alur utama (bikin scroll jadi
 * panjang) dipindah ke sini, dibuka lewat ikon \u2753 di header. Alur utama jadi cuma kontrol +
 * hint sebaris pendek.
 */
@Composable
private fun HelpDialog(systemAudioSupported: Boolean, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Bantuan & Keterangan") },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .heightIn(max = 480.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                HelpSection(
                    title = "System Audio",
                    body = if (!systemAudioSupported) {
                        "Butuh Android 10 (Q) ke atas dan tidak tersedia di perangkat ini."
                    } else {
                        "Menangkap audio yang diputar aplikasi lain (video/musik/game), BUKAN " +
                            "audio panggilan VoIP. Dialog izin capture layar/audio muncul saat " +
                            "kamu menekan Start Translator dengan toggle ini aktif. Untuk " +
                            "translate suara lawan bicara di panggilan telepon/VoIP, tetap " +
                            "pakai mode Microphone + loudspeaker."
                    }
                )
                HelpSection(
                    title = "Mode LIGHT / SMART / COPILOT",
                    body = "LIGHT: terjemahan cepat biasa. SMART: terjemahan yang " +
                        "mempertimbangkan konteks percakapan (pakai Gemini Nano kalau device " +
                        "mendukung, fallback ke terjemahan biasa kalau tidak). COPILOT: " +
                        "menambahkan saran balasan (Suggested Replies), dicoba berurutan lewat " +
                        "beberapa \"tier\" — lihat bagian AI Copilot di bawah."
                )
                HelpSection(
                    title = "AI Copilot (Suggested Replies) — urutan tier",
                    body = "1) Gemini Nano on-device via AICore — kalau device flagship yang " +
                        "didukung (mis. Pixel 8+, Galaxy S24+), tidak butuh apa pun tambahan. " +
                        "2) Remote (VPS milik kamu sendiri) — kalau URL sudah diisi di bawah, " +
                        "lebih ringan/stabil untuk device kelas menengah dibanding model lokal, " +
                        "tapi transcript dikirim lewat jaringan ke server itu. 3) Model AI " +
                        "lokal — OPT-IN, harus dinyalakan sadar lewat toggle di bawah karena " +
                        "pernah menyebabkan APP CRASH TOTAL (native, tidak bisa dicegah kode) " +
                        "di device RAM 4GB kelas menengah saat menghasilkan saran. 4) Rule-based " +
                        "— jaring pengaman terakhir, selalu berhasil walau saranya generik."
                )
                HelpSection(
                    title = "Remote AI (VPS)",
                    body = "Isi URL server LLM di VPS kamu sendiri (mis. llama.cpp server, " +
                        "Ollama, atau vLLM yang expose endpoint OpenAI-compatible " +
                        "\"/v1/chat/completions\"), contoh: http://203.0.113.5:8080 — tanpa " +
                        "path, tanpa garis miring di akhir (boleh juga diisi sampai \"...:8080/v1\" " +
                        "kalau itu yang kamu pakai buat curl test — app ini otomatis mendeteksi " +
                        "biar tidak dobel jadi \"/v1/v1/chat/completions\"). API Key opsional (isi kalau server " +
                        "kamu butuh Authorization Bearer token). Nama Model opsional — " +
                        "kebanyakan server single-model mengabaikan field ini. Kosongkan URL " +
                        "untuk melewati tier ini sepenuhnya. Catatan: server VPS pribadi " +
                        "biasanya belum punya HTTPS, jadi http:// polos sengaja diizinkan " +
                        "(usesCleartextTraffic) — kalau VPS-nya diakses lewat internet publik " +
                        "(bukan cuma VPN/LAN pribadi), sangat disarankan pasang reverse proxy " +
                        "TLS gratis (mis. Caddy) di depannya."
                )
                HelpSection(
                    title = "Model AI Lokal",
                    body = "Model .litertlm TIDAK dibundel/di-download otomatis — download " +
                        "sendiri (mis. Gemma3-1B-IT, sekitar 500MB+) dari HuggingFace LiteRT " +
                        "Community, lalu Import lewat file picker. \u26A0\uFE0F Berat untuk RAM " +
                        "4GB ke bawah dan PERNAH MENYEBABKAN APP CRASH TOTAL (native, tidak " +
                        "bisa dicegah dari sisi kode) saat menghasilkan saran — makanya default " +
                        "OFF, nyalakan hanya kalau device kamu cukup kuat dan kamu paham " +
                        "risikonya. Kalau sering crash/lemot, matikan togglenya lagi; app tetap " +
                        "jalan normal lewat tier lain."
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}

@Composable
private fun HelpSection(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, style = MaterialTheme.typography.titleSmall)
        Text(body, style = MaterialTheme.typography.bodySmall)
    }
}

/**
 * Kontrol untuk RemoteCopilotEngine (tier 2 COPILOT) — VPS milik user sendiri. Field disimpan
 * lokal dulu di Compose state, ditulis ke DataStore lewat tombol "Simpan" (bukan tiap keystroke)
 * supaya tidak nulis DataStore berkali-kali saat user masih mengetik.
 */
@Composable
private fun RemoteCopilotSection(viewModel: MainViewModel) {
    val savedUrl by viewModel.settings.remoteCopilotUrl.collectAsState(initial = null)
    val savedApiKey by viewModel.settings.remoteCopilotApiKey.collectAsState(initial = null)
    val savedModelName by viewModel.settings.remoteCopilotModelName.collectAsState(initial = "local-model")

    var urlInput by remember(savedUrl) { mutableStateOf(savedUrl ?: "") }
    var apiKeyInput by remember(savedApiKey) { mutableStateOf(savedApiKey ?: "") }
    var modelNameInput by remember(savedModelName) { mutableStateOf(savedModelName) }
    var showApiKey by remember { mutableStateOf(false) }
    var saved by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Remote AI (VPS sendiri, opsional)", style = MaterialTheme.typography.titleMedium)
        Text(
            if (savedUrl.isNullOrBlank()) {
                "Belum dikonfigurasi — tier ini dilewati. Ketuk \u2753 untuk cara setup."
            } else {
                "\u2705 Aktif: $savedUrl"
            },
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = urlInput,
            onValueChange = { urlInput = it; saved = false },
            label = { Text("URL VPS (mis. http://203.0.113.5:8080)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = apiKeyInput,
            onValueChange = { apiKeyInput = it; saved = false },
            label = { Text("API Key (opsional)") },
            singleLine = true,
            visualTransformation = if (showApiKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                TextButton(onClick = { showApiKey = !showApiKey }) {
                    Text(if (showApiKey) "Sembunyikan" else "Lihat", style = MaterialTheme.typography.labelSmall)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = modelNameInput,
            onValueChange = { modelNameInput = it; saved = false },
            label = { Text("Nama Model (opsional)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = {
                viewModel.setRemoteCopilotUrl(urlInput.trim().ifBlank { null })
                viewModel.setRemoteCopilotApiKey(apiKeyInput.trim().ifBlank { null })
                viewModel.setRemoteCopilotModelName(modelNameInput.trim().ifBlank { "local-model" })
                saved = true
            }) { Text("Simpan") }
            if (saved) {
                Text("\u2705 Tersimpan", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

/**
 * UI untuk import model .litertlm secara manual (lihat catatan kejujuran di
 * LocalLlmModelManager) + toggle opt-in eksplisit karena tier ini pernah menyebabkan crash
 * native yang tidak bisa dicegah dari kode (lihat LocalLlmCopilotEngine).
 */
@Composable
private fun LocalLlmModelSection(
    localLlmEnabled: Boolean,
    onLocalLlmEnabledChange: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val modelManager = remember { LocalLlmModelManager(context) }
    var isReady by remember { mutableStateOf(modelManager.isModelReady()) }
    var sizeMb by remember { mutableStateOf(modelManager.modelSizeMb()) }
    var importError by remember { mutableStateOf<String?>(null) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val success = modelManager.importFrom(uri)
        isReady = modelManager.isModelReady()
        sizeMb = modelManager.modelSizeMb()
        importError = if (!success) "Import gagal — pastikan file .litertlm valid dan cukup ruang penyimpanan." else null
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Model AI Lokal (opsional, untuk COPILOT)", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = localLlmEnabled, onCheckedChange = onLocalLlmEnabledChange)
            Text(
                "Aktifkan model lokal \u26A0\uFE0F bisa crash di HP kelas menengah",
                style = MaterialTheme.typography.bodySmall
            )
        }
        Text(
            if (isReady) "\u2705 Model tersimpan (${sizeMb} MB)." else "Belum ada model tersimpan.",
            style = MaterialTheme.typography.bodySmall
        )
        importError?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) {
                Text(if (isReady) "Ganti Model" else "Import Model (.litertlm)")
            }
            if (isReady) {
                OutlinedButton(onClick = {
                    modelManager.deleteModel()
                    isReady = false
                }) { Text("Hapus") }
            }
        }
    }
}
