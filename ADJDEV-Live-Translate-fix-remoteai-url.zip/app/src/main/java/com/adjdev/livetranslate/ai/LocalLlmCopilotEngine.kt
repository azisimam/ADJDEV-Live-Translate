package com.adjdev.livetranslate.ai

import com.adjdev.livetranslate.ai.local.LocalLlmModelManager
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Implementasi COPILOT pakai model kecil quantized on-device SUNGGUHAN, lewat LiteRT-LM
 * (com.google.ai.edge.litertlm — penerus resmi MediaPipe LLM Inference API yang sudah
 * deprecated per Maret 2026). Ini tier KEDUA dalam rantai fallback (lihat FallbackCopilotEngine
 * versi baru): dicoba kalau Gemini Nano/AICore tidak didukung device, SEBELUM jatuh ke
 * PlaceholderCopilotEngine rule-based.
 *
 * ⚠️ PERINGATAN JUJUR — kamu sudah pilih opsi ini sadar akan trade-off-nya:
 *  - Model TIDAK dibundel/di-download otomatis (lihat LocalLlmModelManager) — kalau belum
 *    di-import user, status langsung UNAVAILABLE, otomatis lanjut ke rule-based tanpa error.
 *  - Model instruct terkecil yang wajar (Gemma3-1B-IT, ~529MB int4) tetap berat untuk RAM 4GB
 *    kelas Redmi Note 13 4G ketika berjalan BERSAMAAN dengan foreground service, ML Kit
 *    Translate/LanguageID, dan (kalau System Audio aktif) model Vosk sekaligus. Realistis:
 *    bisa lambat (beberapa detik per saran), atau engine.initialize() gagal/di-OOM-kill kalau
 *    RAM device sedang penuh — makanya generateSuggestions() dibungkus timeout supaya gagal
 *    dengan rapi (list kosong) bukan nge-hang/nge-freeze overlay.
 *  - Ditulis mengikuti dokumentasi resmi LiteRT-LM Kotlin API per Mei 2026, BELUM PERNAH
 *    dikompilasi/dites di device nyata (tidak ada Android SDK/internet di sandbox pembuatan
 *    ini). Ada catatan komunitas soal litertlm-android versi tertentu butuh class file Java 21
 *    — build.gradle.kts sudah dinaikkan ke Java 21 untuk berjaga-jaga, cek pertama kalau ada
 *    error compile "class file has wrong version".
 */
class LocalLlmCopilotEngine(
    private val modelManager: LocalLlmModelManager,
    // Opt-in eksplisit dari Settings (default false). Dicek SEBELUM apa pun lain di load() —
    // ini baris pertahanan utama supaya tier ini tidak pernah auto-jalan di device yang belum
    // pernah "disetujui" secara sadar oleh usernya. Lihat FallbackCopilotEngine untuk urutan
    // tier & SettingsRepository.localLlmEnabled untuk alasan default-nya OFF.
    private val isEnabled: () -> Boolean
) : AIEngine {

    private var engine: Engine? = null

    override var status: AIEngineStatus = AIEngineStatus.IDLE
        private set

    override suspend fun load() {
        if (status == AIEngineStatus.READY) return
        if (!isEnabled()) {
            status = AIEngineStatus.UNAVAILABLE
            return
        }
        if (!modelManager.isModelReady()) {
            status = AIEngineStatus.UNAVAILABLE
            return
        }
        status = AIEngineStatus.LOADING
        status = try {
            val config = EngineConfig(modelPath = modelManager.modelPath())
            val newEngine = Engine(config)
            newEngine.initialize()
            engine = newEngine
            AIEngineStatus.READY
        } catch (e: Exception) {
            runCatching { engine?.close() }
            engine = null
            AIEngineStatus.UNAVAILABLE
        }
    }

    override fun unload() {
        runCatching { engine?.close() }
        engine = null
        // Jangan timpa UNAVAILABLE (mis. model belum di-import) supaya FallbackCopilotEngine
        // tidak coba-coba load ulang tiap toggle Copilot off/on kalau memang belum siap.
        if (status != AIEngineStatus.UNAVAILABLE) status = AIEngineStatus.IDLE
    }

    override suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>
    ): List<SuggestedReply> {
        val eng = engine ?: return emptyList()
        if (status != AIEngineStatus.READY) return emptyList()
        status = AIEngineStatus.GENERATING

        val suggestions = try {
            // Timeout jaring-pengaman: hardware mid-range/di-bawahnya bisa jauh lebih lambat
            // dari device pengujian resmi Google. 12 detik dipilih supaya masih "hidup" secara
            // realtime chat, tapi tidak nge-freeze pengalaman kalau ternyata terlalu berat.
            withTimeoutOrNull(12_000) {
                val contextBlock = recentContext.takeLast(6).joinToString("\n") { "- $it" }
                val prompt = """
                    Ini percakapan yang sedang diterjemahkan live. Giliran-giliran sebelumnya:
                    $contextBlock

                    Pesan lawan bicara barusan: "$incomingTranslatedText"

                    Beri TEPAT 3 saran balasan singkat (maksimal 12 kata masing-masing), dalam
                    bahasa yang sama dengan pesan barusan, terdengar natural seperti obrolan
                    sungguhan, dengan isi berbeda-beda: 1) jawaban singkat/langsung, 2) tanggapan
                    natural/santai yang menyambung topik, 3) SATU pertanyaan balik yang relevan.
                    Balas HANYA 3 baris berisi saran itu saja — tanpa nomor, tanpa tanda kutip,
                    tanpa penjelasan.
                """.trimIndent()

                val fullText = StringBuilder()
                eng.createConversation().use { conversation ->
                    conversation.sendMessageAsync(prompt)
                        .catch { /* biarkan fullText apa adanya sampai titik gagal */ }
                        .collect { chunk -> fullText.append(chunk) }
                }

                fullText.toString()
                    .lines()
                    .map { it.trim().trimStart('-', '*', '•').trim().trim('"') }
                    .filter { it.isNotBlank() }
                    .take(3)
                    .map { SuggestedReply(it, ReplyTone.NATURAL) }
            } ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }

        status = AIEngineStatus.READY
        return suggestions
    }
}
