package com.adjdev.livetranslate.ai

/**
 * Composite untuk mode COPILOT — rantai tier yang dicoba BERURUTAN sampai satu tier READY:
 *   1. Gemini Nano via AICore — kalau device flagship yang didukung (Pixel 8+, Galaxy S24+,
 *      dst), kualitas terbaik & tidak butuh apa pun tambahan dari user.
 *   2. Remote (VPS milik user sendiri, RemoteCopilotEngine) — kalau user sudah isi URL di
 *      Settings. Butuh jaringan, tapi jauh lebih ringan/stabil untuk device kelas menengah
 *      dibanding model lokal (lihat catatan crash di LocalLlmCopilotEngine).
 *   3. Model kecil quantized on-device via LiteRT-LM (LocalLlmCopilotEngine) — OPT-IN, hanya
 *      dicoba kalau user secara SADAR menyalakan toggle "Aktifkan model AI lokal" di Settings
 *      DAN sudah import model .litertlm sendiri. Default OFF karena pernah menyebabkan crash
 *      native (SIGSEGV di liblitertlm_jni.so, tidak bisa ditangkap try/catch) di device RAM 4GB.
 *   4. Rule-based (PlaceholderCopilotEngine) — selalu berhasil, jaring pengaman terakhir supaya
 *      Suggested Replies tidak pernah mati total.
 *
 * Pipeline/UI tidak perlu tahu tier mana yang aktif — cukup pakai kontrak AIEngine seperti
 * biasa. Begitu satu tier UNAVAILABLE saat load(), langsung coba tier berikutnya di load() yang
 * sama (bukan nunggu toggle ulang). `tiers` TIDAK termasuk fallback — fallback selalu dicoba
 * terakhir dan tidak pernah di-skip, supaya urutan ini tidak bisa "salah setup" jadi tanpa
 * jaring pengaman sama sekali.
 */
class FallbackCopilotEngine(
    private val tiers: List<AIEngine>,
    private val fallback: AIEngine = PlaceholderCopilotEngine()
) : AIEngine {

    private var active: AIEngine = fallback

    override val status: AIEngineStatus get() = active.status

    override suspend fun load() {
        for (tier in tiers) {
            tier.load()
            if (tier.status == AIEngineStatus.READY) {
                active = tier
                return
            }
        }
        active = fallback
        fallback.load()
    }

    override fun unload() {
        tiers.forEach { it.unload() }
        fallback.unload()
    }

    override suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>
    ): List<SuggestedReply> = active.generateSuggestions(incomingTranslatedText, recentContext)
}
