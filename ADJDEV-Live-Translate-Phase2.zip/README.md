# ADJDEV Live Translate — Phase 1 + sebagian Phase 2

Floating-overlay live translator untuk penggunaan pribadi. Native Android (Kotlin + Jetpack
Compose), local-first, tanpa backend/VPS/login/cloud database.

## ⚠️ Belum bisa langsung diinstall dari sini

Ini adalah source project, bukan APK. Sandbox pembuatan project ini tidak punya akses internet
(dibutuhkan Gradle untuk mengunduh dependency) maupun Android SDK terpasang, jadi saya tidak bisa
mengcompile APK di sisi saya. Untuk mendapatkan APK yang bisa diinstall:

1. Buka folder ini di Android Studio → Run ke device fisik via USB (paling gampang, wrapper
   Gradle akan di-generate otomatis), **atau**
2. Kalau sudah ada Gradle terpasang lokal: `gradle wrapper --gradle-version 8.7` lalu
   `./gradlew assembleDebug` → APK ada di `app/build/outputs/apk/debug/`.

### Kalau pakai IDE Gradle di HP (mis. AndroidIDE, dan sejenisnya)

Jika muncul error semacam **"Tidak ditemukan module aplikasi dalam proyek"**, dua hal yang perlu
dicek:

- **Buka folder yang BENAR sebagai project root.** Zip ini sekarang di-package rata (flat) —
  `settings.gradle.kts` ada persis di root arsip, bukan di dalam subfolder lagi. Pastikan aplikasi
  IDE-mu membuka folder hasil ekstrak zip ini langsung (yang berisi `settings.gradle.kts`,
  `build.gradle.kts`, dan folder `app/` sejajar), bukan folder di atasnya.
- **Gradle wrapper** (`gradlew`, `gradle/wrapper/gradle-wrapper.properties`) sudah saya tambahkan.
  Namun **`gradle-wrapper.jar`** (file binary bootstrap Gradle) belum ada — saya tidak punya akses
  internet untuk mengunduhnya. Kalau IDE di HP-mu butuh file ini secara eksplisit dan tidak
  auto-generate, jalankan `gradle wrapper` sekali di device tersebut (kalau ada Gradle bawaan
  aplikasinya) untuk melengkapi file jar itu, atau unduh manual dari
  `https://services.gradle.org/distributions/` sesuai versi di `gradle-wrapper.properties`.

Saya belum pernah menguji aplikasi RiSETiDEx secara spesifik, jadi kalau setelah dua perbaikan di
atas masih error yang sama, kemungkinan besar app tersebut punya persyaratan struktur project
yang lebih spesifik (mis. hanya mendukung Groovy DSL `settings.gradle`/`build.gradle`, bukan
Kotlin DSL `.kts`) — beri tahu saya pesan error persisnya dan saya bisa coba convert project ke
Groovy DSL sebagai alternatif.

## Status: Phase 1 (selesai) + Phase 2 (selesai sesuai checklist §20, minus profiling formal)

Yang sudah dibangun di skeleton ini:

- Project Android (Gradle Kotlin DSL), struktur modular sesuai spesifikasi (`audio/`, `stt/`,
  `translation/`, `detection/`, `vad/`, `overlay/`, `settings/`, `storage/`, `core/`).
- Floating overlay (panel penuh + bubble minimized) via `WindowManager` + Compose, dikelola oleh
  satu Foreground Service (`OverlayService`).
- Mic capture (`MicAudioSource`, `AudioRecord`) dengan toggle ON/OFF yang benar-benar melepas
  resource saat OFF.
- System audio capture (`SystemAudioSource`, `AudioPlaybackCaptureConfiguration`, API 29+) —
  lihat **Keterbatasan** di bawah.
- VAD berbasis energi (RMS), ringan, dipakai sebagai gate agar STT tidak selalu aktif.
- STT via `android.speech.SpeechRecognizer` (prioritas on-device jika tersedia).
- Deteksi bahasa otomatis via ML Kit Language ID (on-device).
- Terjemahan via ML Kit Translate (on-device setelah model per pasangan bahasa diunduh sekali).
- Cache terjemahan lokal (LRU, in-memory, dibatasi ukurannya).
- Settings lokal via DataStore (bukan cloud, tidak ada login).
- UI utama sesuai spesifikasi §13 (status, input toggle, mode selector, Start/Stop).

Tambahan Phase 2 yang sudah masuk:

- **Overlay draggable + snap-to-edge**: `OverlayService.attachDragHandling()` — geser panel,
  lepas, otomatis nempel ke tepi kiri/kanan layar terdekat dengan animasi singkat.
- **Translation cache persist**: `TranslationCache` sekarang menulis ke DataStore di background
  (tidak memblokir fast path) sehingga cache frasa bertahan lintas restart aplikasi.
- **Conversation context buffer** (`conversation/ConversationContextStore.kt`): menyimpan N
  turn percakapan terakhir (dibatasi ketat sesuai setting `contextMessageLimit`), sebagai
  dasar untuk mode SMART di Phase 3. Tombol **Clear Conversation** sudah aktif di overlay.
- **Fix crash saat mulai bicara**: `SpeechRecognizer` sebelumnya dibuat di background thread
  (Dispatchers.Default, tanpa Looper) → crash. Sekarang sesi STT dijalankan di `Dispatchers.Main`.
- **Fix crash saat Start Translator**: foreground service sebelumnya mendeklarasikan tipe
  `mediaProjection` tanpa pernah meminta izin `MediaProjectionManager` → SecurityException di
  Android 14+. Sekarang service start dengan tipe `microphone` saja; System Audio dinonaktifkan
  sementara di UI sampai alur permintaan izinnya benar-benar dibangun.
- **Fix "tidak ada teks muncul" saat bicara**: `MicAudioSource` (untuk VAD) dan
  `android.speech.SpeechRecognizer` (untuk STT) sebelumnya sama-sama coba akses mic secara
  bersamaan — di banyak perangkat ini bikin SpeechRecognizer gagal dapat audio secara diam-diam
  (`onError` cuma `close()` tanpa pesan apa pun). Sekarang: VAD custom tidak dipakai lagi untuk
  gating mic; `TranslationPipeline` menjalankan sesi SpeechRecognizer berulang (auto-restart),
  dan `onError` sekarang membedakan error normal (hening/timeout, diam-diam restart) dari error
  yang perlu terlihat user (mic direbut app lain, izin dicabut, dll — muncul di overlay).
  `EnergyVadEngine`/`MicAudioSource` tetap ada di codebase untuk dipakai STT engine berbasis
  raw-PCM (Vosk/whisper.cpp) nanti yang bisa berbagi satu AudioRecord tap tanpa konflik.
- **Streaming/partial translation lebih halus** (`TranslationPipeline.schedulePartialTranslation`):
  sebelumnya, selagi user masih bicara, overlay cuma menampilkan teks sumber mentah (belum
  diterjemahkan) — terjemahan baru muncul setelah SpeechRecognizer menandai hasil sebagai final.
  Sekarang teks partial juga diterjemahkan secara live, di-debounce 400ms (dan diabaikan kalau
  < 2 karakter) supaya tidak memanggil translation engine di setiap perubahan huruf. Job partial
  ini dibatalkan begitu ada partial baru atau transcript final datang, dan kegagalannya diam-diam
  saja — hasil FINAL dari `handleFinalTranscript()` tetap satu-satunya sumber kebenaran, fast
  path tidak pernah menunggu proses ini. Overlay membedakan visualnya lewat warna teks yang
  sedikit diredupkan selama partial (`OverlayScreen.kt`).
- **Resize overlay via gesture** (`OverlayService.attachDragAndResizeHandling`): panel sekarang
  bisa diperlebar/dipersempit dengan menyeret kotak kecil di pojok kanan-bawah (ikon
  "resize" transparan), dibatasi 220–400dp dan dipersist ke DataStore (`overlay_width`) lintas
  restart. Drag-to-resize dan drag-to-move ditangani dalam SATU `View.OnTouchListener` yang sama
  (bukan `pointerInput` Compose terpisah di dalam handle) — kalau dipisah, `ACTION_MOVE` untuk
  resize bisa "kerebut" duluan oleh logika drag-to-move begitu melewati touch slop. Titik awal
  sentuhan dicek dulu terhadap area kotak resize (`RESIZE_HANDLE_DP`) sebelum menentukan mode
  (`PENDING_RESIZE` vs `PENDING_MOVE`) untuk sesi sentuh tersebut.

Groundwork Phase 3 yang sudah masuk (bukan final — lihat catatan kejujuran di bawah):

- **`ai/AIEngine.kt`**: kontrak AI Copilot dengan siklus idle→load→generate sesuai spesifikasi
  §6, dan `ai/PlaceholderCopilotEngine.kt` sebagai implementasi rule-based (⚠️ **bukan model AI
  sungguhan**, cuma balasan generik) untuk membuktikan pipeline-nya bekerja end-to-end.
- **AI Path terpisah dari Fast Path** (spesifikasi §11): di `TranslationPipeline`, suggested
  replies dihasilkan di coroutine terpisah SETELAH translation tampil — translation tidak
  pernah menunggu proses AI selesai.
- Mode **SMART** dan **COPILOT** sudah aktif di UI (tidak lagi disabled). COPILOT menampilkan
  Suggested Replies di overlay. SMART mencatat context percakapan, tapi translasinya **belum**
  benar-benar context-aware (ML Kit Translate adalah NMT biasa tanpa dukungan context injection
  — untuk itu betulan butuh model translation berbasis LLM, belum dikerjakan).

**Yang masih murni placeholder / belum real**, supaya jelas:
- Suggested replies COPILOT: rule-based, bukan hasil model AI.
- SMART mode: context tercatat, tapi belum memengaruhi kualitas terjemahan.
- System Audio: masih nonaktif, izin MediaProjection belum di-wire.
- Profiling RAM/CPU/baterai formal: belum ada — ini dijadwalkan Phase 4, bukan Phase 2.
- Opacity overlay: setting `overlay_opacity` sudah ada di `SettingsRepository` tapi belum ada
  UI slider-nya maupun belum diterapkan ke alpha panel — groundwork lama yang belum
  disambungkan, di luar scope perbaikan Phase 2 kali ini.

**Catatan kejujuran soal perubahan Phase 2 kali ini**: saya tidak bisa mengcompile atau
menjalankan project ini di sandbox saya (tanpa akses internet & Android SDK) — perubahan di atas
sudah saya cek manual (baca ulang tiap file, cek konsistensi tipe/signature antar kelas), tapi
**belum pernah benar-benar di-build atau dites di device**. Yang paling berisiko meleset kalau
ada masalah nanti: interaksi `View.OnTouchListener` untuk resize vs drag-to-move di
`OverlayService.attachDragAndResizeHandling()`, karena itu satu-satunya bagian yang bergantung
ketat pada urutan event sentuh Android yang perilakunya kadang beda-beda antar perangkat/skin
(MIUI, dsb). Kalau resize/drag terasa "nyangkut" atau kebalik di device asli, itu tempat pertama
yang perlu dicek.

## Keterbatasan penting yang perlu diketahui sebelum lanjut development

1. **`android.speech.SpeechRecognizer` tidak menerima PCM eksternal.** Ia mengelola capture
   mic-nya sendiri. Karena itu, saat ini STT hanya bisa mentranskripsi **microphone**, bukan
   system audio. `MicAudioSource` dipakai paralel murni untuk VAD (gating hemat baterai), bukan
   sebagai sumber audio bagi SpeechRecognizer. Lihat komentar detail di
   `stt/AndroidSpeechRecognizerEngine.kt`.
   Untuk mentranskripsi **system audio**, Phase 2/3 perlu STT engine yang menerima raw PCM
   langsung (mis. Vosk atau whisper.cpp via JNI) — interface `SpeechRecognizerEngine` sudah
   dirancang agar ini bisa ditukar tanpa mengubah `TranslationPipeline`.

2. **System audio capture tidak bisa menangkap audio panggilan VoIP** (WhatsApp/Telegram call)
   karena Android sengaja mengecualikan `USAGE_VOICE_COMMUNICATION` dari
   `AudioPlaybackCaptureConfiguration` demi privasi. Ini batasan platform, bukan bug. Untuk kasus
   itu, gunakan mode Microphone (tangkap dari speaker perangkat).

3. **Drag/resize/snap-to-edge pada overlay belum diimplementasikan** — placeholder ada di
   `OverlayService.showOverlayPanel()`. Ini eksplisit dijadwalkan sebagai bagian Phase 2 UX
   polish di spesifikasi.

4. **Gradle wrapper (`gradlew`) belum di-generate** karena lingkungan pembuatan project ini
   tidak punya akses internet untuk mengunduh `gradle-wrapper.jar`. Saat pertama kali dibuka di
   Android Studio, biarkan Android Studio men-generate wrapper-nya (atau jalankan
   `gradle wrapper --gradle-version 8.7` jika punya Gradle terpasang lokal).

5. **Model ML Kit (Translate & Language ID) butuh koneksi internet SEKALI di awal** untuk
   diunduh per pasangan bahasa (default lewat WiFi saja, lihat `DownloadConditions` di
   `MlKitTranslationEngine`). Setelah itu translation berjalan offline. Ini konsisten dengan
   spesifikasi "tetap dapat digunakan untuk translation dasar tanpa koneksi internet **jika
   model lokal tersedia**" — model harus terpasang dulu.

## Cara membuka project

1. Buka folder ini di Android Studio (Koala/2024.1+ direkomendasikan).
2. Biarkan Android Studio sync Gradle & generate wrapper.
3. Jalankan di perangkat fisik (emulator tidak bisa menguji overlay/system-audio dengan baik).
4. Saat pertama Start Translator, aplikasi akan meminta izin: RECORD_AUDIO, notifikasi
   (Android 13+), dan "Display over other apps" (SYSTEM_ALERT_WINDOW) — ketiganya wajib.

## Roadmap sesuai spesifikasi (§20)

- **Phase 1 (ini):** project, overlay, mic/system audio capture, VAD, STT, translation, auto
  language detection. ✅ selesai sebagai skeleton fungsional.
- **Phase 2:** streaming/partial translation yang lebih halus ✅, translation cache persist ✅,
  conversation context (dasar untuk mode SMART) ✅, drag/resize/snap overlay ✅, profiling awal
  (belum — digeser ke Phase 4, lihat catatan kejujuran di atas).
- **Phase 3:** mode SMART & COPILOT penuh, local small AI model (dengan sistem
  idle→unload/load-on-demand seperti di spesifikasi §6), suggested replies.
- **Phase 4:** RAM/CPU/battery profiling, deteksi memory leak, optimasi startup & latency.

## Prinsip yang dijaga di seluruh kode

- Tidak ada backend/VPS/database cloud/sistem login.
- Tidak ada API key yang di-hardcode di APK.
- Semua toggle (Mic, System Audio) benar-benar melepas resource saat OFF — bukan sekadar
  menyembunyikan UI.
- Fast path (audio → VAD → STT → translation → overlay) tidak pernah menunggu proses AI —
  ditegaskan lewat pemisahan `TranslationPipeline` (Phase 1) dari layer AI (Phase 3 nanti).
