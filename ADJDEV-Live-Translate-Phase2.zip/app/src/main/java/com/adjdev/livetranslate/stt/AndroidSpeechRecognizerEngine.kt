package com.adjdev.livetranslate.stt

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * CATATAN ARSITEKTUR PENTING (baca sebelum mengganti engine ini):
 *
 * android.speech.SpeechRecognizer TIDAK menerima stream PCM eksternal — ia mengelola
 * capture microphone-nya sendiri secara internal. Karena itu untuk mode MICROPHONE,
 * kelas ini memicu sesi listening-nya sendiri (bukan mengonsumsi AudioChunk dari
 * MicAudioSource), sementara MicAudioSource tetap dipakai secara paralel oleh VAD
 * untuk mendeteksi kapan harus start/stop sesi agar hemat CPU.
 *
 * Konsekuensi: engine ini TIDAK BISA dipakai untuk mentranskripsi SYSTEM AUDIO,
 * karena SpeechRecognizer hanya bisa membaca dari mic perangkat.
 *
 * Untuk transkripsi system audio (dan untuk STT yang benar-benar offline/on-device
 * secara eksplisit, bukan bergantung pada ketersediaan recognizer bawaan OEM),
 * ganti implementasi ini dengan engine berbasis model lokal yang menerima raw PCM
 * langsung dari AudioSource manapun (mis. Vosk atau whisper.cpp via JNI) — cukup
 * implementasikan interface SpeechRecognizerEngine yang menerima Flow<AudioChunk>
 * tanpa mengubah TranslationPipeline. Ini didaftarkan sebagai item Phase 2/3.
 *
 * isAvailable memeriksa dukungan on-device recognition (API 31+) agar sedapat mungkin
 * tidak bergantung pada koneksi internet, sesuai prinsip local-first.
 */
class AndroidSpeechRecognizerEngine(private val context: Context) : SpeechRecognizerEngine {

    override val isAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    private var recognizer: SpeechRecognizer? = null

    override fun startListening(languageTag: String?): Flow<TranscriptResult> = callbackFlow {
        if (!isAvailable) {
            close(IllegalStateException("Speech recognition unavailable."))
            return@callbackFlow
        }

        val sr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        ) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context)
        }
        recognizer = sr

        val listener = object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    trySend(TranscriptResult(text, isFinal = true, languageHint = languageTag))
                }
            }

            override fun onPartialResults(partialResults: Bundle) {
                val text = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    trySend(TranscriptResult(text, isFinal = false, languageHint = languageTag))
                }
            }

            override fun onError(error: Int) {
                // Error umum (mis. NO_MATCH, SPEECH_TIMEOUT) tidak fatal untuk sesi berikutnya;
                // biarkan pipeline yang memutuskan apakah perlu restart sesi.
                close()
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }

        sr.setRecognitionListener(listener)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            if (languageTag != null) putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
        }
        sr.startListening(intent)

        awaitClose {
            sr.stopListening()
            sr.destroy()
            recognizer = null
        }
    }

    override fun stopListening() {
        recognizer?.stopListening()
    }
}
