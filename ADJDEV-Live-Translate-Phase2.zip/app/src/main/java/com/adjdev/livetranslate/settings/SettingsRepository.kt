package com.adjdev.livetranslate.settings

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "adjdev_live_translate_settings")

enum class TranslationMode { LIGHT, SMART, COPILOT }

/**
 * Menyimpan pengaturan pengguna secara lokal saja (DataStore), TIDAK ada
 * database cloud dan TIDAK ada sistem login, sesuai spesifikasi.
 */
class SettingsRepository(private val context: Context) {

    private object Keys {
        val SOURCE_LANG = stringPreferencesKey("source_lang")
        val TARGET_LANG = stringPreferencesKey("target_lang")
        val AUTO_DETECT = booleanPreferencesKey("auto_detect")
        val MIC_ON = booleanPreferencesKey("mic_on")
        val SYSTEM_AUDIO_ON = booleanPreferencesKey("system_audio_on")
        val OPACITY = floatPreferencesKey("overlay_opacity")
        val FONT_SIZE = intPreferencesKey("overlay_font_size")
        val MODE = stringPreferencesKey("translation_mode")
        val CONTEXT_LIMIT = intPreferencesKey("context_message_limit")
        val DARK_MODE = booleanPreferencesKey("dark_mode")
    }

    val sourceLanguage: Flow<String> = context.dataStore.data.map { it[Keys.SOURCE_LANG] ?: "auto" }
    val targetLanguage: Flow<String> = context.dataStore.data.map { it[Keys.TARGET_LANG] ?: "id" }
    val autoDetect: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_DETECT] ?: true }
    val micOn: Flow<Boolean> = context.dataStore.data.map { it[Keys.MIC_ON] ?: true }
    val systemAudioOn: Flow<Boolean> = context.dataStore.data.map { it[Keys.SYSTEM_AUDIO_ON] ?: false }
    val overlayOpacity: Flow<Float> = context.dataStore.data.map { it[Keys.OPACITY] ?: 0.92f }
    val overlayFontSize: Flow<Int> = context.dataStore.data.map { it[Keys.FONT_SIZE] ?: 14 }
    val translationMode: Flow<TranslationMode> = context.dataStore.data.map {
        runCatching { TranslationMode.valueOf(it[Keys.MODE] ?: "LIGHT") }.getOrDefault(TranslationMode.LIGHT)
    }
    // Batas pesan context untuk mode SMART/COPILOT, agar RAM tidak membengkak (spesifikasi #4).
    val contextMessageLimit: Flow<Int> = context.dataStore.data.map { it[Keys.CONTEXT_LIMIT] ?: 12 }
    val darkMode: Flow<Boolean> = context.dataStore.data.map { it[Keys.DARK_MODE] ?: true }

    suspend fun setSourceLanguage(tag: String) = context.dataStore.edit { it[Keys.SOURCE_LANG] = tag }
    suspend fun setTargetLanguage(tag: String) = context.dataStore.edit { it[Keys.TARGET_LANG] = tag }
    suspend fun setAutoDetect(value: Boolean) = context.dataStore.edit { it[Keys.AUTO_DETECT] = value }
    suspend fun setMicOn(value: Boolean) = context.dataStore.edit { it[Keys.MIC_ON] = value }
    suspend fun setSystemAudioOn(value: Boolean) = context.dataStore.edit { it[Keys.SYSTEM_AUDIO_ON] = value }
    suspend fun setOverlayOpacity(value: Float) = context.dataStore.edit { it[Keys.OPACITY] = value }
    suspend fun setOverlayFontSize(value: Int) = context.dataStore.edit { it[Keys.FONT_SIZE] = value }
    suspend fun setTranslationMode(mode: TranslationMode) = context.dataStore.edit { it[Keys.MODE] = mode.name }
    suspend fun setContextMessageLimit(value: Int) = context.dataStore.edit { it[Keys.CONTEXT_LIMIT] = value }
    suspend fun setDarkMode(value: Boolean) = context.dataStore.edit { it[Keys.DARK_MODE] = value }
}
