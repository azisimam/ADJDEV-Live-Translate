package com.adjdev.livetranslate.core

import com.adjdev.livetranslate.audio.AudioSource
import com.adjdev.livetranslate.conversation.ConversationContextStore
import com.adjdev.livetranslate.conversation.ConversationTurn
import com.adjdev.livetranslate.detection.LanguageDetector
import com.adjdev.livetranslate.stt.SpeechRecognizerEngine
import com.adjdev.livetranslate.storage.TranslationCache
import com.adjdev.livetranslate.translation.TranslationEngine
import com.adjdev.livetranslate.translation.TranslationOutcome
import com.adjdev.livetranslate.vad.EnergyVadEngine
import com.adjdev.livetranslate.vad.VoiceActivityDetector
import com.adjdev.livetranslate.vad.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Menghubungkan: AudioSource -> VAD (gating) -> STT -> Deteksi bahasa -> Cache/Translation -> state.
 *
 * FAST PATH murni (spesifikasi #11): tidak ada langkah AI/Copilot di kelas ini sama sekali.
 * Mode SMART/COPILOT (context, suggestions) dibangun sebagai layer terpisah di atas
 * hasil finalTranscript yang di-emit dari sini (Phase 3), agar jalur realtime translation
 * TIDAK PERNAH menunggu proses AI.
 *
 * VAD di sini berfungsi sebagai GATE untuk menghemat CPU: SpeechRecognizerEngine hanya
 * dijalankan ketika ada suara terdeteksi pada AudioSource yang aktif. Lihat catatan di
 * AndroidSpeechRecognizerEngine mengenai keterbatasan STT bawaan Android untuk system audio.
 */
class TranslationPipeline(
    private val micSource: AudioSource,
    private val sttEngine: SpeechRecognizerEngine,
    private val languageDetector: LanguageDetector,
    private val translationEngine: TranslationEngine,
    private val cache: TranslationCache,
    private val vad: VoiceActivityDetector = EnergyVadEngine(),
    val conversationContext: ConversationContextStore = ConversationContextStore()
) {
    private val scope = CoroutineScope(SupervisorJob())
    private var vadJob: Job? = null
    private var sttJob: Job? = null

    private val _state = MutableStateFlow(TranslatorState())
    val state: StateFlow<TranslatorState> = _state.asStateFlow()

    private var targetLanguageTag: String = "id"
    private var autoDetect: Boolean = true
    private var fixedSourceLanguageTag: String? = null

    fun configure(targetLanguageTag: String, autoDetect: Boolean, sourceLanguageTag: String?) {
        this.targetLanguageTag = targetLanguageTag
        this.autoDetect = autoDetect
        this.fixedSourceLanguageTag = sourceLanguageTag
    }

    /** Mulai pipeline mic: VAD memantau energi audio, STT hanya aktif saat ada suara. */
    fun startMic() {
        if (vadJob?.isActive == true) return
        vad.reset()
        _state.value = _state.value.copy(isRunning = true, micOn = true, errorMessage = null)

        vadJob = scope.launch {
            try {
                micSource.start().collect { chunk ->
                    val voiceState = vad.evaluate(chunk)
                    if (voiceState == VoiceState.SPEECH && sttJob?.isActive != true) {
                        startSttSession()
                    }
                    // Saat SILENCE, sesi STT yang sedang berjalan dibiarkan menyelesaikan
                    // dirinya sendiri lewat onEndOfSpeech/onError bawaan SpeechRecognizer.
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(errorMessage = e.message ?: "Speech recognition unavailable.")
            }
        }
    }

    private fun startSttSession() {
        sttJob = scope.launch {
            val langTag = fixedSourceLanguageTag
            sttEngine.startListening(langTag).collect { result ->
                if (result.isFinal) {
                    handleFinalTranscript(result.text)
                } else {
                    _state.value = _state.value.copy(partialSourceText = result.text)
                }
            }
        }
    }

    private suspend fun handleFinalTranscript(text: String) {
        if (text.isBlank()) return

        val sourceLang = if (autoDetect) {
            languageDetector.detect(text) ?: "en"
        } else {
            fixedSourceLanguageTag ?: "en"
        }

        val cached = cache.get(sourceLang, targetLanguageTag, text)
        if (cached != null) {
            emitTranslated(text, cached, sourceLang)
            return
        }

        when (val outcome = translationEngine.translate(text, sourceLang, targetLanguageTag)) {
            is TranslationOutcome.Success -> {
                cache.put(sourceLang, targetLanguageTag, text, outcome.translatedText)
                emitTranslated(text, outcome.translatedText, sourceLang)
            }
            is TranslationOutcome.Failure -> {
                _state.value = _state.value.copy(errorMessage = outcome.message)
            }
        }
    }

    private fun emitTranslated(source: String, translated: String, detectedLang: String) {
        // Dicatat sebagai groundwork mode SMART (Phase 3); fast path di atas tidak menunggu ini.
        conversationContext.addTurn(ConversationTurn(source, translated, detectedLang))
        _state.value = _state.value.copy(
            partialSourceText = "",
            lastSourceText = source,
            lastTranslatedText = translated,
            detectedLanguage = detectedLang,
            errorMessage = null
        )
    }

    /** Dipanggil dari tombol "Clear Conversation" di overlay/settings (spesifikasi §4/§15). */
    fun clearConversation() = conversationContext.clear()

    fun setContextLimit(maxTurns: Int) = conversationContext.setMaxTurns(maxTurns)

    fun stopMic() {
        vadJob?.cancel()
        sttJob?.cancel()
        sttEngine.stopListening()
        micSource.stop()
        _state.value = _state.value.copy(micOn = false, partialSourceText = "")
    }

    /** Hentikan seluruh pipeline & lepaskan semua resource (dipanggil saat translator OFF). */
    fun stopAll() {
        stopMic()
        translationEngine.release()
        _state.value = TranslatorState()
        scope.cancel()
    }
}
