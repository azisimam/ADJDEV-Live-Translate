package com.adjdev.livetranslate

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.livetranslate.settings.SettingsRepository
import com.adjdev.livetranslate.settings.TranslationMode
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val settings = SettingsRepository(application.applicationContext)

    fun setMicOn(value: Boolean) = viewModelScope.launch { settings.setMicOn(value) }
    fun setSystemAudioOn(value: Boolean) = viewModelScope.launch { settings.setSystemAudioOn(value) }
    fun setAutoDetect(value: Boolean) = viewModelScope.launch { settings.setAutoDetect(value) }
    fun setTargetLanguage(tag: String) = viewModelScope.launch { settings.setTargetLanguage(tag) }
    fun setSourceLanguage(tag: String) = viewModelScope.launch { settings.setSourceLanguage(tag) }
    fun setMode(mode: TranslationMode) = viewModelScope.launch { settings.setTranslationMode(mode) }
}
