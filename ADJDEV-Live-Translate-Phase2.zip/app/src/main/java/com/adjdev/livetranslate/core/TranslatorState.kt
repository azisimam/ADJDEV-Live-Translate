package com.adjdev.livetranslate.core

/** Status pipeline realtime, dikonsumsi oleh overlay & UI utama. */
data class TranslatorState(
    val isRunning: Boolean = false,
    val micOn: Boolean = false,
    val systemAudioOn: Boolean = false,
    val partialSourceText: String = "",
    val lastSourceText: String = "",
    val lastTranslatedText: String = "",
    val detectedLanguage: String? = null,
    val errorMessage: String? = null
)
