# ADJDEV Live Translate - proguard rules
# ML Kit menggunakan reflection untuk beberapa komponen; tambahkan keep rules di sini
# jika ditemukan crash setelah minify pada build release.
