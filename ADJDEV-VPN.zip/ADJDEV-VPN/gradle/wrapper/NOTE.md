# Tentang gradle-wrapper.jar

File `gradle-wrapper.jar` adalah file **binary** yang secara normal dibuat oleh
perintah `gradle wrapper`. Karena file ini dihasilkan dari environment yang
menjalankan Gradle secara nyata, file tersebut **tidak disertakan sebagai
teks** di sini.

Workflow GitHub Actions (`.github/workflows/build.yml`) sudah menangani ini
secara otomatis: langkah **"Provision Gradle Wrapper"** akan menginstall
Gradle sesuai versi di `gradle-wrapper.properties`, lalu menjalankan
`gradle wrapper` untuk menghasilkan `gradle-wrapper.jar` sebelum build APK
dijalankan. Anda tidak perlu melakukan apa pun secara manual di GitHub.

Jika Anda ingin build di komputer lokal (opsional, tidak wajib karena build
utama dilakukan lewat GitHub Actions), jalankan sekali saja setelah meng-
install Gradle (https://gradle.org/install/):

```
gradle wrapper --gradle-version 8.9 --distribution-type bin
```

Perintah ini akan membuat `gradle-wrapper.jar` di folder ini secara otomatis.
