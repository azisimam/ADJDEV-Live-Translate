# WireGuard tunnel library uses JNI - keep its classes intact.
-keep class com.wireguard.** { *; }
-dontwarn com.wireguard.**

# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class **$$serializer {
    *** INSTANCE;
}

# Keep data/model classes used for serialization
-keep class com.adjdev.vpn.data.model.** { *; }
