import java.util.Properties
import java.io.FileInputStream

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
}

// ---------------------------------------------------------------------------
// Konfigurasi endpoint API & environment TANPA mengubah source code.
// Nilai diambil berurutan dari:
//   1. Environment variable (misalnya di GitHub Actions Secrets/Variables)
//   2. File lokal `app/config.properties` (tidak di-commit, lihat .gitignore)
//   3. Nilai default (untuk keperluan development)
// ---------------------------------------------------------------------------
val configProps = Properties().apply {
    val configFile = rootProject.file("app/config.properties")
    if (configFile.exists()) {
        load(FileInputStream(configFile))
    }
}

fun resolveConfig(envKey: String, propKey: String, default: String): String {
    return System.getenv(envKey) ?: configProps.getProperty(propKey) ?: default
}

val apiBaseUrl = resolveConfig(
    "ADJDEV_API_BASE_URL",
    "API_BASE_URL",
    "https://api.adjdev.example.com/"
)

val wgServerPublicKey = resolveConfig(
    "ADJDEV_WG_SERVER_PUBLIC_KEY",
    "WG_SERVER_PUBLIC_KEY",
    "RB271L8TjjyyXdnZRu334PsRSWfN5NqxMBPieStRVGk="
)

val wgServerEndpoint = resolveConfig(
    "ADJDEV_WG_SERVER_ENDPOINT",
    "WG_SERVER_ENDPOINT",
    "148.230.96.102:51820"
)

val wgVpnSubnet = resolveConfig(
    "ADJDEV_WG_VPN_SUBNET",
    "WG_VPN_SUBNET",
    "10.8.0.0/24"
)

android {
    namespace = "com.adjdev.vpn"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.adjdev.vpn"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Nilai-nilai ini di-inject ke BuildConfig, TIDAK di-hardcode di source.
        // Private key server TIDAK PERNAH ada di sini.
        buildConfigField("String", "API_BASE_URL", "\"$apiBaseUrl\"")
        buildConfigField("String", "WG_SERVER_PUBLIC_KEY", "\"$wgServerPublicKey\"")
        buildConfigField("String", "WG_SERVER_ENDPOINT", "\"$wgServerEndpoint\"")
        buildConfigField("String", "WG_VPN_SUBNET", "\"$wgVpnSubnet\"")
    }

    signingConfigs {
        // Debug signing bawaan Android sudah cukup untuk artifact "app-debug.apk"
        // yang dihasilkan GitHub Actions. Untuk rilis produksi, tambahkan
        // signingConfig release terpisah dengan keystore yang disimpan sebagai
        // GitHub Secrets, jangan pernah di-commit ke repository.
        getByName("debug") {
            // menggunakan debug keystore default Android
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
            isDebuggable = true
            applicationIdSuffix = ".debug"
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.ktx)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.security.crypto)
    implementation(libs.androidx.datastore.preferences)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons.extended)
    debugImplementation(libs.compose.ui.tooling)

    // WireGuard - implementasi tunnel NYATA (bukan simulasi), resmi dari
    // proyek WireGuard, dipakai juga oleh aplikasi WireGuard official di Play Store.
    implementation(libs.wireguard.tunnel)

    // Networking - untuk integrasi REST API backend (auth, device registration, dsb.)
    implementation(libs.retrofit.core)
    implementation(libs.retrofit.kotlinx.serialization)
    implementation(libs.okhttp.core)
    implementation(libs.okhttp.logging.interceptor)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)
}
