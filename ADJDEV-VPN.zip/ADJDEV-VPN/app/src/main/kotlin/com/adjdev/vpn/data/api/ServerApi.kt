package com.adjdev.vpn.data.api

import com.adjdev.vpn.data.model.ServerInfo
import com.adjdev.vpn.data.model.ServerStatus
import retrofit2.http.GET
import retrofit2.http.Path

interface ServerApi {
    @GET("v1/servers")
    suspend fun listServers(): List<ServerInfo>

    @GET("v1/servers/{serverId}/status")
    suspend fun serverStatus(@Path("serverId") serverId: String): ServerStatus
}
