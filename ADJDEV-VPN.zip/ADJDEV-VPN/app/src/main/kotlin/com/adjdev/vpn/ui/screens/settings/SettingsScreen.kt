package com.adjdev.vpn.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.adjdev.vpn.BuildConfig

@Composable
fun SettingsScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge)
        androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Konfigurasi Backend", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                androidx.compose.foundation.layout.Spacer(Modifier.padding(4.dp))
                Text("API Base URL: ${BuildConfig.API_BASE_URL}", style = MaterialTheme.typography.labelLarge)
                Text("Default Endpoint: ${BuildConfig.WG_SERVER_ENDPOINT}", style = MaterialTheme.typography.labelLarge)
                Text("VPN Subnet: ${BuildConfig.WG_VPN_SUBNET}", style = MaterialTheme.typography.labelLarge)
                androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))
                Text(
                    "Nilai di atas diatur lewat app/config.properties atau environment " +
                        "variable saat build (lihat README), tanpa mengubah source code.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelLarge
                )
            }
        }
    }
}
