package com.adjdev.vpn.data.model

import kotlinx.serialization.Serializable

@Serializable
data class LoginRequest(val email: String, val password: String)

@Serializable
data class RegisterRequest(val email: String, val password: String, val displayName: String)

@Serializable
data class AuthResponse(
    val accessToken: String,
    val refreshToken: String,
    val userId: String
)

/**
 * Dikirim saat mendaftarkan perangkat. [publicKey] adalah kunci publik
 * WireGuard yang di-generate SECARA LOKAL di perangkat (lihat
 * [com.adjdev.vpn.vpn.WireGuardManager.ensureLocalKeyPair]). Private key
 * TIDAK PERNAH dikirim ke server maupun disimpan di server.
 */
@Serializable
data class DeviceRegisterRequest(
    val deviceName: String,
    val platform: String = "android",
    val publicKey: String
)

@Serializable
data class DeviceRegisterResponse(
    val deviceId: String,
    val publicKey: String
)

/**
 * Respons "generate peer" dari backend: server membuat entri peer baru
 * menggunakan public key yang dikirim device, lalu mengembalikan alamat
 * tunnel yang dialokasikan untuk device tsb (mis. 10.8.0.2/32) beserta
 * info server. Server PRIVATE key tidak pernah ada dalam respons ini.
 */
@Serializable
data class PeerConfigResponse(
    val deviceId: String,
    val assignedAddress: String,       // contoh: "10.8.0.2/32"
    val dns: List<String> = listOf("1.1.1.1"),
    val serverPublicKey: String,
    val endpointHost: String,
    val endpointPort: Int,
    val allowedIps: List<String> = listOf("0.0.0.0/0"),
    val persistentKeepalive: Int = 25
)
