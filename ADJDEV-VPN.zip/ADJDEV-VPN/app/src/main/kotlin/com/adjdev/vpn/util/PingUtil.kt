package com.adjdev.vpn.util

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Mengukur latency nyata ke host (bukan angka acak/fake). Android tidak
 * mengizinkan raw ICMP socket tanpa root, sehingga pendekatan yang dipakai:
 *  1. Coba InetAddress.isReachable() (ICMP jika diizinkan sistem, atau
 *     fallback TCP echo port 7 di banyak perangkat).
 *  2. Jika gagal/timeout, ukur waktu TCP handshake ke port endpoint
 *     WireGuard sebagai indikator latency jaringan ke server tsb.
 */
object PingUtil {
    suspend fun measurePingMs(host: String, tcpFallbackPort: Int, timeoutMs: Int = 2000): Long? =
        withContext(Dispatchers.IO) {
            runCatching {
                val address = InetAddress.getByName(host)
                val start = System.currentTimeMillis()
                if (address.isReachable(timeoutMs)) {
                    return@withContext System.currentTimeMillis() - start
                }
                measureTcpHandshake(host, tcpFallbackPort, timeoutMs)
            }.getOrNull() ?: measureTcpHandshake(host, tcpFallbackPort, timeoutMs)
        }

    private fun measureTcpHandshake(host: String, port: Int, timeoutMs: Int): Long? =
        runCatching {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            System.currentTimeMillis() - start
        }.getOrNull()
}
