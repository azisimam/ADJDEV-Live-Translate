package com.adjdev.vpn.vpn

import com.wireguard.android.backend.Tunnel

/**
 * Implementasi [Tunnel] dari library resmi com.wireguard.android:tunnel.
 * [onStateChange] dipanggil oleh GoBackend saat state tunnel BENAR-BENAR
 * berubah di level sistem (bukan simulasi), sehingga kelas ini menjadi
 * jembatan antara backend WireGuard native dan state UI aplikasi.
 */
class AdjdevTunnel(
    private val tunnelName: String,
    private val onStateChanged: (Tunnel.State) -> Unit
) : Tunnel {
    override fun getName(): String = tunnelName

    override fun onStateChange(newState: Tunnel.State) {
        onStateChanged(newState)
    }
}
