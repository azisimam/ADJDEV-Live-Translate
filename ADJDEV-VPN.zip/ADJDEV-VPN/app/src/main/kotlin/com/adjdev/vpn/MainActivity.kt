package com.adjdev.vpn

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.adjdev.vpn.ui.VpnViewModel
import com.adjdev.vpn.ui.navigation.AdjdevBottomBar
import com.adjdev.vpn.ui.navigation.AdjdevDestination
import com.adjdev.vpn.ui.screens.about.AboutScreen
import com.adjdev.vpn.ui.screens.details.ConnectionDetailsScreen
import com.adjdev.vpn.ui.screens.home.HomeScreen
import com.adjdev.vpn.ui.screens.servers.ServersScreen
import com.adjdev.vpn.ui.screens.settings.SettingsScreen
import com.adjdev.vpn.ui.theme.AdjdevVpnTheme

class MainActivity : ComponentActivity() {

    private val viewModel: VpnViewModel by viewModels()

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            viewModel.onVpnPermissionGranted()
        } else {
            viewModel.onVpnPermissionDenied()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AdjdevVpnTheme {
                val permissionIntent by viewModel.permissionRequest.collectAsState()
                LaunchedEffect(permissionIntent) {
                    permissionIntent?.let { vpnPermissionLauncher.launch(it) }
                }
                AdjdevVpnApp(viewModel)
            }
        }
    }
}

@Composable
fun AdjdevVpnApp(viewModel: VpnViewModel) {
    val navController: NavHostController = rememberNavController()

    Scaffold(
        bottomBar = { AdjdevBottomBar(navController) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AdjdevDestination.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(AdjdevDestination.Home.route) {
                HomeScreen(viewModel = viewModel)
            }
            composable(AdjdevDestination.Servers.route) {
                ServersScreen(viewModel = viewModel)
            }
            composable(AdjdevDestination.Details.route) {
                ConnectionDetailsScreen(viewModel = viewModel)
            }
            composable(AdjdevDestination.Settings.route) {
                SettingsScreen()
            }
            composable(AdjdevDestination.About.route) {
                AboutScreen()
            }
        }
    }
}
