package com.adjdev.vpn.ui.screens.about

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.adjdev.vpn.BuildConfig

@Composable
fun AboutScreen() {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("About", style = MaterialTheme.typography.titleLarge)
        androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))
        Text("ADJDEV VPN")
        Text("Versi: ${BuildConfig.VERSION_NAME}")
        androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))
        Text(
            "Dibangun dengan Kotlin, Jetpack Compose, Material 3, dan " +
                "implementasi WireGuard resmi (com.wireguard.android:tunnel) " +
                "untuk membuat tunnel VPN nyata di Android."
        )
    }
}
