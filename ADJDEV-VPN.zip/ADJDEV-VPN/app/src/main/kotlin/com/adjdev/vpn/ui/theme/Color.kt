package com.adjdev.vpn.ui.theme

import androidx.compose.ui.graphics.Color

val AdjdevBlue = Color(0xFF2F6FED)
val AdjdevBlueDark = Color(0xFF1B4FC4)
val AdjdevGreen = Color(0xFF2ECC71)
val AdjdevYellow = Color(0xFFF1C40F)
val AdjdevRed = Color(0xFFE74C3C)
val AdjdevGray = Color(0xFFBDC3C7)

val SurfaceLight = Color(0xFFF7F9FC)
val SurfaceDark = Color(0xFF10131A)
