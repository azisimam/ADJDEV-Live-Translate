package com.adjdev.vpn.data.api

import com.adjdev.vpn.data.model.AuthResponse
import com.adjdev.vpn.data.model.LoginRequest
import com.adjdev.vpn.data.model.RegisterRequest
import retrofit2.http.Body
import retrofit2.http.POST

interface AuthApi {
    @POST("v1/auth/login")
    suspend fun login(@Body request: LoginRequest): AuthResponse

    @POST("v1/auth/register")
    suspend fun register(@Body request: RegisterRequest): AuthResponse
}
