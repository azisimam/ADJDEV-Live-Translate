package com.adjdev.vpn.data.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Penyimpanan aman berbasis Android Keystore (via Jetpack Security /
 * EncryptedSharedPreferences) untuk:
 *  - access token & refresh token hasil login
 *  - deviceId hasil registrasi
 *  - private key WireGuard yang DI-GENERATE LOKAL di perangkat ini
 *  - konfigurasi peer terakhir (assigned address, dsb.)
 *
 * PENTING: private key WireGuard SERVER tidak pernah melewati kelas ini
 * ataupun aplikasi ini sama sekali. Yang disimpan di sini hanyalah
 * keypair milik CLIENT (perangkat ini sendiri), yang wajar untuk
 * disimpan secara lokal agar tunnel bisa dibuat.
 *
 * Kelas ini juga tidak pernah melakukan logging terhadap nilai apa pun
 * yang disimpan/dibaca di sini.
 */
class SecureStore(context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "adjdev_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveAuthTokens(accessToken: String, refreshToken: String) {
        prefs.edit()
            .putString(KEY_ACCESS_TOKEN, accessToken)
            .putString(KEY_REFRESH_TOKEN, refreshToken)
            .apply()
    }

    fun getAccessToken(): String? = prefs.getString(KEY_ACCESS_TOKEN, null)
    fun getRefreshToken(): String? = prefs.getString(KEY_REFRESH_TOKEN, null)

    fun clearAuthTokens() {
        prefs.edit()
            .remove(KEY_ACCESS_TOKEN)
            .remove(KEY_REFRESH_TOKEN)
            .apply()
    }

    fun saveDeviceId(deviceId: String) {
        prefs.edit().putString(KEY_DEVICE_ID, deviceId).apply()
    }

    fun getDeviceId(): String? = prefs.getString(KEY_DEVICE_ID, null)

    fun saveClientKeyPair(privateKeyBase64: String, publicKeyBase64: String) {
        prefs.edit()
            .putString(KEY_CLIENT_PRIVATE_KEY, privateKeyBase64)
            .putString(KEY_CLIENT_PUBLIC_KEY, publicKeyBase64)
            .apply()
    }

    fun getClientPrivateKey(): String? = prefs.getString(KEY_CLIENT_PRIVATE_KEY, null)
    fun getClientPublicKey(): String? = prefs.getString(KEY_CLIENT_PUBLIC_KEY, null)

    fun savePeerConfigJson(json: String) {
        prefs.edit().putString(KEY_PEER_CONFIG_JSON, json).apply()
    }

    fun getPeerConfigJson(): String? = prefs.getString(KEY_PEER_CONFIG_JSON, null)

    fun clearAll() {
        prefs.edit().clear().apply()
    }

    companion object {
        private const val KEY_ACCESS_TOKEN = "access_token"
        private const val KEY_REFRESH_TOKEN = "refresh_token"
        private const val KEY_DEVICE_ID = "device_id"
        private const val KEY_CLIENT_PRIVATE_KEY = "client_private_key"
        private const val KEY_CLIENT_PUBLIC_KEY = "client_public_key"
        private const val KEY_PEER_CONFIG_JSON = "peer_config_json"
    }
}
