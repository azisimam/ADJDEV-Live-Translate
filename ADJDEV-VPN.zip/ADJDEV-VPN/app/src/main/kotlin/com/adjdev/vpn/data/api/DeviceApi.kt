package com.adjdev.vpn.data.api

import com.adjdev.vpn.data.model.DeviceRegisterRequest
import com.adjdev.vpn.data.model.DeviceRegisterResponse
import com.adjdev.vpn.data.model.PeerConfigResponse
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface DeviceApi {

    @POST("v1/devices/register")
    suspend fun registerDevice(@Body request: DeviceRegisterRequest): DeviceRegisterResponse

    /**
     * Meminta backend membuat/menerbitkan peer WireGuard baru untuk device ini.
     * Setiap device akan mendapat alamat tunnel unik, contoh:
     *   device A -> 10.8.0.2
     *   device B -> 10.8.0.3
     */
    @POST("v1/devices/{deviceId}/peer")
    suspend fun generatePeer(@Path("deviceId") deviceId: String): PeerConfigResponse

    @GET("v1/devices/{deviceId}/peer")
    suspend fun getPeerConfig(@Path("deviceId") deviceId: String): PeerConfigResponse

    @DELETE("v1/devices/{deviceId}")
    suspend fun revokeDevice(@Path("deviceId") deviceId: String)
}
