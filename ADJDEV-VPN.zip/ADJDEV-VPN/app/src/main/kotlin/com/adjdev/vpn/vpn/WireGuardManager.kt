package com.adjdev.vpn.vpn

import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.adjdev.vpn.data.model.PeerConfigResponse
import com.adjdev.vpn.data.security.SecureStore
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.InetEndpoint
import com.wireguard.config.InetNetwork
import com.wireguard.config.Interface
import com.wireguard.config.Peer
import com.wireguard.crypto.Key
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress

/**
 * Mengelola tunnel WireGuard SUNGGUHAN lewat library resmi
 * `com.wireguard.android:tunnel` (GoBackend, userspace WireGuard-go yang
 * dijembatani ke android.net.VpnService). Tidak ada simulasi di sini:
 * connect/disconnect benar-benar membuat & mematikan interface VPN di
 * level sistem Android, dan statistik RX/TX diambil langsung dari
 * backend WireGuard.
 */
class WireGuardManager(private val context: Context) {

    private val secureStore = SecureStore(context)
    private val backend: Backend = GoBackend(context)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var statsJob: Job? = null

    private val tunnel = AdjdevTunnel(TUNNEL_NAME) { newState ->
        scope.launch { handleBackendStateChange(newState) }
    }

    private val _connectionState = MutableStateFlow<VpnConnectionState>(VpnConnectionState.Disconnected)
    val connectionState: StateFlow<VpnConnectionState> = _connectionState.asStateFlow()

    private val _stats = MutableStateFlow<TunnelStats?>(null)
    val stats: StateFlow<TunnelStats?> = _stats.asStateFlow()

    /** Mengembalikan Intent izin VPN jika perlu diminta, atau null jika sudah diizinkan. */
    fun permissionIntentOrNull(): Intent? = VpnService.prepare(context)

    /**
     * Pastikan device punya keypair WireGuard lokal. Private key TIDAK PERNAH
     * dikirim ke server maupun ke mana pun - hanya disimpan terenkripsi di
     * perangkat ini (lihat [SecureStore]). Yang dikirim ke backend hanyalah
     * public key saat registrasi device.
     */
    fun ensureLocalKeyPair(): KeyPair {
        val storedPrivate = secureStore.getClientPrivateKey()
        if (storedPrivate != null) {
            return KeyPair(Key.fromBase64(storedPrivate))
        }
        val newKeyPair = KeyPair()
        secureStore.saveClientKeyPair(
            privateKeyBase64 = newKeyPair.privateKey.toBase64(),
            publicKeyBase64 = newKeyPair.publicKey.toBase64()
        )
        return newKeyPair
    }

    fun localPublicKeyBase64(): String = ensureLocalKeyPair().publicKey.toBase64()

    private fun buildConfig(peer: PeerConfigResponse): Config {
        val keyPair = ensureLocalKeyPair()

        val ifaceBuilder = Interface.Builder()
            .setKeyPair(keyPair)
            .addAddress(InetNetwork.parse(peer.assignedAddress))
        peer.dns.forEach { dns ->
            ifaceBuilder.addDnsServer(InetAddress.getByName(dns))
        }

        val peerBuilder = Peer.Builder()
            .setPublicKey(Key.fromBase64(peer.serverPublicKey))
            .setEndpoint(InetEndpoint.parse("${peer.endpointHost}:${peer.endpointPort}"))
            .setPersistentKeepalive(peer.persistentKeepalive)
        peer.allowedIps.forEach { cidr ->
            peerBuilder.addAllowedIp(InetNetwork.parse(cidr))
        }

        return Config.Builder()
            .setInterface(ifaceBuilder.build())
            .addPeer(peerBuilder.build())
            .build()
    }

    /**
     * Menghubungkan tunnel menggunakan [peerConfig] (hasil dari backend REST,
     * lihat SessionRepository.generatePeer/refreshPeerConfig). Melempar
     * exception yang jelas jika gagal - tidak ada fallback ke state "sukses"
     * palsu.
     */
    suspend fun connect(peerConfig: PeerConfigResponse) {
        if (permissionIntentOrNull() != null) {
            throw VpnPermissionRequiredException()
        }
        _connectionState.value = VpnConnectionState.Connecting
        try {
            val config = buildConfig(peerConfig)
            withContext(Dispatchers.IO) {
                backend.setState(tunnel, Tunnel.State.UP, config)
            }
        } catch (e: Exception) {
            _connectionState.value = VpnConnectionState.Error(e.message ?: "Gagal membuat tunnel WireGuard")
            throw e
        }
    }

    suspend fun disconnect() {
        _connectionState.value = VpnConnectionState.Disconnecting
        try {
            withContext(Dispatchers.IO) {
                backend.setState(tunnel, Tunnel.State.DOWN, null)
            }
        } catch (e: Exception) {
            _connectionState.value = VpnConnectionState.Error(e.message ?: "Gagal memutuskan tunnel WireGuard")
            throw e
        }
    }

    suspend fun reconnect(peerConfig: PeerConfigResponse) {
        if (currentBackendState() == Tunnel.State.UP) {
            disconnect()
        }
        connect(peerConfig)
    }

    fun currentBackendState(): Tunnel.State = try {
        backend.getState(tunnel)
    } catch (e: Exception) {
        Tunnel.State.DOWN
    }

    private fun handleBackendStateChange(newState: Tunnel.State) {
        when (newState) {
            Tunnel.State.UP -> {
                _connectionState.value = VpnConnectionState.Connected(System.currentTimeMillis())
                startStatsPolling()
            }
            Tunnel.State.DOWN -> {
                _connectionState.value = VpnConnectionState.Disconnected
                _stats.value = null
                stopStatsPolling()
            }
            else -> Unit
        }
    }

    private fun startStatsPolling() {
        stopStatsPolling()
        statsJob = scope.launch {
            while (true) {
                try {
                    val statistics = withContext(Dispatchers.IO) { backend.getStatistics(tunnel) }
                    _stats.value = TunnelStats(
                        rxBytes = statistics.totalRx(),
                        txBytes = statistics.totalTx()
                    )
                } catch (_: Exception) {
                    // Backend mungkin sedang bertransisi state; abaikan satu siklus polling.
                }
                delay(1000)
            }
        }
    }

    private fun stopStatsPolling() {
        statsJob?.cancel()
        statsJob = null
    }

    companion object {
        private const val TUNNEL_NAME = "adjdev0"
    }
}

/** Dilempar saat izin VpnService.prepare() belum diberikan oleh user. */
class VpnPermissionRequiredException : Exception("Izin VPN belum diberikan oleh pengguna")
