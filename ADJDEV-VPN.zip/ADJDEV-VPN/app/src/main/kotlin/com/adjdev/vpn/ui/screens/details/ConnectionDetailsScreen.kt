package com.adjdev.vpn.ui.screens.details

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.adjdev.vpn.ui.VpnViewModel
import com.adjdev.vpn.vpn.VpnConnectionState

@Composable
fun ConnectionDetailsScreen(viewModel: VpnViewModel) {
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Connection Details", style = MaterialTheme.typography.titleLarge)
        androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                DetailRow("Status", statusLabel(state.connectionState))
                DetailRow("Tunnel Interface", "adjdev0 (WireGuard)")
                DetailRow("Server", state.selectedServer?.name ?: "-")
                DetailRow("Endpoint", state.selectedServer?.let { "${it.endpointHost}:${it.endpointPort}" } ?: "-")
                DetailRow("Protocol", "UDP (WireGuard)")
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                DetailRow("Assigned Address", state.assignedAddress ?: "-")
                DetailRow("Ping", state.pingMs?.let { "$it ms" } ?: "-")
                DetailRow("RX (Download)", "${state.stats?.rxBytes ?: 0} bytes")
                DetailRow("TX (Upload)", "${state.stats?.txBytes ?: 0} bytes")
                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                if (state.connectionState is VpnConnectionState.Connected) {
                    androidx.compose.material3.TextButton(onClick = { viewModel.reconnect() }) {
                        Text("Reconnect Tunnel")
                    }
                }
            }
        }
    }
}

private fun statusLabel(state: VpnConnectionState): String = when (state) {
    is VpnConnectionState.Connected -> "🟢 Connected"
    is VpnConnectionState.Connecting -> "🟡 Connecting"
    is VpnConnectionState.Disconnecting -> "⚪ Disconnecting"
    is VpnConnectionState.Error -> "🔴 Error: ${state.message}"
    is VpnConnectionState.Disconnected -> "🔴 Disconnected"
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Medium)
    }
}
