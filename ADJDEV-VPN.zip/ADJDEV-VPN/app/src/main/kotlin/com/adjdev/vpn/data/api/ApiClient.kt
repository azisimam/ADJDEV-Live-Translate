package com.adjdev.vpn.data.api

import com.adjdev.vpn.data.security.SecureStore
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import kotlinx.serialization.json.Json
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import java.util.concurrent.TimeUnit

/**
 * Wiring Retrofit + OkHttp untuk komunikasi ke backend ADJDEV VPN.
 *
 * Aturan keamanan yang diterapkan di sini:
 *  - HTTPS only (base URL divalidasi, network_security_config memblok cleartext).
 *  - Token otentikasi diselipkan lewat interceptor, TIDAK PERNAH di-log.
 *  - Logging interceptor hanya mencatat baris request (BASIC), tidak pernah
 *    BODY, supaya token/credential tidak pernah tercetak di Logcat.
 */
class ApiClient(baseUrl: String, private val secureStore: SecureStore) {

    init {
        require(baseUrl.startsWith("https://")) {
            "API_BASE_URL harus menggunakan HTTPS. Nilai saat ini: $baseUrl"
        }
    }

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    private val authInterceptor = Interceptor { chain ->
        val token = secureStore.getAccessToken()
        val request = if (!token.isNullOrEmpty()) {
            chain.request().newBuilder()
                .addHeader("Authorization", "Bearer $token")
                .build()
        } else {
            chain.request()
        }
        chain.proceed(request)
    }

    private val safeLogging = HttpLoggingInterceptor().apply {
        // Sengaja dibatasi ke BASIC: tidak pernah mencatat header/body yang
        // bisa berisi token, credential, atau isi trafik pengguna.
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .addInterceptor(authInterceptor)
        .addInterceptor(safeLogging)
        .build()

    private val retrofit = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(okHttpClient)
        .addConverterFactory(
            json.asConverterFactory("application/json".toMediaType())
        )
        .build()

    val authApi: AuthApi = retrofit.create(AuthApi::class.java)
    val deviceApi: DeviceApi = retrofit.create(DeviceApi::class.java)
    val serverApi: ServerApi = retrofit.create(ServerApi::class.java)
}
