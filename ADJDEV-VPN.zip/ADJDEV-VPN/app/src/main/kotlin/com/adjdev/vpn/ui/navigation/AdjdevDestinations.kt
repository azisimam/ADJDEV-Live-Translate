package com.adjdev.vpn.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.ui.graphics.vector.ImageVector

sealed class AdjdevDestination(val route: String, val label: String, val icon: ImageVector) {
    data object Home : AdjdevDestination("home", "Home", Icons.Filled.Shield)
    data object Servers : AdjdevDestination("servers", "Servers", Icons.Filled.List)
    data object Details : AdjdevDestination("details", "Details", Icons.Filled.Timeline)
    data object Settings : AdjdevDestination("settings", "Settings", Icons.Filled.Settings)
    data object About : AdjdevDestination("about", "About", Icons.Filled.Info)

    companion object {
        val bottomNavItems = listOf(Home, Servers, Details, Settings, About)
    }
}
