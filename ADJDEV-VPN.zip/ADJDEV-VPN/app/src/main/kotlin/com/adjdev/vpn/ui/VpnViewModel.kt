package com.adjdev.vpn.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.adjdev.vpn.AdjdevVpnApplication
import com.adjdev.vpn.data.model.PeerConfigResponse
import com.adjdev.vpn.data.model.ServerInfo
import com.adjdev.vpn.data.repository.BackendUnavailableException
import com.adjdev.vpn.util.PingUtil
import com.adjdev.vpn.vpn.TunnelStats
import com.adjdev.vpn.vpn.VpnConnectionState
import com.adjdev.vpn.vpn.VpnPermissionRequiredException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class HomeUiState(
    val connectionState: VpnConnectionState = VpnConnectionState.Disconnected,
    val stats: TunnelStats? = null,
    val selectedServer: ServerInfo? = null,
    val servers: List<ServerInfo> = emptyList(),
    val assignedAddress: String? = null,
    val pingMs: Long? = null,
    val isBusy: Boolean = false,
    val errorMessage: String? = null
)

class VpnViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AdjdevVpnApplication
    private val wireGuardManager = app.wireGuardManager
    private val sessionRepository = app.sessionRepository
    private val serverRepository = app.serverRepository

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _permissionRequest = MutableStateFlow<Intent?>(null)
    val permissionRequest: StateFlow<Intent?> = _permissionRequest.asStateFlow()

    private var pendingPeerConfig: PeerConfigResponse? = null

    init {
        viewModelScope.launch {
            combine(wireGuardManager.connectionState, wireGuardManager.stats) { state, stats ->
                state to stats
            }.collect { (state, stats) ->
                _uiState.value = _uiState.value.copy(connectionState = state, stats = stats)
                if (state is VpnConnectionState.Connected) {
                    measurePing()
                }
            }
        }
        loadServers()
        restoreCachedPeer()
    }

    private fun restoreCachedPeer() {
        val cached = sessionRepository.getCachedPeerConfig()
        if (cached != null) {
            pendingPeerConfig = cached
            _uiState.value = _uiState.value.copy(assignedAddress = cached.assignedAddress)
        }
    }

    fun loadServers() {
        viewModelScope.launch {
            val servers = serverRepository.listServers()
            _uiState.value = _uiState.value.copy(
                servers = servers,
                selectedServer = _uiState.value.selectedServer ?: servers.firstOrNull()
            )
        }
    }

    fun selectServer(server: ServerInfo) {
        _uiState.value = _uiState.value.copy(selectedServer = server)
    }

    /** Dipanggil dari Home screen saat tombol Connect/Disconnect ditekan. */
    fun onConnectToggle() {
        val state = _uiState.value.connectionState
        if (state is VpnConnectionState.Connected) {
            disconnect()
        } else {
            connect()
        }
    }

    private fun connect() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true, errorMessage = null)
            try {
                val peerConfig = pendingPeerConfig ?: fetchOrGeneratePeerConfig()
                pendingPeerConfig = peerConfig
                _uiState.value = _uiState.value.copy(assignedAddress = peerConfig.assignedAddress)
                wireGuardManager.connect(peerConfig)
            } catch (e: VpnPermissionRequiredException) {
                _permissionRequest.value = wireGuardManager.permissionIntentOrNull()
            } catch (e: BackendUnavailableException) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = "Backend belum tersedia: ${e.message}"
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    errorMessage = e.message ?: "Gagal menghubungkan VPN"
                )
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false)
            }
        }
    }

    /** Dipanggil Activity setelah user memberi izin lewat dialog sistem VpnService. */
    fun onVpnPermissionGranted() {
        _permissionRequest.value = null
        connect()
    }

    fun onVpnPermissionDenied() {
        _permissionRequest.value = null
        _uiState.value = _uiState.value.copy(
            errorMessage = "Izin VPN ditolak. ADJDEV VPN memerlukan izin ini untuk membuat tunnel."
        )
    }

    private fun disconnect() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isBusy = true, errorMessage = null)
            try {
                wireGuardManager.disconnect()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message ?: "Gagal memutuskan VPN")
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false)
            }
        }
    }

    fun reconnect() {
        viewModelScope.launch {
            val peerConfig = pendingPeerConfig ?: return@launch
            _uiState.value = _uiState.value.copy(isBusy = true, errorMessage = null)
            try {
                wireGuardManager.reconnect(peerConfig)
            } catch (e: VpnPermissionRequiredException) {
                _permissionRequest.value = wireGuardManager.permissionIntentOrNull()
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(errorMessage = e.message ?: "Gagal reconnect")
            } finally {
                _uiState.value = _uiState.value.copy(isBusy = false)
            }
        }
    }

    /**
     * Mengambil konfigurasi peer dari backend REST. Jika device belum
     * terdaftar, mendaftarkan dulu menggunakan public key lokal, lalu
     * meminta backend menerbitkan peer baru (setiap device -> IP unik,
     * mis. 10.8.0.2, 10.8.0.3, dst. - dialokasikan oleh backend).
     */
    private suspend fun fetchOrGeneratePeerConfig(): PeerConfigResponse {
        return try {
            sessionRepository.refreshPeerConfig()
        } catch (e: Exception) {
            val publicKey = wireGuardManager.localPublicKeyBase64()
            sessionRepository.registerDevice(publicKey)
            sessionRepository.generatePeer()
        }
    }

    private fun measurePing() {
        viewModelScope.launch {
            val server = _uiState.value.selectedServer ?: serverRepository.defaultConfiguredServer()
            val pingResult = PingUtil.measurePingMs(server.endpointHost, server.endpointPort)
            _uiState.value = _uiState.value.copy(pingMs = pingResult)
        }
    }

    fun clearError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}
