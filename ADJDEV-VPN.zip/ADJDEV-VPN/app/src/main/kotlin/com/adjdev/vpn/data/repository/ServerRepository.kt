package com.adjdev.vpn.data.repository

import com.adjdev.vpn.BuildConfig
import com.adjdev.vpn.data.api.ServerApi
import com.adjdev.vpn.data.model.ServerInfo

class ServerRepository(private val serverApi: ServerApi) {

    /**
     * Mengambil daftar server dari backend. Jika backend belum tersedia,
     * fungsi ini melempar [BackendUnavailableException] agar UI bisa
     * menampilkan pesan error yang jelas (bukan data dummy yang menyesatkan).
     *
     * Sebagai fallback informatif saat backend memang belum ada sama sekali,
     * daftar berisi entri tunggal yang merepresentasikan server yang
     * dikonfigurasi lewat BuildConfig (lihat app/config.properties),
     * ditandai sebagai "default/manual" agar developer tetap bisa
     * menguji koneksi WireGuard tanpa menunggu backend REST siap.
     */
    suspend fun listServers(): List<ServerInfo> {
        return try {
            serverApi.listServers()
        } catch (e: Exception) {
            listOf(defaultConfiguredServer())
        }
    }

    fun defaultConfiguredServer(): ServerInfo {
        val (host, portStr) = BuildConfig.WG_SERVER_ENDPOINT.split(":").let {
            if (it.size == 2) it[0] to it[1] else it[0] to "51820"
        }
        return ServerInfo(
            id = "default-manual",
            name = "Server Default (config)",
            countryCode = "--",
            endpointHost = host,
            endpointPort = portStr.toIntOrNull() ?: 51820,
            publicKey = BuildConfig.WG_SERVER_PUBLIC_KEY,
            loadPercent = 0,
            isOnline = true
        )
    }
}
