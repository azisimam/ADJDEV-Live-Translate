package com.adjdev.vpn.vpn

/**
 * Status koneksi VPN sesuai spesifikasi UI:
 * 🔴 Disconnected, 🟡 Connecting, 🟢 Connected, ⚪ Disconnecting
 */
sealed class VpnConnectionState {
    data object Disconnected : VpnConnectionState()
    data object Connecting : VpnConnectionState()
    data class Connected(val connectedAtEpochMillis: Long) : VpnConnectionState()
    data object Disconnecting : VpnConnectionState()
    data class Error(val message: String) : VpnConnectionState()
}

data class TunnelStats(
    val rxBytes: Long,
    val txBytes: Long
)
