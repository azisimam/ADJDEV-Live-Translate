package com.adjdev.vpn.data.repository

import android.os.Build
import com.adjdev.vpn.data.api.AuthApi
import com.adjdev.vpn.data.api.DeviceApi
import com.adjdev.vpn.data.model.DeviceRegisterRequest
import com.adjdev.vpn.data.model.LoginRequest
import com.adjdev.vpn.data.model.PeerConfigResponse
import com.adjdev.vpn.data.model.RegisterRequest
import com.adjdev.vpn.data.security.SecureStore
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Mengatur alur akun & device: login/register, registrasi device, dan
 * penerbitan peer WireGuard untuk device tsb. Ini adalah lapisan "siap
 * diintegrasikan dengan REST API" yang diminta - saat ini endpoint asli
 * belum tentu tersedia, sehingga setiap fungsi melempar exception yang
 * jelas ([BackendUnavailableException]) bila gagal, BUKAN silent-fail
 * atau data palsu.
 */
class SessionRepository(
    private val authApi: AuthApi,
    private val deviceApi: DeviceApi,
    private val secureStore: SecureStore
) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun login(email: String, password: String) {
        runCatchingBackend {
            val response = authApi.login(LoginRequest(email, password))
            secureStore.saveAuthTokens(response.accessToken, response.refreshToken)
        }
    }

    suspend fun register(email: String, password: String, displayName: String) {
        runCatchingBackend {
            val response = authApi.register(RegisterRequest(email, password, displayName))
            secureStore.saveAuthTokens(response.accessToken, response.refreshToken)
        }
    }

    fun isLoggedIn(): Boolean = !secureStore.getAccessToken().isNullOrEmpty()

    fun logout() = secureStore.clearAuthTokens()

    /**
     * Mendaftarkan device ini ke backend menggunakan public key WireGuard
     * yang sudah di-generate lokal (lihat WireGuardManager). Hasilnya
     * (deviceId) disimpan untuk dipakai memanggil generatePeer/getPeerConfig.
     */
    suspend fun registerDevice(localPublicKey: String): String = runCatchingBackend {
        val deviceName = "${Build.MANUFACTURER} ${Build.MODEL}".trim().ifEmpty { "Android Device" }
        val response = deviceApi.registerDevice(
            DeviceRegisterRequest(deviceName = deviceName, publicKey = localPublicKey)
        )
        secureStore.saveDeviceId(response.deviceId)
        response.deviceId
    }

    suspend fun generatePeer(): PeerConfigResponse = runCatchingBackend {
        val deviceId = secureStore.getDeviceId()
            ?: throw IllegalStateException("Device belum terdaftar. Panggil registerDevice() dahulu.")
        val response = deviceApi.generatePeer(deviceId)
        secureStore.savePeerConfigJson(json.encodeToString(response))
        response
    }

    suspend fun refreshPeerConfig(): PeerConfigResponse = runCatchingBackend {
        val deviceId = secureStore.getDeviceId()
            ?: throw IllegalStateException("Device belum terdaftar.")
        val response = deviceApi.getPeerConfig(deviceId)
        secureStore.savePeerConfigJson(json.encodeToString(response))
        response
    }

    fun getCachedPeerConfig(): PeerConfigResponse? =
        secureStore.getPeerConfigJson()?.let {
            runCatching { json.decodeFromString(PeerConfigResponse.serializer(), it) }.getOrNull()
        }

    suspend fun revokeThisDevice() = runCatchingBackend {
        val deviceId = secureStore.getDeviceId() ?: return@runCatchingBackend
        deviceApi.revokeDevice(deviceId)
        secureStore.clearAll()
    }

    private suspend fun <T> runCatchingBackend(block: suspend () -> T): T {
        return try {
            block()
        } catch (e: java.net.UnknownHostException) {
            throw BackendUnavailableException("Tidak dapat menjangkau server backend.", e)
        } catch (e: java.net.ConnectException) {
            throw BackendUnavailableException("Koneksi ke server backend ditolak/gagal.", e)
        } catch (e: retrofit2.HttpException) {
            throw BackendUnavailableException("Server backend mengembalikan error HTTP ${e.code()}.", e)
        }
    }
}

/** Dilempar saat backend REST API belum tersedia / tidak bisa dihubungi. */
class BackendUnavailableException(message: String, cause: Throwable? = null) : Exception(message, cause)
