package com.adjdev.vpn.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.adjdev.vpn.ui.VpnViewModel
import com.adjdev.vpn.vpn.VpnConnectionState
import java.util.Locale

@Composable
fun HomeScreen(viewModel: VpnViewModel) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = "ADJDEV VPN",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(24.dp))

        StatusBadge(state.connectionState)
        Spacer(Modifier.height(32.dp))

        ConnectButton(
            state = state.connectionState,
            isBusy = state.isBusy,
            onClick = viewModel::onConnectToggle
        )

        Spacer(Modifier.height(32.dp))

        InfoCard(state = state)

        state.errorMessage?.let { message ->
            Spacer(Modifier.height(16.dp))
            Snackbar(
                action = {
                    Text(
                        text = "TUTUP",
                        modifier = Modifier.padding(8.dp),
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(message)
            }
        }
    }
}

@Composable
private fun StatusBadge(state: VpnConnectionState) {
    val (label, color) = when (state) {
        is VpnConnectionState.Connected -> "🟢 Connected" to Color(0xFF2ECC71)
        is VpnConnectionState.Connecting -> "🟡 Connecting" to Color(0xFFF1C40F)
        is VpnConnectionState.Disconnecting -> "⚪ Disconnecting" to Color(0xFFBDC3C7)
        is VpnConnectionState.Error -> "🔴 Error" to Color(0xFFE74C3C)
        is VpnConnectionState.Disconnected -> "🔴 Disconnected" to Color(0xFFE74C3C)
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.12f))
    ) {
        Text(
            text = label,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
            color = color,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.titleLarge
        )
    }
}

@Composable
private fun ConnectButton(
    state: VpnConnectionState,
    isBusy: Boolean,
    onClick: () -> Unit
) {
    val isConnected = state is VpnConnectionState.Connected
    val buttonColor = if (isConnected) Color(0xFFE74C3C) else MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .size(180.dp)
            .background(buttonColor.copy(alpha = 0.1f), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Button(
            onClick = onClick,
            enabled = !isBusy && state !is VpnConnectionState.Connecting && state !is VpnConnectionState.Disconnecting,
            shape = CircleShape,
            modifier = Modifier.size(140.dp)
        ) {
            if (isBusy) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp))
            } else {
                Text(if (isConnected) "DISCONNECT" else "CONNECT", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun InfoCard(state: com.adjdev.vpn.ui.HomeUiState) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(20.dp)) {
            InfoRow("Server", state.selectedServer?.name ?: "-")
            InfoRow("IP Address", state.assignedAddress ?: "-")
            InfoRow("Ping", state.pingMs?.let { "${it} ms" } ?: "-")
            InfoRow("Download", formatBytes(state.stats?.rxBytes))
            InfoRow("Upload", formatBytes(state.stats?.txBytes))
            InfoRow("Duration", durationText(state.connectionState))
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

private fun formatBytes(bytes: Long?): String {
    if (bytes == null) return "-"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unitIndex = 0
    while (value >= 1024 && unitIndex < units.lastIndex) {
        value /= 1024
        unitIndex++
    }
    return String.format(Locale.US, "%.1f %s", value, units[unitIndex])
}

private fun durationText(state: VpnConnectionState): String {
    if (state !is VpnConnectionState.Connected) return "-"
    val elapsedSeconds = (System.currentTimeMillis() - state.connectedAtEpochMillis) / 1000
    val h = elapsedSeconds / 3600
    val m = (elapsedSeconds % 3600) / 60
    val s = elapsedSeconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
}
