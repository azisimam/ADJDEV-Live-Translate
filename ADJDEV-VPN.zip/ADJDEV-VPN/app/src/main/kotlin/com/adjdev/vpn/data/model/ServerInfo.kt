package com.adjdev.vpn.data.model

import kotlinx.serialization.Serializable

/**
 * Representasi satu server WireGuard yang tersedia bagi user.
 * Data ini idealnya diambil dari endpoint GET /servers milik backend.
 */
@Serializable
data class ServerInfo(
    val id: String,
    val name: String,
    val countryCode: String,
    val endpointHost: String,
    val endpointPort: Int,
    val publicKey: String,
    val loadPercent: Int = 0,
    val isOnline: Boolean = true
)

@Serializable
data class ServerStatus(
    val serverId: String,
    val isOnline: Boolean,
    val connectedPeers: Int,
    val loadPercent: Int
)
