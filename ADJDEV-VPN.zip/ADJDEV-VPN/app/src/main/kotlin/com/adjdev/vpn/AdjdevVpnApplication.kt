package com.adjdev.vpn

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.adjdev.vpn.data.api.ApiClient
import com.adjdev.vpn.data.repository.ServerRepository
import com.adjdev.vpn.data.repository.SessionRepository
import com.adjdev.vpn.data.security.SecureStore
import com.adjdev.vpn.vpn.WireGuardManager

/**
 * Application root. Menyimpan instance singleton sederhana untuk backend
 * WireGuard dan repository, tanpa framework DI eksternal supaya project
 * tetap ringan dan mudah di-build tanpa dependency tambahan.
 */
class AdjdevVpnApplication : Application() {

    lateinit var secureStore: SecureStore
        private set

    lateinit var apiClient: ApiClient
        private set

    lateinit var sessionRepository: SessionRepository
        private set

    lateinit var serverRepository: ServerRepository
        private set

    lateinit var wireGuardManager: WireGuardManager
        private set

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        secureStore = SecureStore(this)
        apiClient = ApiClient(baseUrl = BuildConfig.API_BASE_URL, secureStore = secureStore)
        sessionRepository = SessionRepository(apiClient.authApi, apiClient.deviceApi, secureStore)
        serverRepository = ServerRepository(apiClient.serverApi)
        wireGuardManager = WireGuardManager(this)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                VPN_NOTIFICATION_CHANNEL_ID,
                "ADJDEV VPN Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Menampilkan status koneksi VPN yang sedang aktif"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    companion object {
        const val VPN_NOTIFICATION_CHANNEL_ID = "adjdev_vpn_status"
    }
}
