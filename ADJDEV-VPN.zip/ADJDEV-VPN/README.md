# ADJDEV VPN

Aplikasi Android native VPN client berbasis **WireGuard**, dibangun dengan
Kotlin + Gradle + Android Jetpack + Material 3. Project ini didesain agar
bisa langsung di-build menjadi APK lewat **GitHub Actions**, tanpa perlu
Android Studio di komputer lokal.

Tunnel WireGuard yang dibuat aplikasi ini **nyata**, menggunakan library
resmi `com.wireguard.android:tunnel` (GoBackend) yang juga dipakai oleh
aplikasi WireGuard official — bukan simulasi UI.

---

## Daftar Isi

1. [Cara upload project ke GitHub](#1-cara-upload-project-ke-github)
2. [Cara menjalankan GitHub Actions](#2-cara-menjalankan-github-actions)
3. [Cara mengambil APK dari Artifacts](#3-cara-mengambil-apk-dari-artifacts)
4. [Cara mengubah endpoint API](#4-cara-mengubah-endpoint-api)
5. [Cara menghubungkan aplikasi ke WireGuard backend](#5-cara-menghubungkan-aplikasi-ke-wireguard-backend)
6. [Cara konfigurasi server VPN](#6-cara-konfigurasi-server-vpn)
7. [Struktur Project](#7-struktur-project)
8. [Catatan Keamanan](#8-catatan-keamanan)
9. [Batasan & Catatan Teknis](#9-batasan--catatan-teknis)

---

## 1. Cara upload project ke GitHub

1. Buat repository baru di GitHub (bisa private/public), contoh: `adjdev-vpn`.
2. Di komputer Anda, masuk ke folder hasil ekstrak project ini, lalu jalankan:

   ```bash
   cd ADJDEV-VPN
   git init
   git add .
   git commit -m "Initial commit: ADJDEV VPN"
   git branch -M main
   git remote add origin https://github.com/USERNAME/adjdev-vpn.git
   git push -u origin main
   ```

3. Selesai — tidak perlu Android Studio sama sekali di langkah ini.

> Pastikan Anda **tidak** meng-commit file `app/config.properties` atau file
> `.conf` WireGuard pribadi Anda — keduanya sudah otomatis diabaikan oleh
> `.gitignore`.

## 2. Cara menjalankan GitHub Actions

Workflow build (`.github/workflows/build.yml`) berjalan otomatis setiap kali
Anda:

- `git push` ke branch `main` atau `master`, atau
- membuka Pull Request ke branch tersebut.

Anda juga bisa menjalankannya manual:

1. Buka repository di GitHub.
2. Klik tab **Actions**.
3. Pilih workflow **"Build ADJDEV VPN APK"** di sidebar kiri.
4. Klik **"Run workflow"** → pilih branch → **Run workflow**.

Workflow ini akan otomatis:

1. Checkout repository
2. Setup JDK 17
3. Setup Android SDK + install `platforms;android-34` dan `build-tools;34.0.0`
4. Meng-generate `gradle-wrapper.jar` (lihat [Catatan Teknis](#9-batasan--catatan-teknis))
5. Memberi permission executable ke `gradlew`
6. Menjalankan `./gradlew assembleDebug`
7. Meng-upload hasil APK sebagai GitHub Actions Artifact bernama `app-debug`

## 3. Cara mengambil APK dari Artifacts

1. Buka tab **Actions** di repository Anda.
2. Klik run workflow yang sudah selesai (tanda centang hijau ✅).
3. Scroll ke bagian **Artifacts** di bagian bawah halaman ringkasan run.
4. Klik **`app-debug`** untuk mengunduh file zip berisi `app-debug.apk`.
5. Ekstrak dan install APK tersebut ke perangkat Android (aktifkan
   "Install from unknown sources" jika diminta).

## 4. Cara mengubah endpoint API

Endpoint API backend (untuk login, device registration, generate peer, dll.)
**tidak di-hardcode** di source code. Ada dua cara mengubahnya:

**A. Lewat GitHub Actions (untuk build APK):**

1. Buka repository → **Settings** → **Secrets and variables** → **Actions** → tab **Variables**.
2. Tambahkan variable:
   - `ADJDEV_API_BASE_URL` → contoh: `https://api.punya-anda.com/`
   - `ADJDEV_WG_SERVER_PUBLIC_KEY`
   - `ADJDEV_WG_SERVER_ENDPOINT`
   - `ADJDEV_WG_VPN_SUBNET`
3. Jalankan ulang workflow — APK baru akan otomatis memakai nilai tersebut.

**B. Lewat file lokal (untuk build manual, opsional):**

Salin `app/config.properties.example` menjadi `app/config.properties` (sudah
di-gitignore) dan isi sesuai kebutuhan:

```properties
API_BASE_URL=https://api.punya-anda.com/
WG_SERVER_PUBLIC_KEY=RB271L8TjjyyXdnZRu334PsRSWfN5NqxMBPieStRVGk=
WG_SERVER_ENDPOINT=203.0.113.10:51820
WG_VPN_SUBNET=10.8.0.0/24
```

Kedua cara ini membaca nilai lewat `app/build.gradle.kts` dan meng-inject-nya
ke `BuildConfig`, sehingga source code utama **tidak pernah berubah**.

## 5. Cara menghubungkan aplikasi ke WireGuard backend

Alur yang sudah disiapkan di `SessionRepository` + `WireGuardManager`:

1. **Generate keypair lokal** — saat pertama kali dibutuhkan, aplikasi
   membuat keypair WireGuard *di perangkat* (`WireGuardManager.ensureLocalKeyPair()`).
   Private key ini disimpan terenkripsi (Android Keystore) dan **tidak
   pernah dikirim ke server**.
2. **Register device** — aplikasi memanggil `POST /v1/devices/register`
   dengan public key device tsb (`DeviceApi.registerDevice`).
3. **Generate peer** — aplikasi memanggil `POST /v1/devices/{id}/peer`
   (`DeviceApi.generatePeer`), backend Anda bertugas:
   - Menjalankan `wg set wg0 peer <public_key_device> allowed-ips 10.8.0.X/32`
   - Mengalokasikan IP unik per device (contoh: device A → `10.8.0.2`,
     device B → `10.8.0.3`, dst.)
   - Mengembalikan JSON berisi `assignedAddress`, `serverPublicKey`,
     `endpointHost`, `endpointPort`, `allowedIps`, `dns`.
4. **Connect** — `WireGuardManager` membangun objek `Config` WireGuard dari
   respons di atas + keypair lokal, lalu memanggil
   `GoBackend.setState(tunnel, Tunnel.State.UP, config)` — ini yang membuat
   tunnel VPN sungguhan di sistem Android.

Anda perlu mengimplementasikan endpoint REST di atas di server Anda sendiri
(lihat interface di `app/.../data/api/AuthApi.kt`, `DeviceApi.kt`,
`ServerApi.kt` untuk kontrak lengkapnya). Selama backend belum tersedia,
tombol Connect akan menampilkan pesan error yang jelas
(`BackendUnavailableException`), bukan berpura-pura berhasil.

**Uji cepat tanpa backend:** jika Anda hanya ingin menguji tunnel WireGuard
memakai file `.conf` yang sudah Anda punya (mis. hasil `wg genkey` manual),
Anda bisa sementara meng-hardcode nilai tsb di `app/config.properties` lokal
Anda (jangan di-commit) sebagai `WG_SERVER_ENDPOINT`/`WG_SERVER_PUBLIC_KEY`,
dan menambahkan sedikit kode di `VpnViewModel` untuk melewati langkah
register/generate-peer, langsung memakai `PeerConfigResponse` buatan tangan
berisi address `10.8.0.2/32` dari file `.conf` Anda.

## 6. Cara konfigurasi server VPN

Di sisi server (VPS Anda), yang perlu disiapkan:

```bash
# Contoh konfigurasi wg0 di server (Linux)
[Interface]
PrivateKey = <PRIVATE_KEY_SERVER_ANDA>   # JANGAN PERNAH taruh ini di APK
Address = 10.8.0.1/24
ListenPort = 51820
PostUp   = iptables -A FORWARD -i wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# Peer akan ditambahkan secara dinamis oleh backend REST API Anda,
# satu [Peer] per device, menggunakan public key yang dikirim aplikasi:
[Peer]
PublicKey = <PUBLIC_KEY_DARI_DEVICE_ANDROID>
AllowedIPs = 10.8.0.2/32
```

Backend REST API Anda (di luar scope Android project ini) idealnya
menjalankan `wg set wg0 peer ... allowed-ips ...` setiap kali endpoint
`POST /v1/devices/{id}/peer` dipanggil, lalu menyimpan pemetaan
`device_id -> ip_address` di database agar tidak ada IP yang bentrok.

Detail server publik yang dipakai sebagai default di project ini (bisa
diubah lewat konfigurasi, lihat [bagian 4](#4-cara-mengubah-endpoint-api)):

| Item | Nilai |
|---|---|
| Interface | `wg0` |
| Public Key | `RB271L8TjjyyXdnZRu334PsRSWfN5NqxMBPieStRVGk=` |
| Endpoint | `148.230.96.102:51820` |
| Protocol | UDP |
| VPN Subnet | `10.8.0.0/24` |

## 7. Struktur Project

```
ADJDEV-VPN/
├── .github/workflows/build.yml       # CI: build & upload APK
├── app/
│   ├── build.gradle.kts              # konfigurasi module + injeksi BuildConfig
│   ├── config.properties.example     # contoh override konfigurasi lokal
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── kotlin/com/adjdev/vpn/
│           ├── AdjdevVpnApplication.kt
│           ├── MainActivity.kt
│           ├── data/
│           │   ├── api/          # Retrofit: Auth, Device, Server
│           │   ├── model/        # data class (serializable)
│           │   ├── repository/   # SessionRepository, ServerRepository
│           │   └── security/     # SecureStore (Android Keystore)
│           ├── vpn/              # WireGuardManager, AdjdevTunnel, state
│           ├── ui/
│           │   ├── VpnViewModel.kt
│           │   ├── navigation/
│           │   ├── theme/
│           │   └── screens/{home,servers,details,settings,about}
│           └── util/PingUtil.kt
├── gradle/libs.versions.toml         # version catalog terpusat
├── build.gradle.kts / settings.gradle.kts
└── gradlew / gradlew.bat
```

## 8. Catatan Keamanan

- **HTTPS only** — `ApiClient` menolak base URL yang bukan `https://`, dan
  `network_security_config.xml` memblokir cleartext traffic di level OS.
- **Private key server tidak pernah ada di APK** — hanya public key server
  yang disimpan (lewat `BuildConfig`, bisa diubah tanpa recompile source).
- **Private key device digenerate lokal**, disimpan lewat
  `EncryptedSharedPreferences` yang di-backing oleh Android Keystore
  (`SecureStore.kt`).
- **Token API** disimpan dengan cara yang sama, tidak pernah di-log
  (`HttpLoggingInterceptor` dikunci ke level `BASIC`, tidak mencatat
  header/body).
- **Tidak ada logging isi trafik pengguna** — aplikasi hanya membaca
  statistik agregat RX/TX dari WireGuard backend, tidak menyadap/mencatat
  payload trafik.
- `data_extraction_rules.xml` mengecualikan seluruh shared preferences &
  file dari cloud backup/device transfer, supaya token & key tidak ikut
  ter-backup ke akun Google pengguna.

## 9. Batasan & Catatan Teknis

- **`gradle-wrapper.jar` tidak disertakan sebagai file di repository** ini
  karena merupakan file biner yang dibuat oleh perintah `gradle wrapper`
  (lihat penjelasan di `gradle/wrapper/NOTE.md`). Workflow GitHub Actions
  sudah menghasilkannya secara otomatis di setiap run, jadi ini **tidak
  memerlukan tindakan apa pun dari Anda**. Jika ingin build lokal, jalankan
  sekali: `gradle wrapper --gradle-version 8.9 --distribution-type bin`
  setelah meng-install Gradle di komputer Anda.
- Endpoint REST API (`AuthApi`, `DeviceApi`, `ServerApi`) adalah **kontrak/
  interface** yang siap diintegrasikan — implementasi server-nya perlu
  dibuat terpisah (Node.js/Go/Python/dll., di luar scope project Android
  ini). Selama backend belum ada, tombol Connect akan menampilkan pesan
  error yang jelas, bukan berpura-pura terhubung.
- Fitur "Ping" mengukur latency nyata (ICMP reachability, fallback ke TCP
  handshake) — bukan angka acak.
- Versi yang dipakai: Kotlin 2.0.21, AGP 8.5.2, Gradle 8.9, JDK 17,
  compileSdk/targetSdk 34, minSdk 24 — kombinasi yang saling kompatibel per
  dokumentasi resmi Android/Kotlin.
