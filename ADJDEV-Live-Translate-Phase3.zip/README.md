# ADJDEV Live Translate — Phase 1 + Phase 2 + Phase 3 (awal)

Floating-overlay live translator untuk penggunaan pribadi. Native Android (Kotlin + Jetpack
Compose), local-first, tanpa backend/VPS/login/cloud database.

## ⚠️ Belum bisa langsung diinstall dari sini

Ini adalah source project, bukan APK. Sandbox pembuatan project ini tidak punya akses internet
(dibutuhkan Gradle untuk mengunduh dependency) maupun Android SDK terpasang, jadi saya tidak bisa
mengcompile APK di sisi saya. Untuk mendapatkan APK yang bisa diinstall:

1. Buka folder ini di Android Studio → Run ke device fisik via USB (paling gampang, wrapper
   Gradle akan di-generate otomatis), **atau**
2. Kalau sudah ada Gradle terpasang lokal: `gradle wrapper --gradle-version 8.7` lalu
   `./gradlew assembleDebug` → APK ada di `app/build/outputs/apk/debug/`.

### Kalau pakai IDE Gradle di HP (mis. AndroidIDE, dan sejenisnya)

Jika muncul error semacam **"Tidak ditemukan module aplikasi dalam proyek"**, dua hal yang perlu
dicek:

- **Buka folder yang BENAR sebagai project root.** Zip ini sekarang di-package rata (flat) —
  `settings.gradle.kts` ada persis di root arsip, bukan di dalam subfolder lagi. Pastikan aplikasi
  IDE-mu membuka folder hasil ekstrak zip ini langsung (yang berisi `settings.gradle.kts`,
  `build.gradle.kts`, dan folder `app/` sejajar), bukan folder di atasnya.
- **Gradle wrapper** (`gradlew`, `gradle/wrapper/gradle-wrapper.properties`) sudah saya tambahkan.
  Namun **`gradle-wrapper.jar`** (file binary bootstrap Gradle) belum ada — saya tidak punya akses
  internet untuk mengunduhnya. Kalau IDE di HP-mu butuh file ini secara eksplisit dan tidak
  auto-generate, jalankan `gradle wrapper` sekali di device tersebut (kalau ada Gradle bawaan
  aplikasinya) untuk melengkapi file jar itu, atau unduh manual dari
  `https://services.gradle.org/distributions/` sesuai versi di `gradle-wrapper.properties`.

Saya belum pernah menguji aplikasi RiSETiDEx secara spesifik, jadi kalau setelah dua perbaikan di
atas masih error yang sama, kemungkinan besar app tersebut punya persyaratan struktur project
yang lebih spesifik (mis. hanya mendukung Groovy DSL `settings.gradle`/`build.gradle`, bukan
Kotlin DSL `.kts`) — beri tahu saya pesan error persisnya dan saya bisa coba convert project ke
Groovy DSL sebagai alternatif.

## Status: Phase 1 (selesai) + Phase 2 (selesai sesuai checklist §20, minus profiling formal)

Yang sudah dibangun di skeleton ini:

- Project Android (Gradle Kotlin DSL), struktur modular sesuai spesifikasi (`audio/`, `stt/`,
  `translation/`, `detection/`, `vad/`, `overlay/`, `settings/`, `storage/`, `core/`).
- Floating overlay (panel penuh + bubble minimized) via `WindowManager` + Compose, dikelola oleh
  satu Foreground Service (`OverlayService`).
- Mic capture (`MicAudioSource`, `AudioRecord`) dengan toggle ON/OFF yang benar-benar melepas
  resource saat OFF.
- System audio capture (`SystemAudioSource`, `AudioPlaybackCaptureConfiguration`, API 29+) —
  lihat **Keterbatasan** di bawah.
- VAD berbasis energi (RMS), ringan, dipakai sebagai gate agar STT tidak selalu aktif.
- STT via `android.speech.SpeechRecognizer` (prioritas on-device jika tersedia).
- Deteksi bahasa otomatis via ML Kit Language ID (on-device).
- Terjemahan via ML Kit Translate (on-device setelah model per pasangan bahasa diunduh sekali).
- Cache terjemahan lokal (LRU, in-memory, dibatasi ukurannya).
- Settings lokal via DataStore (bukan cloud, tidak ada login).
- UI utama sesuai spesifikasi §13 (status, input toggle, mode selector, Start/Stop).

Tambahan Phase 2 yang sudah masuk:

- **Overlay draggable + snap-to-edge**: `OverlayService.attachDragHandling()` — geser panel,
  lepas, otomatis nempel ke tepi kiri/kanan layar terdekat dengan animasi singkat.
- **Translation cache persist**: `TranslationCache` sekarang menulis ke DataStore di background
  (tidak memblokir fast path) sehingga cache frasa bertahan lintas restart aplikasi.
- **Conversation context buffer** (`conversation/ConversationContextStore.kt`): menyimpan N
  turn percakapan terakhir (dibatasi ketat sesuai setting `contextMessageLimit`), sebagai
  dasar untuk mode SMART di Phase 3. Tombol **Clear Conversation** sudah aktif di overlay.
- **Fix crash saat mulai bicara**: `SpeechRecognizer` sebelumnya dibuat di background thread
  (Dispatchers.Default, tanpa Looper) → crash. Sekarang sesi STT dijalankan di `Dispatchers.Main`.
- **Fix crash saat Start Translator**: foreground service sebelumnya mendeklarasikan tipe
  `mediaProjection` tanpa pernah meminta izin `MediaProjectionManager` → SecurityException di
  Android 14+. Sekarang service start dengan tipe `microphone` saja; System Audio dinonaktifkan
  sementara di UI sampai alur permintaan izinnya benar-benar dibangun.
- **Fix "tidak ada teks muncul" saat bicara**: `MicAudioSource` (untuk VAD) dan
  `android.speech.SpeechRecognizer` (untuk STT) sebelumnya sama-sama coba akses mic secara
  bersamaan — di banyak perangkat ini bikin SpeechRecognizer gagal dapat audio secara diam-diam
  (`onError` cuma `close()` tanpa pesan apa pun). Sekarang: VAD custom tidak dipakai lagi untuk
  gating mic; `TranslationPipeline` menjalankan sesi SpeechRecognizer berulang (auto-restart),
  dan `onError` sekarang membedakan error normal (hening/timeout, diam-diam restart) dari error
  yang perlu terlihat user (mic direbut app lain, izin dicabut, dll — muncul di overlay).
  `EnergyVadEngine`/`MicAudioSource` tetap ada di codebase untuk dipakai STT engine berbasis
  raw-PCM (Vosk/whisper.cpp) nanti yang bisa berbagi satu AudioRecord tap tanpa konflik.
- **Streaming/partial translation lebih halus** (`TranslationPipeline.schedulePartialTranslation`):
  sebelumnya, selagi user masih bicara, overlay cuma menampilkan teks sumber mentah (belum
  diterjemahkan) — terjemahan baru muncul setelah SpeechRecognizer menandai hasil sebagai final.
  Sekarang teks partial juga diterjemahkan secara live, di-debounce 400ms (dan diabaikan kalau
  < 2 karakter) supaya tidak memanggil translation engine di setiap perubahan huruf. Job partial
  ini dibatalkan begitu ada partial baru atau transcript final datang, dan kegagalannya diam-diam
  saja — hasil FINAL dari `handleFinalTranscript()` tetap satu-satunya sumber kebenaran, fast
  path tidak pernah menunggu proses ini. Overlay membedakan visualnya lewat warna teks yang
  sedikit diredupkan selama partial (`OverlayScreen.kt`).
- **Resize overlay via gesture** (`OverlayService.attachDragAndResizeHandling`): panel sekarang
  bisa diperlebar/dipersempit dengan menyeret kotak kecil di pojok kanan-bawah (ikon
  "resize" transparan), dibatasi 220–400dp dan dipersist ke DataStore (`overlay_width`) lintas
  restart. Drag-to-resize dan drag-to-move ditangani dalam SATU `View.OnTouchListener` yang sama
  (bukan `pointerInput` Compose terpisah di dalam handle) — kalau dipisah, `ACTION_MOVE` untuk
  resize bisa "kerebut" duluan oleh logika drag-to-move begitu melewati touch slop. Titik awal
  sentuhan dicek dulu terhadap area kotak resize (`RESIZE_HANDLE_DP`) sebelum menentukan mode
  (`PENDING_RESIZE` vs `PENDING_MOVE`) untuk sesi sentuh tersebut.

## Phase 3 (baru, kali ini): SMART & COPILOT sungguhan, bukan placeholder lagi

**Bug diperbaiki dulu**: error *"Translation model files not found. Make sure to call
downloadModelIfNeeded..."* yang muncul saat Start Translator disebabkan `TranslationPipeline`
memanggil `translationEngine.translate()` langsung tanpa pernah memanggil
`ensureModelDownloaded()` lebih dulu — jadi ML Kit selalu gagal karena model untuk pasangan
bahasa itu belum terunduh. Sekarang `handleFinalTranscript()` dan
`schedulePartialTranslation()` di `TranslationPipeline.kt` memastikan model terunduh dulu
sebelum menerjemahkan. Sekalian: `MlKitTranslationEngine` sebelumnya mensyaratkan `.requireWifi()`
untuk unduhan model, yang bikin proses unduh menggantung tanpa sukses/gagal kalau device sedang
di data seluler — sekarang syarat itu dilepas.

**SMART dan COPILOT sekarang benar-benar memakai model AI on-device** (bukan lagi placeholder
rule-based / context yang cuma dicatat tanpa dipakai), lewat **Gemini Nano** via
**ML Kit GenAI Prompt API** (`com.google.mlkit:genai-prompt`, diakses lewat AICore bawaan
Android):

- **`ai/GeminiNanoCopilotEngine.kt`**: implementasi `AIEngine` sungguhan untuk COPILOT — 3
  saran balasan dihasilkan oleh model generatif, bukan rule-based lagi.
- **`translation/ContextAwareTranslationEngine.kt`**: implementasi `TranslationEngine` untuk
  SMART — `translateWithContext()` mengirim beberapa giliran percakapan terakhir sebagai bagian
  prompt ke Gemini Nano, sesuatu yang **tidak bisa** dilakukan ML Kit Translate biasa (NMT
  klasik, satu kalimat berdiri sendiri, tanpa context injection). Mode LIGHT/COPILOT tetap
  memakai `translate()` ML Kit biasa seperti sebelumnya — SMART-lah satu-satunya yang lewat
  jalur ini, sesuai kontrak baru `translateWithContext()` di `TranslationEngine`.
- **`ai/FallbackCopilotEngine.kt`**: composite — coba Gemini Nano dulu, otomatis & permanen
  (untuk sesi translator berjalan) pindah ke `PlaceholderCopilotEngine` lama kalau
  `checkStatus()` mengembalikan `UNAVAILABLE` atau `load()` gagal apa pun. Jadi COPILOT tidak
  pernah mati total di perangkat yang belum didukung — cuma turun ke rule-based seperti Phase 2.
- AI Path tetap terpisah dari Fast Path (spesifikasi §11): translation tampil dulu di overlay,
  suggested replies menyusul di coroutine terpisah — tidak berubah dari Phase 2.

### ⚠️ Batasan penting Gemini Nano / ML Kit GenAI Prompt API

- **Beta/alpha per dokumentasi resmi Google (Jan 2026)**, hanya jalan di perangkat yang
  didukung **AICore** — sebagian besar flagship 2024+ (Pixel 9/10, Galaxy S25/S26, sebagian
  Oppo/Honor/Poco terbaru; lihat daftar resmi ML Kit GenAI, berubah dari waktu ke waktu).
  **Perangkat target awal spesifikasi (kelas menengah, mis. Redmi Note 13 4G) kemungkinan
  besar TIDAK termasuk** — di perangkat itu `checkStatus()` akan `UNAVAILABLE` dan SMART/COPILOT
  otomatis berperilaku sama seperti Phase 2 (fallback), **bukan bug**.
- **Tidak didukung di perangkat dengan bootloader unlocked** (batasan resmi AICore).
- Model Gemini Nano jauh lebih besar dari model ML Kit Translate (~30MB). Sengaja **tidak**
  dipicu unduh otomatis diam-diam di `ContextAwareTranslationEngine` untuk menghindari
  menghabiskan kuota data user tanpa izin — kalau status device `DOWNLOADABLE` (belum
  terunduh), SMART untuk sesi itu berperilaku seperti fallback sampai fitur benar-benar
  `AVAILABLE`. `GeminiNanoCopilotEngine.load()` (dipicu saat masuk mode COPILOT) memang memicu
  unduh sekali kalau `DOWNLOADABLE` — pertimbangkan menambah dialog konfirmasi user sebelum ini
  di iterasi berikutnya kalau ukurannya jadi masalah.
- Input dibatasi ~4000 token per request (cukup untuk prompt translasi/saran balasan single-turn
  seperti di sini, jadi tidak jadi masalah praktis).

**Yang masih placeholder / belum real setelah Phase 3 ini**, supaya jelas:
- System Audio: masih nonaktif, izin MediaProjection belum di-wire (dari Phase 2, belum
  disentuh di iterasi ini).
- Profiling RAM/CPU/baterai formal: belum ada — dijadwalkan Phase 4.
- Opacity overlay: setting `overlay_opacity` sudah ada di `SettingsRepository` tapi belum ada
  UI slider maupun diterapkan ke alpha panel.
- Di perangkat yang TIDAK didukung AICore (kemungkinan besar mayoritas target awal), SMART dan
  COPILOT secara fungsional kembali sama seperti Phase 2 (fallback otomatis) — belum ada
  alternatif model kecil quantized (MediaPipe LLM Inference/llama.cpp) untuk perangkat kelas
  menengah seperti disebut di TODO lama `PlaceholderCopilotEngine.kt`; itu masih pekerjaan
  terbuka kalau device target memang tidak didukung Gemini Nano.

**Catatan kejujuran Phase 3**: sama seperti Phase 1/2, saya tidak bisa mengcompile atau
menjalankan project ini di sandbox saya (tanpa akses internet & Android SDK) — kode di
`GeminiNanoCopilotEngine.kt`, `ContextAwareTranslationEngine.kt`, dan perubahan di
`TranslationPipeline.kt`/`OverlayService.kt` ditulis mengikuti dokumentasi resmi Prompt API
Google (`developers.google.com/ml-kit/genai/prompt/android/get-started`) dan sudah dicek
manual (konsistensi tipe/signature antar kelas), tapi **belum pernah benar-benar di-build atau
dites di device**, baik di perangkat yang didukung AICore maupun yang tidak. Yang paling
berisiko meleset: nama-nama kelas persis dari API `com.google.mlkit:genai-prompt:1.0.0-beta2`
(mis. `Generation.getClient()`, `FeatureStatus`, `DownloadStatus`, bentuk `GenerateContentResponse.candidates`) —
API ini masih beta dan bisa saja sedikit berbeda dari dokumentasi per versi rilis yang benar-benar
ter-resolve Gradle. Kalau build gagal di baris-baris ini, cek dulu versi terbaru
`com.google.mlkit:genai-prompt` di Maven dan sesuaikan referensi kelasnya.

**Catatan kejujuran soal perubahan Phase 2 kali ini**: saya tidak bisa mengcompile atau
menjalankan project ini di sandbox saya (tanpa akses internet & Android SDK) — perubahan di atas
sudah saya cek manual (baca ulang tiap file, cek konsistensi tipe/signature antar kelas), tapi
**belum pernah benar-benar di-build atau dites di device**. Yang paling berisiko meleset kalau
ada masalah nanti: interaksi `View.OnTouchListener` untuk resize vs drag-to-move di
`OverlayService.attachDragAndResizeHandling()`, karena itu satu-satunya bagian yang bergantung
ketat pada urutan event sentuh Android yang perilakunya kadang beda-beda antar perangkat/skin
(MIUI, dsb). Kalau resize/drag terasa "nyangkut" atau kebalik di device asli, itu tempat pertama
yang perlu dicek.

## Keterbatasan penting yang perlu diketahui sebelum lanjut development

1. **`android.speech.SpeechRecognizer` tidak menerima PCM eksternal.** Ia mengelola capture
   mic-nya sendiri. Karena itu, saat ini STT hanya bisa mentranskripsi **microphone**, bukan
   system audio. `MicAudioSource` dipakai paralel murni untuk VAD (gating hemat baterai), bukan
   sebagai sumber audio bagi SpeechRecognizer. Lihat komentar detail di
   `stt/AndroidSpeechRecognizerEngine.kt`.
   Untuk mentranskripsi **system audio**, Phase 2/3 perlu STT engine yang menerima raw PCM
   langsung (mis. Vosk atau whisper.cpp via JNI) — interface `SpeechRecognizerEngine` sudah
   dirancang agar ini bisa ditukar tanpa mengubah `TranslationPipeline`.

2. **System audio capture tidak bisa menangkap audio panggilan VoIP** (WhatsApp/Telegram call)
   karena Android sengaja mengecualikan `USAGE_VOICE_COMMUNICATION` dari
   `AudioPlaybackCaptureConfiguration` demi privasi. Ini batasan platform, bukan bug. Untuk kasus
   itu, gunakan mode Microphone (tangkap dari speaker perangkat).

3. **Drag/resize/snap-to-edge pada overlay belum diimplementasikan** — placeholder ada di
   `OverlayService.showOverlayPanel()`. Ini eksplisit dijadwalkan sebagai bagian Phase 2 UX
   polish di spesifikasi.

4. **Gradle wrapper (`gradlew`) belum di-generate** karena lingkungan pembuatan project ini
   tidak punya akses internet untuk mengunduh `gradle-wrapper.jar`. Saat pertama kali dibuka di
   Android Studio, biarkan Android Studio men-generate wrapper-nya (atau jalankan
   `gradle wrapper --gradle-version 8.7` jika punya Gradle terpasang lokal).

5. **Model ML Kit (Translate & Language ID) butuh koneksi internet SEKALI di awal** untuk
   diunduh per pasangan bahasa (default lewat WiFi saja, lihat `DownloadConditions` di
   `MlKitTranslationEngine`). Setelah itu translation berjalan offline. Ini konsisten dengan
   spesifikasi "tetap dapat digunakan untuk translation dasar tanpa koneksi internet **jika
   model lokal tersedia**" — model harus terpasang dulu.

## Cara membuka project

1. Buka folder ini di Android Studio (Koala/2024.1+ direkomendasikan).
2. Biarkan Android Studio sync Gradle & generate wrapper.
3. Jalankan di perangkat fisik (emulator tidak bisa menguji overlay/system-audio dengan baik).
4. Saat pertama Start Translator, aplikasi akan meminta izin: RECORD_AUDIO, notifikasi
   (Android 13+), dan "Display over other apps" (SYSTEM_ALERT_WINDOW) — ketiganya wajib.

## Roadmap sesuai spesifikasi (§20)

- **Phase 1 (ini):** project, overlay, mic/system audio capture, VAD, STT, translation, auto
  language detection. ✅ selesai sebagai skeleton fungsional.
- **Phase 2:** streaming/partial translation yang lebih halus ✅, translation cache persist ✅,
  conversation context (dasar untuk mode SMART) ✅, drag/resize/snap overlay ✅, profiling awal
  (belum — digeser ke Phase 4, lihat catatan kejujuran di atas).
- **Phase 3 (awal, iterasi ini):** mode SMART & COPILOT sungguhan via Gemini Nano/ML Kit GenAI
  Prompt API ✅ (dengan fallback otomatis ke placeholder di perangkat tak didukung), idle→load/
  unload sesuai §6 ✅. Belum: model kecil quantized alternatif untuk perangkat yang tidak
  didukung AICore, dan belum pernah dites di device nyata sama sekali (lihat catatan kejujuran).
- **Phase 4:** RAM/CPU/battery profiling, deteksi memory leak, optimasi startup & latency.

## Prinsip yang dijaga di seluruh kode

- Tidak ada backend/VPS/database cloud/sistem login.
- Tidak ada API key yang di-hardcode di APK.
- Semua toggle (Mic, System Audio) benar-benar melepas resource saat OFF — bukan sekadar
  menyembunyikan UI.
- Fast path (audio → VAD → STT → translation → overlay) tidak pernah menunggu proses AI —
  ditegaskan lewat pemisahan `TranslationPipeline` (Phase 1) dari layer AI (Phase 3 nanti).
