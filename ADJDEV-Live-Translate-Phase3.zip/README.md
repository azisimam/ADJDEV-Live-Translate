# ADJDEV Live Translate — Phase 1 + Phase 2 + Phase 3 (awal)

Floating-overlay live translator untuk penggunaan pribadi. Native Android (Kotlin + Jetpack
Compose), local-first, tanpa backend/VPS/login/cloud database.

## ⚠️ Belum bisa langsung diinstall dari sini

Ini adalah source project, bukan APK. Sandbox pembuatan project ini tidak punya akses internet
(dibutuhkan Gradle untuk mengunduh dependency) maupun Android SDK terpasang, jadi saya tidak bisa
mengcompile APK di sisi saya. Untuk mendapatkan APK yang bisa diinstall:

1. Buka folder ini di Android Studio → Run ke device fisik via USB (paling gampang, wrapper
   Gradle akan di-generate otomatis), **atau**
2. Kalau sudah ada Gradle terpasang lokal: `gradle wrapper --gradle-version 8.7` lalu
   `./gradlew assembleDebug` → APK ada di `app/build/outputs/apk/debug/`.

### Kalau pakai IDE Gradle di HP (mis. AndroidIDE, dan sejenisnya)

Jika muncul error semacam **"Tidak ditemukan module aplikasi dalam proyek"**, dua hal yang perlu
dicek:

- **Buka folder yang BENAR sebagai project root.** Zip ini sekarang di-package rata (flat) —
  `settings.gradle.kts` ada persis di root arsip, bukan di dalam subfolder lagi. Pastikan aplikasi
  IDE-mu membuka folder hasil ekstrak zip ini langsung (yang berisi `settings.gradle.kts`,
  `build.gradle.kts`, dan folder `app/` sejajar), bukan folder di atasnya.
- **Gradle wrapper** (`gradlew`, `gradle/wrapper/gradle-wrapper.properties`) sudah saya tambahkan.
  Namun **`gradle-wrapper.jar`** (file binary bootstrap Gradle) belum ada — saya tidak punya akses
  internet untuk mengunduhnya. Kalau IDE di HP-mu butuh file ini secara eksplisit dan tidak
  auto-generate, jalankan `gradle wrapper` sekali di device tersebut (kalau ada Gradle bawaan
  aplikasinya) untuk melengkapi file jar itu, atau unduh manual dari
  `https://services.gradle.org/distributions/` sesuai versi di `gradle-wrapper.properties`.

Saya belum pernah menguji aplikasi RiSETiDEx secara spesifik, jadi kalau setelah dua perbaikan di
atas masih error yang sama, kemungkinan besar app tersebut punya persyaratan struktur project
yang lebih spesifik (mis. hanya mendukung Groovy DSL `settings.gradle`/`build.gradle`, bukan
Kotlin DSL `.kts`) — beri tahu saya pesan error persisnya dan saya bisa coba convert project ke
Groovy DSL sebagai alternatif.

## Status: Phase 1 (selesai) + Phase 2 (selesai sesuai checklist §20, minus profiling formal)

Yang sudah dibangun di skeleton ini:

- Project Android (Gradle Kotlin DSL), struktur modular sesuai spesifikasi (`audio/`, `stt/`,
  `translation/`, `detection/`, `vad/`, `overlay/`, `settings/`, `storage/`, `core/`).
- Floating overlay (panel penuh + bubble minimized) via `WindowManager` + Compose, dikelola oleh
  satu Foreground Service (`OverlayService`).
- Mic capture (`MicAudioSource`, `AudioRecord`) dengan toggle ON/OFF yang benar-benar melepas
  resource saat OFF.
- System audio capture (`SystemAudioSource`, `AudioPlaybackCaptureConfiguration`, API 29+) —
  lihat **Keterbatasan** di bawah.
- VAD berbasis energi (RMS), ringan, dipakai sebagai gate agar STT tidak selalu aktif.
- STT via `android.speech.SpeechRecognizer` (prioritas on-device jika tersedia).
- Deteksi bahasa otomatis via ML Kit Language ID (on-device).
- Terjemahan via ML Kit Translate (on-device setelah model per pasangan bahasa diunduh sekali).
- Cache terjemahan lokal (LRU, in-memory, dibatasi ukurannya).
- Settings lokal via DataStore (bukan cloud, tidak ada login).
- UI utama sesuai spesifikasi §13 (status, input toggle, mode selector, Start/Stop).

Tambahan Phase 2 yang sudah masuk:

- **Overlay draggable + snap-to-edge**: `OverlayService.attachDragHandling()` — geser panel,
  lepas, otomatis nempel ke tepi kiri/kanan layar terdekat dengan animasi singkat.
- **Translation cache persist**: `TranslationCache` sekarang menulis ke DataStore di background
  (tidak memblokir fast path) sehingga cache frasa bertahan lintas restart aplikasi.
- **Conversation context buffer** (`conversation/ConversationContextStore.kt`): menyimpan N
  turn percakapan terakhir (dibatasi ketat sesuai setting `contextMessageLimit`), sebagai
  dasar untuk mode SMART di Phase 3. Tombol **Clear Conversation** sudah aktif di overlay.
- **Fix crash saat mulai bicara**: `SpeechRecognizer` sebelumnya dibuat di background thread
  (Dispatchers.Default, tanpa Looper) → crash. Sekarang sesi STT dijalankan di `Dispatchers.Main`.
- **Fix crash saat Start Translator**: foreground service sebelumnya mendeklarasikan tipe
  `mediaProjection` tanpa pernah meminta izin `MediaProjectionManager` → SecurityException di
  Android 14+. Sekarang service start dengan tipe `microphone` saja; System Audio dinonaktifkan
  sementara di UI sampai alur permintaan izinnya benar-benar dibangun.
- **Fix "tidak ada teks muncul" saat bicara**: `MicAudioSource` (untuk VAD) dan
  `android.speech.SpeechRecognizer` (untuk STT) sebelumnya sama-sama coba akses mic secara
  bersamaan — di banyak perangkat ini bikin SpeechRecognizer gagal dapat audio secara diam-diam
  (`onError` cuma `close()` tanpa pesan apa pun). Sekarang: VAD custom tidak dipakai lagi untuk
  gating mic; `TranslationPipeline` menjalankan sesi SpeechRecognizer berulang (auto-restart),
  dan `onError` sekarang membedakan error normal (hening/timeout, diam-diam restart) dari error
  yang perlu terlihat user (mic direbut app lain, izin dicabut, dll — muncul di overlay).
  `EnergyVadEngine`/`MicAudioSource` tetap ada di codebase untuk dipakai STT engine berbasis
  raw-PCM (Vosk/whisper.cpp) nanti yang bisa berbagi satu AudioRecord tap tanpa konflik.
- **Streaming/partial translation lebih halus** (`TranslationPipeline.schedulePartialTranslation`):
  sebelumnya, selagi user masih bicara, overlay cuma menampilkan teks sumber mentah (belum
  diterjemahkan) — terjemahan baru muncul setelah SpeechRecognizer menandai hasil sebagai final.
  Sekarang teks partial juga diterjemahkan secara live, di-debounce 400ms (dan diabaikan kalau
  < 2 karakter) supaya tidak memanggil translation engine di setiap perubahan huruf. Job partial
  ini dibatalkan begitu ada partial baru atau transcript final datang, dan kegagalannya diam-diam
  saja — hasil FINAL dari `handleFinalTranscript()` tetap satu-satunya sumber kebenaran, fast
  path tidak pernah menunggu proses ini. Overlay membedakan visualnya lewat warna teks yang
  sedikit diredupkan selama partial (`OverlayScreen.kt`).
- **Resize overlay via gesture** (`OverlayService.attachDragAndResizeHandling`): panel sekarang
  bisa diperlebar/dipersempit dengan menyeret kotak kecil di pojok kanan-bawah (ikon
  "resize" transparan), dibatasi 220–400dp dan dipersist ke DataStore (`overlay_width`) lintas
  restart. Drag-to-resize dan drag-to-move ditangani dalam SATU `View.OnTouchListener` yang sama
  (bukan `pointerInput` Compose terpisah di dalam handle) — kalau dipisah, `ACTION_MOVE` untuk
  resize bisa "kerebut" duluan oleh logika drag-to-move begitu melewati touch slop. Titik awal
  sentuhan dicek dulu terhadap area kotak resize (`RESIZE_HANDLE_DP`) sebelum menentukan mode
  (`PENDING_RESIZE` vs `PENDING_MOVE`) untuk sesi sentuh tersebut.

## Fix build CI: Kotlin 1.9.24 tidak cocok dengan dependency GenAI Prompt Phase 3

Build GitHub Actions (`build-apk.yml`) gagal di `compileDebugKotlin` dengan pesan
*"Module was compiled with an incompatible version of Kotlin. The binary version of its
metadata is 2.2.0, expected version is 1.9.0"*. Penyebabnya: `com.google.mlkit:genai-prompt:1.0.0-beta2`
dan `com.google.mlkit:genai-common:1.0.0-beta3` (ditambahkan untuk Phase 3 di atas) dirilis
Google dengan metadata Kotlin **2.2.0**, sementara project ini masih memakai Kotlin **1.9.24**
— compiler 1.9.x cuma bisa membaca metadata sampai 2.0.0.

**Perbaikan** (`build.gradle.kts` root + `app/build.gradle.kts`):
- Kotlin plugin dinaikkan dari `1.9.24` -> `2.2.0`.
- Sejak Kotlin 2.0+, compiler Compose tidak lagi dibundel lewat
  `composeOptions.kotlinCompilerExtensionVersion` (mekanisme lama, K1-only) — sekarang wajib
  lewat plugin Gradle terpisah `org.jetbrains.kotlin.plugin.compose`, ditambahkan dengan versi
  yang sama (`2.2.0`). Blok `composeOptions` lama dihapus dari `app/build.gradle.kts`.
- AGP (`8.5.2`) dan Gradle wrapper (`8.7`) TIDAK diubah — keduanya sudah kompatibel dengan
  Kotlin 2.2.

**Catatan kejujuran**: perbaikan ini didasarkan pada pesan error CI yang dilaporkan persis
(bukan ditebak), tapi tetap belum pernah dicoba build ulang oleh saya sendiri (sandbox saya
tidak punya internet untuk resolve dependency Gradle). Kalau CI berikutnya masih gagal di
`compileDebugKotlin` tapi dengan error BERBEDA (mis. soal K2 strict-mode di kode Compose lama),
itu kemungkinan efek samping lompatan K1->K2 yang belum ketahuan dari sini — laporkan pesan
errornya, itu paling cepat untuk didiagnosis lebih lanjut daripada saya menebak.



**Bug diperbaiki dulu**: error *"Translation model files not found. Make sure to call
downloadModelIfNeeded..."* yang muncul saat Start Translator disebabkan `TranslationPipeline`
memanggil `translationEngine.translate()` langsung tanpa pernah memanggil
`ensureModelDownloaded()` lebih dulu — jadi ML Kit selalu gagal karena model untuk pasangan
bahasa itu belum terunduh. Sekarang `handleFinalTranscript()` dan
`schedulePartialTranslation()` di `TranslationPipeline.kt` memastikan model terunduh dulu
sebelum menerjemahkan. Sekalian: `MlKitTranslationEngine` sebelumnya mensyaratkan `.requireWifi()`
untuk unduhan model, yang bikin proses unduh menggantung tanpa sukses/gagal kalau device sedang
di data seluler — sekarang syarat itu dilepas.

**SMART dan COPILOT sekarang benar-benar memakai model AI on-device** (bukan lagi placeholder
rule-based / context yang cuma dicatat tanpa dipakai), lewat **Gemini Nano** via
**ML Kit GenAI Prompt API** (`com.google.mlkit:genai-prompt`, diakses lewat AICore bawaan
Android):

- **`ai/GeminiNanoCopilotEngine.kt`**: implementasi `AIEngine` sungguhan untuk COPILOT — 3
  saran balasan dihasilkan oleh model generatif, bukan rule-based lagi.
- **`translation/ContextAwareTranslationEngine.kt`**: implementasi `TranslationEngine` untuk
  SMART — `translateWithContext()` mengirim beberapa giliran percakapan terakhir sebagai bagian
  prompt ke Gemini Nano, sesuatu yang **tidak bisa** dilakukan ML Kit Translate biasa (NMT
  klasik, satu kalimat berdiri sendiri, tanpa context injection). Mode LIGHT/COPILOT tetap
  memakai `translate()` ML Kit biasa seperti sebelumnya — SMART-lah satu-satunya yang lewat
  jalur ini, sesuai kontrak baru `translateWithContext()` di `TranslationEngine`.
- **`ai/FallbackCopilotEngine.kt`**: composite — coba Gemini Nano dulu, otomatis & permanen
  (untuk sesi translator berjalan) pindah ke `PlaceholderCopilotEngine` lama kalau
  `checkStatus()` mengembalikan `UNAVAILABLE` atau `load()` gagal apa pun. Jadi COPILOT tidak
  pernah mati total di perangkat yang belum didukung — cuma turun ke rule-based seperti Phase 2.
- AI Path tetap terpisah dari Fast Path (spesifikasi §11): translation tampil dulu di overlay,
  suggested replies menyusul di coroutine terpisah — tidak berubah dari Phase 2.

### ⚠️ Batasan penting Gemini Nano / ML Kit GenAI Prompt API

- **Beta/alpha per dokumentasi resmi Google (Jan 2026)**, hanya jalan di perangkat yang
  didukung **AICore** — sebagian besar flagship 2024+ (Pixel 9/10, Galaxy S25/S26, sebagian
  Oppo/Honor/Poco terbaru; lihat daftar resmi ML Kit GenAI, berubah dari waktu ke waktu).
  **Perangkat target awal spesifikasi (kelas menengah, mis. Redmi Note 13 4G) kemungkinan
  besar TIDAK termasuk** — di perangkat itu `checkStatus()` akan `UNAVAILABLE` dan SMART/COPILOT
  otomatis berperilaku sama seperti Phase 2 (fallback), **bukan bug**.
- **Tidak didukung di perangkat dengan bootloader unlocked** (batasan resmi AICore).
- Model Gemini Nano jauh lebih besar dari model ML Kit Translate (~30MB). Sengaja **tidak**
  dipicu unduh otomatis diam-diam di `ContextAwareTranslationEngine` untuk menghindari
  menghabiskan kuota data user tanpa izin — kalau status device `DOWNLOADABLE` (belum
  terunduh), SMART untuk sesi itu berperilaku seperti fallback sampai fitur benar-benar
  `AVAILABLE`. `GeminiNanoCopilotEngine.load()` (dipicu saat masuk mode COPILOT) memang memicu
  unduh sekali kalau `DOWNLOADABLE` — pertimbangkan menambah dialog konfirmasi user sebelum ini
  di iterasi berikutnya kalau ukurannya jadi masalah.
- Input dibatasi ~4000 token per request (cukup untuk prompt translasi/saran balasan single-turn
  seperti di sini, jadi tidak jadi masalah praktis).

**Yang masih placeholder / belum real setelah Phase 3 ini**, supaya jelas:
- Profiling RAM/CPU/baterai formal: belum ada — dijadwalkan Phase 4.
- Opacity overlay: setting `overlay_opacity` sudah ada di `SettingsRepository` tapi belum ada
  UI slider maupun diterapkan ke alpha panel.
- Di perangkat yang TIDAK didukung AICore (kemungkinan besar mayoritas target awal), SMART
  kembali sama seperti Phase 2 (fallback ML Kit Translate biasa) — belum ada alternatif model
  kecil quantized (MediaPipe LLM Inference/llama.cpp) untuk perangkat kelas menengah. COPILOT
  di perangkat seperti ini TIDAK lagi sekadar placeholder statis — lihat bagian
  "Copilot rule-based" di bawah.

## Copilot rule-based sekarang context-aware (bukan lagi placeholder statis)

Karena AICore/Gemini Nano hanya jalan di sebagian flagship, `PlaceholderCopilotEngine`
(fallback COPILOT lewat `FallbackCopilotEngine`) BUKAN jalur langka — di kebanyakan perangkat
kelas menengah (termasuk target spesifikasi awal, Redmi Note 13 4G) ini adalah jalur yang
HAMPIR SELALU aktif. Sebelumnya engine ini cuma mengembalikan 3 baris tetap ("Oke, dimengerti."
/ "Boleh diulang sedikit?" / "Baik, saya catat.") terlepas dari isi obrolan — itu yang muncul di
screenshot awal.

`ai/PlaceholderCopilotEngine.kt` ditulis ulang jadi heuristik teks (bukan model generatif, tapi
juga bukan template statis):
- Deteksi kasar jenis kalimat lawan bicara — sapaan, terima kasih, pamit, pertanyaan ya/tidak,
  pertanyaan 5W1H, atau pernyataan biasa (mendukung ID & EN, karena teks yang masuk sudah hasil
  terjemahan ke salah satu arah).
- Menarik "kata kunci topik" dari kalimat + 1–2 giliran terakhir di `recentContext`, supaya
  saran bisa menyinggung isi obrolan, bukan generik.
- Memilih dari beberapa pool variasi kalimat via `Random`, jadi tidak berulang kata yang sama
  persis tiap kali suggested replies muncul.
- Selalu menyertakan SATU saran "tanya balik" (pertanyaan lanjutan relevan) selain jawaban
  singkat & tanggapan natural — sebelumnya cuma ada 3 gaya jawaban searah.

`ai/GeminiNanoCopilotEngine.kt` (jalur AICore sungguhan) prompt-nya juga disamakan gayanya:
diminta eksplisit menghasilkan 1 jawaban langsung + 1 tanggapan natural + 1 pertanyaan balik,
bukan lagi "3 nada berbeda" generik.

Ini tetap BUKAN AI generatif — kalau nanti ada model kecil quantized on-device
(MediaPipe LLM Inference/llama.cpp) untuk perangkat non-AICore, itu upgrade berikutnya yang
belum dikerjakan.

## System Audio: alur izin MediaProjection sekarang sudah di-wire — dengan satu gap penting

Sebelumnya toggle System Audio dinonaktifkan total di UI karena dialog izin
`MediaProjectionManager` belum diimplementasikan. Sekarang:

- Toggle **System Audio** di `MainActivity` aktif (kalau `SystemAudioSource.isSupported`,
  yaitu Android 10/Q+).
- Saat **Start Translator** ditekan dengan toggle ini ON, `projectionManager.createScreenCaptureIntent()`
  dipicu lewat `ActivityResultContracts.StartActivityForResult` — dialog sistem "mulai
  merekam/menampilkan" muncul (ini teks bawaan Android untuk API MediaProjection, tidak bisa
  dikustomisasi lewat app).
- Kalau user setuju (`RESULT_OK`), `resultCode` + `data` Intent diteruskan ke `OverlayService`
  lewat extras (`EXTRA_PROJECTION_RESULT_CODE` / `EXTRA_PROJECTION_DATA`) saat `ACTION_START` —
  BUKAN disimpan lintas proses, karena token ini cuma valid sekali pakai per grant. Service lalu
  benar-benar membuat `MediaProjection` sendiri lewat `MediaProjectionManager.getMediaProjection()`,
  mendaftarkan `MediaProjection.Callback` (wajib di Android 10+, kalau tidak bisa
  Security/IllegalStateException), dan mendeklarasikan tipe foreground service `mediaProjection`
  HANYA saat token itu benar-benar ada di tangan (syarat Android 14+).
- Kalau user menolak dialognya, translator tetap jalan dengan Microphone saja dan toggle System
  Audio otomatis dimatikan kembali untuk sesi itu (`viewModel.setSystemAudioOn(false)`).
- `SystemAudioSource` (`audio/SystemAudioSource.kt`) sendiri isinya SUDAH ADA sejak sebelumnya
  dan tidak diubah — yang hilang murni alur permintaan izinnya, yang sekarang sudah lengkap:
  request izin → buat MediaProjection → capture AudioRecord → cleanup (`MediaProjection.stop()`
  + `unregisterCallback()`) saat translator dimatikan ATAU kalau user mencabut izin capture
  lewat notifikasi sistem di tengah jalan (`projectionCallback.onStop()` di `OverlayService`).

**Gap yang masih terbuka, dan ini penting untuk ekspektasi**: capture audio-nya sekarang BENAR
berjalan (bukan simulasi), tapi **belum ada langkah transkripsi untuk audio ini**. Alasannya
sama seperti keterbatasan #1 di bawah: `android.speech.SpeechRecognizer` yang dipakai untuk mode
Microphone TIDAK BISA menerima PCM eksternal — dia cuma bisa mendengar dari mic-nya sendiri,
bukan dari `AudioRecord` manapun yang kita buat sendiri. Jadi:
- `TranslationPipeline.startSystemAudio()` sekarang benar-benar men-drain `AudioChunk` dari
  `SystemAudioSource` (menjaga capture tetap hidup & bisa diobservasi lewat
  `state.systemAudioOn`), tapi isi audionya belum diproses jadi teks — ada `TODO` eksplisit
  di baris itu.
- Overlay (`OverlayScreen.kt`) menampilkan indikator jujur: *"System Audio aktif (menangkap
  audio, transkrip belum tersedia)"* — bukan pura-pura menampilkan hasil terjemahan yang tidak
  akan pernah muncul dari sumber ini.
- Untuk benar-benar mentranskripsi system audio, dibutuhkan STT berbasis PCM (Vosk atau
  whisper.cpp via JNI, seperti disebut di keterbatasan #1) yang menerima `Flow<AudioChunk>`
  langsung — ini pekerjaan terpisah yang lebih besar (model offline + binding native), belum
  dikerjakan di iterasi ini.
- Untuk kebutuhan translate suara lawan bicara di panggilan video/suara SEKARANG, tetap pakai
  mode Microphone + loudspeaker (sudah berjalan, tidak terpengaruh perubahan ini) — perlu
  diingat juga `AudioPlaybackCaptureConfiguration` memang sengaja mengecualikan audio VoIP
  (`USAGE_VOICE_COMMUNICATION`) demi privasi, jadi System Audio tidak akan pernah menangkap
  panggilan meski STT-nya sudah ada nanti.

**Catatan kejujuran**: sama seperti bagian Gemini Nano di atas, kode alur izin ini ditulis
mengikuti dokumentasi resmi `MediaProjectionManager`/`AudioPlaybackCaptureConfiguration` dan
dicek konsistensi manual, tapi **belum pernah dites di device nyata** (sandbox pembuatan tidak
punya Android SDK/device). Bagian paling berisiko meleset: urutan `registerCallback()` sebelum
`AudioRecord.Builder().setAudioPlaybackCaptureConfig()` di beberapa versi OS/skin (MIUI dkk)
kadang punya kuirk tambahan soal timing izin — kalau dialog sistem muncul tapi capture tetap
gagal setelah `RESULT_OK`, itu tempat pertama yang perlu dicek, dan pesan error dari
`SystemAudioSource` (sudah ada exception handling-nya) akan muncul di `state.errorMessage`
overlay untuk membantu diagnosis.


**Catatan kejujuran Phase 3**: sama seperti Phase 1/2, saya tidak bisa mengcompile atau
menjalankan project ini di sandbox saya (tanpa akses internet & Android SDK) — kode di
`GeminiNanoCopilotEngine.kt`, `ContextAwareTranslationEngine.kt`, dan perubahan di
`TranslationPipeline.kt`/`OverlayService.kt` ditulis mengikuti dokumentasi resmi Prompt API
Google (`developers.google.com/ml-kit/genai/prompt/android/get-started`) dan sudah dicek
manual (konsistensi tipe/signature antar kelas), tapi **belum pernah benar-benar di-build atau
dites di device**, baik di perangkat yang didukung AICore maupun yang tidak. Yang paling
berisiko meleset: nama-nama kelas persis dari API `com.google.mlkit:genai-prompt:1.0.0-beta2`
(mis. `Generation.getClient()`, `FeatureStatus`, `DownloadStatus`, bentuk `GenerateContentResponse.candidates`) —
API ini masih beta dan bisa saja sedikit berbeda dari dokumentasi per versi rilis yang benar-benar
ter-resolve Gradle. Kalau build gagal di baris-baris ini, cek dulu versi terbaru
`com.google.mlkit:genai-prompt` di Maven dan sesuaikan referensi kelasnya.

**Catatan kejujuran soal perubahan Phase 2 kali ini**: saya tidak bisa mengcompile atau
menjalankan project ini di sandbox saya (tanpa akses internet & Android SDK) — perubahan di atas
sudah saya cek manual (baca ulang tiap file, cek konsistensi tipe/signature antar kelas), tapi
**belum pernah benar-benar di-build atau dites di device**. Yang paling berisiko meleset kalau
ada masalah nanti: interaksi `View.OnTouchListener` untuk resize vs drag-to-move di
`OverlayService.attachDragAndResizeHandling()`, karena itu satu-satunya bagian yang bergantung
ketat pada urutan event sentuh Android yang perilakunya kadang beda-beda antar perangkat/skin
(MIUI, dsb). Kalau resize/drag terasa "nyangkut" atau kebalik di device asli, itu tempat pertama
yang perlu dicek.

## Copilot tier 2: model AI lokal via LiteRT-LM (opsional, RAM-berat)

Ditambahkan atas pilihan eksplisit user (paham risikonya): rantai fallback COPILOT sekarang
3 tingkat, bukan 2.

1. **Gemini Nano/AICore** (`GeminiNanoCopilotEngine`) — device flagship yang didukung.
2. **BARU — LiteRT-LM lokal** (`LocalLlmCopilotEngine` + `ai/local/LocalLlmModelManager.kt`) —
   model kecil quantized (rekomendasi: Gemma3-1B-IT, ~529MB int4) berjalan sendiri di device,
   dipakai kalau tingkat 1 tidak didukung TAPI user sudah **import model .litertlm manual**
   lewat tombol "Import Model" di layar utama (document picker, `ACTION_OPEN_DOCUMENT`).
3. **Rule-based** (`PlaceholderCopilotEngine`) — jaring pengaman terakhir, selalu berhasil.

**Kenapa model tidak di-download otomatis oleh app**: model Gemma di HuggingFace LiteRT
Community ada di belakang halaman lisensi yang butuh login & klik "Agree" — URL download-nya
per-akun, tidak bisa di-hardcode tanpa menyimpan kredensial user di APK (melanggar prinsip
"no API key hardcoded", spesifikasi §6). User download sendiri lewat Chrome dari
`huggingface.co/litert-community`, lalu import file-nya lewat tombol di app.

**Kenapa dipakai LiteRT-LM, bukan MediaPipe LLM Inference API**: per pengecekan dokumentasi
resmi Google Agustus 2026, MediaPipe LLM Inference API untuk Android sudah **deprecated**
(maintenance-only sejak Maret 2026) — Google resmi menyarankan migrasi ke LiteRT-LM
(`com.google.ai.edge.litertlm`) sebagai penerusnya.

**Trade-off yang perlu diketahui** (sudah dikonfirmasi ke user sebelum dikerjakan):
- Ukuran download besar (500MB+), tidak dibundel ke APK.
- **Berat untuk RAM 4GB** (target spesifikasi: Redmi Note 13 4G) — apalagi kalau berjalan
  bersamaan dengan foreground service + model ML Kit + model Vosk. Realistis: bisa lambat
  (beberapa detik per saran) atau gagal ter-load kalau RAM sedang penuh.
  `generateSuggestions()` dibungkus timeout 12 detik supaya gagal dengan rapi (list kosong,
  otomatis tidak menampilkan Suggested Replies untuk giliran itu) — bukan nge-freeze overlay.
- `build.gradle.kts` dinaikkan dari Java 17 ke **Java 21** (`sourceCompatibility`,
  `targetCompatibility`, `kotlinOptions.jvmTarget`) karena laporan komunitas soal
  `litertlm-android` butuh class file Java 21 pada sebagian versi. Workflow GitHub Actions
  (`.github/workflows/build-apk.yml`) juga sudah disesuaikan ke JDK 21 — **kalau kamu build di
  Android Studio lokal, pastikan JDK project-nya juga 21**, bukan 17.
- **CATATAN KEJUJURAN**: `LocalLlmCopilotEngine` ditulis mengikuti dokumentasi resmi LiteRT-LM
  Kotlin API per Mei 2026, belum pernah dikompilasi/dites di device nyata (tidak ada Android
  SDK/internet untuk build asli di sandbox pembuatan kode ini). Kalau ada error compile atau
  crash saat load model, itu titik pertama yang perlu dicek manual — kirim stack trace-nya.

Kalau ternyata device kamu tetap kepayahan setelah dicoba: hapus model lewat tombol "Hapus" di
app (kembali otomatis ke rule-based, tanpa perlu uninstall/reinstall apa pun).

## Update 23 Agustus 2026 (lanjutan) — Model AI Lokal DIHAPUS, Remote AI dirapikan

Setelah percobaan model lokal (LiteRT-LM) terbukti crash native di device nyata (lihat laporan
di bawah) DAN device target tetap kelas menengah/RAM 4GB, keputusan akhir: **tier Model AI
Lokal dihapus total** dari codebase (`LocalLlmCopilotEngine.kt`, `ai/local/` package, dependency
`litertlm-android`, toggle & UI import model — semua dihapus, bukan cuma dinonaktifkan).

Rantai COPILOT sekarang **2 tingkat + rule-based**:
1. **Gemini Nano/AICore** (`GeminiNanoCopilotEngine`) — device flagship yang didukung.
2. **Remote AI / VPS pribadi** (`RemoteCopilotEngine`) — server LLM di VPS milik user sendiri,
   endpoint OpenAI-compatible `/v1/chat/completions`. Ini pengganti model lokal untuk device
   kelas menengah: komputasi berat pindah ke VPS, HP cuma kirim/terima teks pendek lewat HTTP.
3. **Rule-based** (`PlaceholderCopilotEngine`) — jaring pengaman terakhir.

**Perbaikan kualitas/kecepatan Remote AI** (berdasar laporan respons lambat & saran cuma
muncul 1 dari 3):
- `max_tokens` dinaikkan 120 → 220 (dugaan kuat: 120 kepotong sebelum model sempat nulis 3 baris
  penuh, apalagi kalau ada sedikit kalimat pembuka meski sudah dilarang).
- System prompt dipertegas: eksplisit melarang kalimat pembuka/penutup.
- Ditambah catatan tuning sisi VPS di `RemoteCopilotEngine.kt` (kalau pakai Ollama):
  `OLLAMA_KEEP_ALIVE=-1` supaya model tidak di-unload dari RAM tiap idle 5 menit (kemungkinan
  besar inilah penyebab utama "respons lambat" — request pertama setelah jeda harus reload
  model dulu sebelum mulai generate), pakai model sekecil mungkin (mis. `qwen2.5:0.5b-instruct`
  atau `llama3.2:1b-instruct-q4_K_M`) karena VPS 2 core CPU-only jauh lebih lambat dari GPU.

**Layar Pengaturan terpisah**: konfigurasi Remote AI (URL, API Key, Nama Model) dipindah dari
layar utama ke `SettingsScreen` baru, dibuka lewat ikon ⚙️ di header `MainScreen` — supaya
layar utama tetap ringkas.

**Versioning & signing supaya update tidak perlu uninstall**:
- Root cause kenapa tiap install harus uninstall dulu: `versionCode` statis (`1`) DAN GitHub
  Actions men-generate debug keystore baru tiap run (tanda tangan APK beda tiap build →
  Android anggap app berbeda).
- Fix: keystore TETAP di-commit ke repo (`keystore/adjdev-debug.keystore`), dipakai eksplisit
  lewat `signingConfigs` di `app/build.gradle.kts` untuk build type `debug` MAUPUN `release`.
  `versionCode` sekarang dibaca dari env var `BUILD_VERSION_CODE` (di-set workflow ke
  `github.run_number`, selalu naik tiap run). Hasilnya: install APK baru dari Artifacts akan
  otomatis jadi **Update**, bukan minta uninstall dulu — asal APK lama juga sudah dari build
  dengan keystore tetap ini (build lama sebelum perubahan ini tetap perlu SEKALI uninstall
  manual sebagai migrasi awal, setelah itu update seterusnya lancar).
- ⚠️ Keystore ini cuma untuk instal pribadi/testing (bukan untuk Play Store — kalau nanti mau
  publish ke Play Store, buat keystore rilis terpisah yang TIDAK di-commit ke repo publik).

## Keterbatasan penting yang perlu diketahui sebelum lanjut development

1. **`android.speech.SpeechRecognizer` tidak menerima PCM eksternal.** Ia mengelola capture
   mic-nya sendiri. Karena itu, STT hanya bisa mentranskripsi **microphone**, bukan
   system audio — walau capture-nya sendiri (`SystemAudioSource`) sekarang benar-benar aktif
   lewat alur izin MediaProjection yang sudah di-wire (lihat bagian "System Audio" di atas).
   `MicAudioSource` dipakai paralel murni untuk VAD (gating hemat baterai), bukan
   sebagai sumber audio bagi SpeechRecognizer. Lihat komentar detail di
   `stt/AndroidSpeechRecognizerEngine.kt`.
   Untuk mentranskripsi **system audio**, dibutuhkan STT engine yang menerima raw PCM
   langsung (mis. Vosk atau whisper.cpp via JNI) — interface `SpeechRecognizerEngine` sudah
   dirancang agar ini bisa ditukar tanpa mengubah `TranslationPipeline`, dan
   `TranslationPipeline.startSystemAudio()` sudah menyediakan titik masuk `Flow<AudioChunk>`
   yang tinggal disambung begitu engine itu ada.

2. **System audio capture tidak bisa menangkap audio panggilan VoIP** (WhatsApp/Telegram call)
   karena Android sengaja mengecualikan `USAGE_VOICE_COMMUNICATION` dari
   `AudioPlaybackCaptureConfiguration` demi privasi. Ini batasan platform, bukan bug. Untuk kasus
   itu, gunakan mode Microphone (tangkap dari speaker perangkat).

3. **Drag/resize/snap-to-edge pada overlay belum diimplementasikan** — placeholder ada di
   `OverlayService.showOverlayPanel()`. Ini eksplisit dijadwalkan sebagai bagian Phase 2 UX
   polish di spesifikasi.

4. **Gradle wrapper (`gradlew`) belum di-generate** karena lingkungan pembuatan project ini
   tidak punya akses internet untuk mengunduh `gradle-wrapper.jar`. Saat pertama kali dibuka di
   Android Studio, biarkan Android Studio men-generate wrapper-nya (atau jalankan
   `gradle wrapper --gradle-version 8.7` jika punya Gradle terpasang lokal).

5. **Model ML Kit (Translate & Language ID) butuh koneksi internet SEKALI di awal** untuk
   diunduh per pasangan bahasa (default lewat WiFi saja, lihat `DownloadConditions` di
   `MlKitTranslationEngine`). Setelah itu translation berjalan offline. Ini konsisten dengan
   spesifikasi "tetap dapat digunakan untuk translation dasar tanpa koneksi internet **jika
   model lokal tersedia**" — model harus terpasang dulu.

## Cara membuka project

1. Buka folder ini di Android Studio (Koala/2024.1+ direkomendasikan).
2. Biarkan Android Studio sync Gradle & generate wrapper.
3. Jalankan di perangkat fisik (emulator tidak bisa menguji overlay/system-audio dengan baik).
4. Saat pertama Start Translator, aplikasi akan meminta izin: RECORD_AUDIO, notifikasi
   (Android 13+), dan "Display over other apps" (SYSTEM_ALERT_WINDOW) — ketiganya wajib.

## Roadmap sesuai spesifikasi (§20)

- **Phase 1 (ini):** project, overlay, mic/system audio capture, VAD, STT, translation, auto
  language detection. ✅ selesai sebagai skeleton fungsional.
- **Phase 2:** streaming/partial translation yang lebih halus ✅, translation cache persist ✅,
  conversation context (dasar untuk mode SMART) ✅, drag/resize/snap overlay ✅, profiling awal
  (belum — digeser ke Phase 4, lihat catatan kejujuran di atas).
- **Phase 3 (lanjutan, iterasi ini):** mode SMART & COPILOT sungguhan via Gemini Nano/ML Kit
  GenAI Prompt API ✅ (dengan fallback rule-based yang sekarang context-aware, bukan lagi
  template statis, di perangkat tak didukung AICore — lihat "Copilot rule-based" di atas), idle→
  load/unload sesuai §6 ✅. Alur izin MediaProjection untuk System Audio ✅ (capture aktif),
  transkripsi audio dari sumber ini masih terbuka (lihat "System Audio" di atas). Belum: model
  kecil quantized alternatif untuk perangkat yang tidak didukung AICore, dan belum pernah dites
  di device nyata sama sekali (lihat catatan kejujuran).
- **Phase 4:** RAM/CPU/battery profiling, deteksi memory leak, optimasi startup & latency.

## Prinsip yang dijaga di seluruh kode

- Tidak ada backend/VPS/database cloud/sistem login WAJIB untuk fitur inti (translate, STT,
  overlay) — semuanya tetap 100% on-device. SATU pengecualian opt-in: RemoteCopilotEngine
  (lihat bawah) mengirim transcript ke VPS PRIBADI MILIK USER kalau URL-nya diisi sendiri di
  Settings — bukan cloud pihak ketiga, dan defaultnya kosong/tidak dipakai.
- Tidak ada API key pihak ketiga yang di-hardcode di APK (API key VPS pribadi di
  RemoteCopilotEngine, kalau diisi, disimpan lokal di DataStore milik user sendiri).
- Semua toggle (Mic, System Audio) benar-benar melepas resource saat OFF — bukan sekadar
  menyembunyikan UI.
- Fast path (audio → VAD → STT → translation → overlay) tidak pernah menunggu proses AI —
  ditegaskan lewat pemisahan `TranslationPipeline` (Phase 1) dari layer AI (Phase 3).

## Update 23 Agustus 2026 — laporan crash dari device nyata (Redmi, RAM 4GB)

Model lokal (LiteRT-LM, Gemma3-1B-IT int4) yang diimpor & dites langsung di device nyata
menyebabkan **crash native total** (`SIGSEGV` di `liblitertlm_jni.so`) saat `generateSuggestions()`
dipanggil — bukan exception Kotlin, jadi `try/catch`/`withTimeoutOrNull` yang sudah ada di
`LocalLlmCopilotEngine` TIDAK bisa mencegahnya (native crash membawa turun seluruh proses app
sebelum Kotlin sempat menangani apa pun). Perubahan sebagai respons:

- **`LocalLlmCopilotEngine` sekarang OPT-IN** (default OFF), dikontrol lewat toggle baru di
  Settings > Model AI Lokal. Sebelumnya otomatis dicoba sebagai fallback tier begitu AICore
  tidak didukung — itulah yang bikin crash muncul tanpa peringatan. Sekarang device tanpa
  AICore & tanpa toggle ini otomatis skip ke tier berikutnya (rule-based, atau Remote kalau
  dikonfigurasi), TIDAK auto-mencoba model lokal lagi.
- **`RemoteCopilotEngine` (baru)**: tier COPILOT yang manggil server LLM di VPS PRIBADI milik
  user sendiri lewat endpoint OpenAI-compatible `/v1/chat/completions` (kompatibel llama.cpp
  server, Ollama, vLLM, dsb — lihat komentar lengkap di file-nya). Cocok untuk device kelas
  menengah yang tidak kuat menjalankan model lokal: kualitas suggested replies tidak dibatasi
  RAM HP, tapi transcript ikut lewat jaringan ke VPS tersebut (bukan lagi murni on-device) —
  makanya opt-in, field URL kosong berarti tier ini dilewati. Diimplementasikan pakai
  `HttpURLConnection` + `org.json` bawaan Android (tidak menambah dependency baru). **Belum
  pernah dites ke server sungguhan** (sandbox pembuatan kode ini tidak ada akses jaringan) —
  skema request/response OpenAI Chat Completions standar, tapi kalau server kamu punya skema
  custom, cek dulu di sana sebelum menyalahkan kode Android-nya.
- **`FallbackCopilotEngine` di-refactor** dari primary/secondary/fallback tetap (2 tier +
  fallback) jadi `tiers: List<AIEngine>` terurut (sekarang 3 tier + fallback: AICore → Remote →
  Local-opt-in → rule-based), supaya nambah/hapus tier ke depan tidak perlu ubah constructor-nya
  lagi.
- **UI dirapikan**: paragraf penjelasan panjang yang sebelumnya nempel di alur utama
  `MainActivity` (bikin scroll sangat panjang) dipindah ke dialog di balik ikon `?` (help) di
  pojok kanan atas header. Alur utama sekarang cuma kontrol + hint sebaris pendek.
- **Belum dikerjakan** (kalau crash ini masih muncul lagi di kasus lain nanti): isolasi proses
  sungguhan untuk `LocalLlmCopilotEngine` (mis. jalankan di Service terpisah lewat
  `android:process=":copilot"` + Messenger IPC) supaya native crash di situ tidak membawa turun
  seluruh foreground service/overlay — opt-in toggle di atas adalah mitigasi pragmatis (jangan
  auto-jalan), bukan perbaikan struktural itu sendiri. Kalau device kamu tetap ingin coba model
  lokal dan crash ini masih terasa mengganggu, kabari saya untuk lanjut ke perbaikan itu.

