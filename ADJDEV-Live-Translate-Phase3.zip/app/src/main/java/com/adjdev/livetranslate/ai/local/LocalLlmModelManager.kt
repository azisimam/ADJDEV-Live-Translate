package com.adjdev.livetranslate.ai.local

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Model .litertlm TIDAK diunduh otomatis oleh app ini — beda dari Vosk (VoskModelManager)
 * yang bisa diunduh dari URL publik langsung. Model Gemma di HuggingFace LiteRT Community
 * umumnya di belakang halaman lisensi (butuh login HuggingFace & klik "Agree" sekali), jadi
 * URL download-nya per-akun/bertanda-tangan — tidak bisa di-hardcode di sini tanpa menyimpan
 * kredensial pengguna di APK (melanggar prinsip "no API key di-hardcode", spesifikasi §6).
 *
 * Alurnya: user download file .litertlm sendiri lewat browser HP (mis. Chrome, sudah kepakai
 * di project ini sebelumnya) dari halaman model yang mereka pilih, lalu "Import" lewat
 * document picker (ACTION_OPEN_DOCUMENT) di MainActivity — file-nya di-copy ke penyimpanan
 * privat app (filesDir), tidak butuh izin storage tambahan.
 */
class LocalLlmModelManager(private val context: Context) {

    companion object {
        const val MODEL_FILE_NAME = "local-llm-model.litertlm"
        // Rekomendasi default: Gemma3-1B-IT versi CPU int4 (~529MB) dari HuggingFace
        // LiteRT Community — model instruct terkecil yang wajar untuk 4GB RAM per riset
        // sebelum implementasi ini. User bebas import model .litertlm lain yang lebih kecil
        // kalau punya (mis. hasil convert sendiri) — file apa pun asal formatnya .litertlm valid.
        const val RECOMMENDED_MODEL_INFO_URL = "https://huggingface.co/litert-community"
    }

    private val modelFile: File get() = File(context.filesDir, "local-llm/$MODEL_FILE_NAME")

    fun isModelReady(): Boolean = modelFile.exists() && modelFile.length() > 0
    fun modelPath(): String = modelFile.absolutePath
    fun modelSizeMb(): Long = if (modelFile.exists()) modelFile.length() / (1024 * 1024) else 0L

    /** Copy file yang dipilih user lewat document picker ke penyimpanan privat app. */
    fun importFrom(uri: Uri): Boolean = try {
        modelFile.parentFile?.mkdirs()
        context.contentResolver.openInputStream(uri)?.use { input ->
            modelFile.outputStream().use { output -> input.copyTo(output) }
        }
        isModelReady()
    } catch (e: Exception) {
        modelFile.delete()
        false
    }

    fun deleteModel() {
        modelFile.delete()
    }
}
