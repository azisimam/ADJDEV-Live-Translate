package com.adjdev.livetranslate.ai

import kotlinx.coroutines.delay

/**
 * ⚠️ INI BUKAN AI SUNGGUHAN. Ini placeholder rule-based yang cuma menghasilkan balasan
 * generik ("Ya", "Tidak", "Bisa diulang?"), dibuat semata untuk membuktikan bahwa arsitektur
 * AI Path (load/unload lifecycle, suggested replies UI, pemisahan dari fast path) BEKERJA
 * secara end-to-end sebelum model sungguhan dipasang.
 *
 * TODO Phase 3 lanjutan (belum dikerjakan): ganti implementasi ini dengan model kecil
 * quantized on-device — kandidat realistis untuk perangkat kelas menengah seperti target
 * spesifikasi (Redmi Note 13 4G):
 *   - MediaPipe LLM Inference API dengan Gemma 2B/3 1B quantized (int4/int8)
 *   - atau llama.cpp via JNI dengan model GGUF kecil (Qwen2.5-0.5B/1.5B-Instruct, dsb.)
 * Interface AIEngine sudah dirancang agar penggantian ini tidak menyentuh pipeline lain.
 */
class PlaceholderCopilotEngine : AIEngine {

    override var status: AIEngineStatus = AIEngineStatus.IDLE
        private set

    override suspend fun load() {
        if (status == AIEngineStatus.READY) return
        status = AIEngineStatus.LOADING
        delay(150) // simulasi biaya "load" agar UI idle->loading terlihat nyata saat model asli dipasang
        status = AIEngineStatus.READY
    }

    override fun unload() {
        status = AIEngineStatus.IDLE
    }

    override suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>
    ): List<SuggestedReply> {
        if (status != AIEngineStatus.READY) return emptyList()
        status = AIEngineStatus.GENERATING
        delay(200) // simulasi latency generate

        val isQuestion = incomingTranslatedText.trim().endsWith("?")
        val suggestions = if (isQuestion) {
            listOf(
                SuggestedReply("Ya.", ReplyTone.SHORT),
                SuggestedReply("Belum tahu, coba cek dulu.", ReplyTone.CASUAL),
                SuggestedReply(incomingTranslatedText, ReplyTone.NATURAL) // "ask back" pattern
            )
        } else {
            listOf(
                SuggestedReply("Oke, dimengerti.", ReplyTone.SHORT),
                SuggestedReply("Boleh diulang sedikit?", ReplyTone.CASUAL),
                SuggestedReply("Baik, saya catat.", ReplyTone.FORMAL)
            )
        }

        status = AIEngineStatus.READY
        return suggestions
    }
}
