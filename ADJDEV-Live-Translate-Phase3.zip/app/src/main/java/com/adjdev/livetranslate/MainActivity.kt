package com.adjdev.livetranslate

import android.Manifest
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.adjdev.livetranslate.ai.local.LocalLlmModelManager
import com.adjdev.livetranslate.audio.SystemAudioSource
import com.adjdev.livetranslate.overlay.OverlayService
import com.adjdev.livetranslate.settings.TranslationMode
import com.adjdev.livetranslate.ui.theme.ADJDEVLiveTranslateTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ADJDEVLiveTranslateTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen(viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val context = LocalContext.current

    val micOn by viewModel.settings.micOn.collectAsState(initial = true)
    val systemAudioOn by viewModel.settings.systemAudioOn.collectAsState(initial = false)
    val autoDetect by viewModel.settings.autoDetect.collectAsState(initial = true)
    val mode by viewModel.settings.translationMode.collectAsState(initial = TranslationMode.LIGHT)

    var isRunning by remember { mutableStateOf(false) }
    val systemAudioSupported = SystemAudioSource.isSupported

    val recordAudioPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }
    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { }

    // Alur izin capture audio sistem (MediaProjection) — sebelumnya belum diimplementasikan,
    // makanya System Audio dinonaktifkan total di UI. Sekarang: dialog sistem diminta lewat
    // launcher ini SAAT user menekan "Start Translator" dengan toggle System Audio ON, lalu
    // resultCode+data dikirim ke OverlayService lewat extras Intent (bukan disimpan lintas
    // proses) supaya service yang membuat MediaProjection-nya sendiri lewat
    // MediaProjectionManager.getMediaProjection(resultCode, data).
    val projectionManager = remember {
        context.getSystemService(MediaProjectionManager::class.java)
    }
    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            startTranslatorService(context, projectionResultCode = result.resultCode, projectionData = result.data)
            isRunning = true
        } else {
            // User menolak dialog capture sistem: tetap jalankan translator tapi hanya
            // dengan Microphone, System Audio otomatis dimatikan lagi untuk sesi ini.
            viewModel.setSystemAudioOn(false)
            startTranslatorService(context, projectionResultCode = null, projectionData = null)
            isRunning = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("ADJDEV Live Translate", style = MaterialTheme.typography.headlineSmall)

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (isRunning) "\uD83D\uDFE2 Translator Active" else "\u26AA Translator Idle")
        }

        Text("Language: AUTO", style = MaterialTheme.typography.bodyMedium)

        HorizontalDivider()

        Text("Input", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilterChip(selected = micOn, onClick = { viewModel.setMicOn(!micOn) }, label = { Text("\uD83C\uDF99 Microphone") })
            FilterChip(
                selected = systemAudioOn,
                onClick = { viewModel.setSystemAudioOn(!systemAudioOn) },
                enabled = systemAudioSupported,
                label = { Text("\uD83D\uDD0A System Audio") }
            )
        }
        Text(
            text = if (!systemAudioSupported) {
                "System Audio butuh Android 10 (Q) ke atas dan tidak tersedia di perangkat ini."
            } else {
                "System Audio menangkap audio yang diputar aplikasi lain (video/musik/game), BUKAN audio " +
                    "panggilan VoIP. Dialog izin capture layar/audio akan muncul saat kamu menekan Start " +
                    "Translator dengan toggle ini aktif. Catatan jujur: transkripsi teks dari sumber ini " +
                    "BELUM tersedia — SpeechRecognizer bawaan Android hanya bisa mendengar dari mic, " +
                    "sehingga saat ini System Audio baru menangkap audio mentahnya saja (fondasi untuk " +
                    "engine STT offline berikutnya), belum menghasilkan teks terjemahan. Untuk translate " +
                    "suara lawan bicara di panggilan, tetap pakai mode Microphone + loudspeaker."
            },
            style = MaterialTheme.typography.bodySmall
        )

        HorizontalDivider()

        Text("Mode", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == TranslationMode.LIGHT, onClick = { viewModel.setMode(TranslationMode.LIGHT) }, label = { Text("\uD83D\uDFE2 LIGHT") })
            FilterChip(selected = mode == TranslationMode.SMART, onClick = { viewModel.setMode(TranslationMode.SMART) }, label = { Text("\uD83D\uDFE1 SMART") })
            FilterChip(selected = mode == TranslationMode.COPILOT, onClick = { viewModel.setMode(TranslationMode.COPILOT) }, label = { Text("\uD83D\uDD34 COPILOT") })
        }
        Text(
            "COPILOT & SMART memakai Gemini Nano on-device (Google ML Kit GenAI, via AICore) kalau " +
                "perangkatmu didukung: COPILOT jadi saran balasan asli dari model, SMART jadi terjemahan " +
                "yang mempertimbangkan konteks percakapan. AICore sendiri baru tersedia di sebagian " +
                "flagship (mis. Pixel 8+, Galaxy S24+) — di perangkat lain, COPILOT otomatis coba model " +
                "AI lokal yang kamu import sendiri (lihat 'Local AI Model' di bawah) sebelum jatuh ke " +
                "jalur rule-based sebagai jaring pengaman terakhir.",
            style = MaterialTheme.typography.bodySmall
        )

        HorizontalDivider()

        LocalLlmModelSection()

        HorizontalDivider()

        Button(
            onClick = {
                val hasMic = androidx.core.content.ContextCompat.checkSelfPermission(
                    context, Manifest.permission.RECORD_AUDIO
                ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (!hasMic) {
                    recordAudioPermission.launch(Manifest.permission.RECORD_AUDIO)
                    return@Button
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    val hasNotif = androidx.core.content.ContextCompat.checkSelfPermission(
                        context, Manifest.permission.POST_NOTIFICATIONS
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!hasNotif) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                if (!Settings.canDrawOverlays(context)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    overlayPermissionLauncher.launch(intent)
                    return@Button
                }

                if (systemAudioOn && systemAudioSupported && projectionManager != null) {
                    projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
                    return@Button
                }

                startTranslatorService(context, projectionResultCode = null, projectionData = null)
                isRunning = true
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isRunning
        ) { Text("Start Translator") }

        OutlinedButton(
            onClick = {
                context.startService(Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
                isRunning = false
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = isRunning
        ) { Text("Stop Translator") }
    }
}

private fun startTranslatorService(
    context: android.content.Context,
    projectionResultCode: Int?,
    projectionData: Intent?
) {
    val intent = Intent(context, OverlayService::class.java).setAction(OverlayService.ACTION_START)
    if (projectionResultCode != null && projectionData != null) {
        intent.putExtra(OverlayService.EXTRA_PROJECTION_RESULT_CODE, projectionResultCode)
        intent.putExtra(OverlayService.EXTRA_PROJECTION_DATA, projectionData)
    }
    context.startForegroundService(intent)
}

/**
 * UI untuk import model .litertlm secara manual (lihat catatan kejujuran di
 * LocalLlmModelManager soal kenapa tidak auto-download). Ditaruh di MainActivity (bukan
 * overlay) karena document picker (ACTION_OPEN_DOCUMENT) butuh Activity context.
 */
@Composable
private fun LocalLlmModelSection() {
    val context = LocalContext.current
    val modelManager = remember { LocalLlmModelManager(context) }
    var isReady by remember { mutableStateOf(modelManager.isModelReady()) }
    var sizeMb by remember { mutableStateOf(modelManager.modelSizeMb()) }
    var importError by remember { mutableStateOf<String?>(null) }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val success = modelManager.importFrom(uri)
        isReady = modelManager.isModelReady()
        sizeMb = modelManager.modelSizeMb()
        importError = if (!success) "Import gagal — pastikan file .litertlm valid dan cukup ruang penyimpanan." else null
    }

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Local AI Model (opsional, untuk COPILOT)", style = MaterialTheme.typography.titleMedium)
        Text(
            if (isReady) {
                "\u2705 Model tersimpan (${sizeMb} MB). COPILOT akan otomatis memakainya kalau " +
                    "Gemini Nano tidak tersedia di perangkat ini."
            } else {
                "Belum ada model tersimpan. Download file .litertlm (mis. Gemma3-1B-IT, sekitar " +
                    "500MB+) lewat Chrome dari ${LocalLlmModelManager.RECOMMENDED_MODEL_INFO_URL}, " +
                    "lalu import di sini. ⚠️ Berat untuk RAM 4GB — kalau device jadi lemot/COPILOT " +
                    "gagal terus, hapus modelnya lagi; app tetap jalan normal dengan jalur rule-based."
            },
            style = MaterialTheme.typography.bodySmall
        )
        importError?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) {
                Text(if (isReady) "Ganti Model" else "Import Model (.litertlm)")
            }
            if (isReady) {
                OutlinedButton(onClick = {
                    modelManager.deleteModel()
                    isReady = false
                }) { Text("Hapus") }
            }
        }
    }
}
