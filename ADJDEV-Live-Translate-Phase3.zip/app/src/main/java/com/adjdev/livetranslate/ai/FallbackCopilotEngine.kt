package com.adjdev.livetranslate.ai

/**
 * Composite untuk mode COPILOT, sekarang RANTAI 3 TINGKAT (sebelumnya 2 tingkat):
 *   1. [primary] Gemini Nano via AICore — kalau device flagship yang didukung (Pixel 8+,
 *      Galaxy S24+, dst), kualitas terbaik & tidak butuh download model tambahan.
 *   2. [secondary] Model kecil quantized on-device via LiteRT-LM (LocalLlmCopilotEngine) —
 *      kalau AICore tidak didukung TAPI user sudah import model .litertlm sendiri lewat
 *      Settings. UNAVAILABLE otomatis (tanpa error) kalau belum di-import.
 *   3. [fallback] Rule-based (PlaceholderCopilotEngine) — selalu berhasil, jaring pengaman
 *      terakhir supaya Suggested Replies tidak pernah mati total.
 *
 * Pipeline/UI tidak perlu tahu tingkat mana yang aktif — cukup pakai kontrak AIEngine seperti
 * biasa. Urutan percobaan TETAP (primary -> secondary -> fallback), begitu satu tingkat
 * UNAVAILABLE saat load(), langsung coba tingkat berikutnya di load() yang sama (bukan nunggu
 * toggle ulang).
 */
class FallbackCopilotEngine(
    private val primary: AIEngine = GeminiNanoCopilotEngine(),
    private val secondary: AIEngine? = null,
    private val fallback: AIEngine = PlaceholderCopilotEngine()
) : AIEngine {

    private enum class ActiveTier { PRIMARY, SECONDARY, FALLBACK }
    private var active = ActiveTier.PRIMARY

    override val status: AIEngineStatus
        get() = when (active) {
            ActiveTier.PRIMARY -> primary.status
            ActiveTier.SECONDARY -> secondary?.status ?: AIEngineStatus.UNAVAILABLE
            ActiveTier.FALLBACK -> fallback.status
        }

    override suspend fun load() {
        primary.load()
        if (primary.status == AIEngineStatus.READY) {
            active = ActiveTier.PRIMARY
            return
        }

        if (secondary != null) {
            secondary.load()
            if (secondary.status == AIEngineStatus.READY) {
                active = ActiveTier.SECONDARY
                return
            }
        }

        active = ActiveTier.FALLBACK
        fallback.load()
    }

    override fun unload() {
        primary.unload()
        secondary?.unload()
        fallback.unload()
    }

    override suspend fun generateSuggestions(
        incomingTranslatedText: String,
        recentContext: List<String>
    ): List<SuggestedReply> = when (active) {
        ActiveTier.PRIMARY -> primary.generateSuggestions(incomingTranslatedText, recentContext)
        ActiveTier.SECONDARY -> secondary?.generateSuggestions(incomingTranslatedText, recentContext) ?: emptyList()
        ActiveTier.FALLBACK -> fallback.generateSuggestions(incomingTranslatedText, recentContext)
    }
}
