package com.adjdev.livetranslate.stt

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * CATATAN ARSITEKTUR: android.speech.SpeechRecognizer TIDAK menerima stream PCM eksternal —
 * ia mengelola capture microphone-nya sendiri secara internal. Karena itu untuk mode
 * MICROPHONE, kelas ini memicu sesi listening-nya sendiri, dan TranslationPipeline.startMic()
 * menjalankannya sebagai LOOP (restart otomatis tiap sesi berakhir) tanpa VAD custom terpisah
 * — VAD custom yang berjalan paralel di AudioRecord sendiri sebelumnya terbukti bikin
 * SpeechRecognizer gagal dapat mic (dua konsumen mic sekaligus), lihat riwayat commit.
 *
 * Konsekuensi: engine ini TIDAK BISA dipakai untuk mentranskripsi SYSTEM AUDIO, karena
 * SpeechRecognizer hanya bisa membaca dari mic perangkat — untuk itu dipakai VoskPcmSttEngine
 * (lihat stt/vosk/) yang menerima raw PCM dari AudioSource manapun.
 *
 * isAvailable memeriksa dukungan on-device recognition (API 31+) agar sedapat mungkin
 * tidak bergantung pada koneksi internet, sesuai prinsip local-first.
 */
class AndroidSpeechRecognizerEngine(private val context: Context) : SpeechRecognizerEngine {

    override val isAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(context)

    private var recognizer: SpeechRecognizer? = null

    override fun startListening(languageTag: String?): Flow<TranscriptResult> = callbackFlow {
        if (!isAvailable) {
            close(IllegalStateException("Speech recognition unavailable."))
            return@callbackFlow
        }

        val sr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        ) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        } else {
            SpeechRecognizer.createSpeechRecognizer(context)
        }
        recognizer = sr

        val listener = object : RecognitionListener {
            override fun onResults(results: Bundle) {
                val text = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    trySend(TranscriptResult(text, isFinal = true, languageHint = languageTag))
                }
            }

            override fun onPartialResults(partialResults: Bundle) {
                val text = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    trySend(TranscriptResult(text, isFinal = false, languageHint = languageTag))
                }
            }

            override fun onError(error: Int) {
                // ERROR_NO_MATCH & ERROR_SPEECH_TIMEOUT itu NORMAL (jeda hening antar kalimat) —
                // sesi ditutup diam-diam lalu TranslationPipeline otomatis mulai sesi baru.
                // Error lain (mic sibuk/direbut app lain, izin dicabut, dsb.) diteruskan supaya
                // terlihat di overlay, bukan gagal diam-diam seperti sebelumnya.
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> close()
                    else -> close(IllegalStateException(errorMessageFor(error)))
                }
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        }

        sr.setRecognitionListener(listener)

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            if (languageTag != null) putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)

            // Tuning timeout (extra string tidak-terdokumentasi tapi stabil dipakai luas):
            // default recognizer di banyak OEM cukup agresif memotong begitu ada jeda
            // singkat di tengah kalimat (mis. orang bicara sambil mikir sebentar) -> kalimat
            // kepotong / dianggap selesai lebih awal. Nilai lebih besar di sini mengurangi
            // itu, dengan trade-off: overlay update sedikit lebih lambat saat kalimat memang
            // sudah selesai (karena recognizer nunggu lebih lama untuk yakin hening).
            putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1500)
            putExtra("android.speech.extra.SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS", 1500)
            putExtra("android.speech.extra.SPEECH_INPUT_MINIMUM_LENGTH_MILLIS", 15000)
        }
        sr.startListening(intent)

        awaitClose {
            sr.stopListening()
            sr.destroy()
            recognizer = null
        }
    }

    override fun stopListening() {
        recognizer?.stopListening()
    }

    private fun errorMessageFor(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Speech recognition unavailable: microphone sedang dipakai aplikasi lain."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Izin microphone belum diberikan."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech recognizer sedang sibuk, coba lagi."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Speech recognition unavailable: butuh koneksi (recognizer online tidak tersedia offline di perangkat ini)."
        SpeechRecognizer.ERROR_CLIENT -> "Speech recognition unavailable (client error)."
        else -> "Speech recognition unavailable."
    }
}
