plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.adjdev.livetranslate"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.adjdev.livetranslate"
        minSdk = 26 // butuh 26+ untuk overlay & foreground service yang stabil
        targetSdk = 34
        versionCode = 1
        versionName = "0.1.0-phase1"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        // Dinaikkan dari 17 ke 21: laporan komunitas menunjukkan litertlm-android (dependency
        // LiteRT-LM di bawah) dikompilasi dengan class file target Java 21 pada sebagian versi
        // ("class file has wrong version 65.0, should be 61.0" kalau tetap di Java 17). Kalau
        // Android Studio/CI di sisi kamu belum punya JDK 21, ini penyebab pertama yang perlu
        // dicek kalau muncul error compile seperti itu.
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
    kotlinOptions {
        jvmTarget = "21"
    }

    buildFeatures {
        compose = true
    }
    // composeOptions { kotlinCompilerExtensionVersion = ... } DIHAPUS: mekanisme itu K1-only.
    // Sejak Kotlin 2.0+, versi compiler Compose ditentukan otomatis oleh plugin
    // "org.jetbrains.kotlin.plugin.compose" (lihat root build.gradle.kts) mengikuti versi
    // Kotlin project ini — tidak perlu diset manual lagi di sini.

    packaging {
        resources.excludes.add("/META-INF/{AL2.0,LGPL2.1}")
    }
}

dependencies {
    // Core & lifecycle
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.savedstate:savedstate-ktx:1.2.1")

    // Compose (BOM)
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
    implementation("androidx.compose.material:material-icons-extended:1.6.8")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // DataStore untuk settings lokal (bukan cloud db)
    implementation("androidx.datastore:datastore-preferences:1.1.1")

    // ML Kit on-device: translation & language identification (offline setelah model diunduh sekali)
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")

    // ML Kit GenAI Prompt API — Gemini Nano on-device via AICore (Phase 3: mode SMART yang
    // benar-benar context-aware + COPILOT dengan suggested replies sungguhan, bukan lagi
    // rule-based). Beta, hanya berjalan di perangkat yang didukung AICore — lihat catatan
    // kejujuran di ContextAwareTranslationEngine.kt / GeminiNanoCopilotEngine.kt. Aman
    // ditambahkan di semua perangkat: di perangkat tak didukung, checkStatus() otomatis
    // UNAVAILABLE dan pipeline jatuh ke perilaku Phase 2 (ML Kit Translate biasa + placeholder).
    implementation("com.google.mlkit:genai-prompt:1.0.0-beta2")

    // Vosk (org.vosk:vosk-android via com.alphacephei) — STT offline berbasis PCM untuk
    // System Audio (Phase 3.1). BEDA dari ML Kit di atas: model bahasa TIDAK dibundel di APK,
    // diunduh sekali saat System Audio pertama kali diaktifkan (lihat VoskModelManager) supaya
    // ukuran APK dasar tidak membengkak untuk fitur yang belum tentu dipakai semua user.
    // JNA (dependensi transitif vosk-android) WAJIB deklarasi @aar eksplisit di sini kalau
    // versi vosk-android yang dipakai tidak menariknya otomatis sebagai aar.
    implementation("com.alphacephei:vosk-android:0.3.75")
    implementation("net.java.dev.jna:jna:5.18.1@aar")

    // LiteRT-LM (com.google.ai.edge.litertlm) — penerus resmi MediaPipe LLM Inference API
    // yang deprecated Maret 2026. Ini tier KEDUA fallback COPILOT untuk device yang tidak
    // didukung Gemini Nano/AICore (mayoritas kelas menengah, termasuk target spesifikasi):
    // model kecil quantized (mis. Gemma3-1B-IT) berjalan sendiri di device, TAPI model file-nya
    // TIDAK dibundel di sini — harus di-import manual oleh user (lihat LocalLlmModelManager)
    // karena model Gemma di HuggingFace ada di belakang halaman lisensi yang butuh login.
    // Versi 0.13.1 dicek terbaru per Agustus 2026 (mvnrepository.com); ganti kalau ada versi
    // lebih baru saat kamu build nanti.
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.13.1")
}
