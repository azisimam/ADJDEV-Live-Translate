# ADJDEV Live Translate - proguard rules
# ML Kit menggunakan reflection untuk beberapa komponen; tambahkan keep rules di sini
# jika ditemukan crash setelah minify pada build release.

# Vosk (JNI ke libvosk.so) & JNA — keep supaya nama kelas/metode yang dipanggil lewat native
# code tidak di-obfuscate/dihapus R8 (belum pernah dites di release build minified,
# lihat catatan kejujuran di VoskPcmSttEngine.kt — ini rule standar yang direkomendasikan
# komunitas Vosk-Android, tapi tetap perlu diverifikasi manual di device kalau ada crash).
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-keepclassmembers class * extends com.sun.jna.Structure { public *; }
-dontwarn com.sun.jna.**

# ML Kit Translate & Language ID sudah punya consumer proguard rules sendiri, tapi tetap
# di-keep eksplisit karena beberapa kelas model diakses lewat reflection saat proses download
# model on-device.
-keep class com.google.mlkit.nl.translate.** { *; }
-keep class com.google.mlkit.nl.languageid.** { *; }
-keep class com.google.android.gms.internal.mlkit_translate.** { *; }

# ML Kit GenAI Prompt (Gemini Nano/AICore) — masih beta, belum tentu punya consumer rules
# lengkap; keep supaya callback/status class tidak ke-strip R8.
-keep class com.google.mlkit.genai.** { *; }
-dontwarn com.google.mlkit.genai.**

# org.json dipakai manual (GroqTranscriptionClient, RemoteCopilotEngine) tanpa Retrofit/Gson,
# jadi tidak butuh keep rule model class tambahan.

# DataStore Preferences pakai Protobuf Lite secara internal.
-dontwarn com.google.protobuf.**
