package com.adjdev.livetranslate.core

import com.adjdev.livetranslate.ai.AIEngine
import com.adjdev.livetranslate.ai.AIEngineStatus
import com.adjdev.livetranslate.audio.AudioSource
import com.adjdev.livetranslate.conversation.ConversationContextStore
import com.adjdev.livetranslate.conversation.ConversationTurn
import com.adjdev.livetranslate.text.PinyinUtils
import com.adjdev.livetranslate.detection.LanguageDetector
import com.adjdev.livetranslate.stt.SpeechRecognizerEngine
import com.adjdev.livetranslate.stt.vosk.ModelPrepStatus
import com.adjdev.livetranslate.stt.vosk.PcmSttEngine
import com.adjdev.livetranslate.stt.vosk.VoskModelManager
import com.adjdev.livetranslate.storage.TranslationCache
import com.adjdev.livetranslate.translation.TranslationEngine
import com.adjdev.livetranslate.translation.TranslationOutcome
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Menghubungkan: STT (loop mandiri) -> Deteksi bahasa -> Cache/Translation -> state.
 *
 * FAST PATH murni (spesifikasi #11): tidak ada langkah AI/Copilot di kelas ini sama sekali.
 * Mode SMART/COPILOT (context, suggestions) dibangun sebagai layer terpisah di atas
 * hasil finalTranscript yang di-emit dari sini (Phase 3), agar jalur realtime translation
 * TIDAK PERNAH menunggu proses AI.
 *
 * CATATAN ARSITEKTUR (Phase 2 -> Phase 3 fix): sebelumnya VAD memakai AudioRecord terpisah
 * (MicAudioSource) berjalan BERSAMAAN dengan android.speech.SpeechRecognizer yang juga
 * membuka mic sendiri. Di banyak perangkat, dua konsumen mic sekaligus membuat
 * SpeechRecognizer gagal mendapat audio (gagal diam-diam lewat onError, tanpa transcript
 * ataupun pesan error yang terlihat). Karena itu untuk STT berbasis SpeechRecognizer bawaan
 * Android, VAD custom TIDAK dipakai lagi sebagai gate mic — sebagai gantinya sesi STT
 * dijalankan berulang (loop) dan SpeechRecognizer sendiri yang menangani deteksi mulai/akhir
 * bicara secara internal. EnergyVadEngine/MicAudioSource tetap disimpan di codebase untuk
 * dipakai nanti oleh STT engine berbasis raw-PCM (Vosk/whisper.cpp) yang BISA berbagi satu
 * AudioRecord tap tanpa konflik.
 */
class TranslationPipeline(
    private val sttEngine: SpeechRecognizerEngine,
    private val languageDetector: LanguageDetector,
    private val translationEngine: TranslationEngine,
    private val cache: TranslationCache,
    val conversationContext: ConversationContextStore = ConversationContextStore(),
    private val aiEngine: AIEngine? = null,
    // Phase 3.1: STT nyata untuk System Audio. Null = perilaku lama (drain tanpa transkrip),
    // dipertahankan biar TranslationPipeline tetap bisa dites/dipakai tanpa Vosk ter-setup.
    private val systemAudioSttEngine: PcmSttEngine? = null,
    private val systemAudioModelManager: VoskModelManager? = null
) {
    companion object {
        // Jeda sebelum partial text diterjemahkan, supaya tidak memanggil translation engine
        // di setiap perubahan huruf saat user masih bicara (Phase 2: streaming translation).
        private const val PARTIAL_TRANSLATE_DEBOUNCE_MS = 400L
        private const val PARTIAL_TRANSLATE_MIN_LENGTH = 2
        // Lihat coalesceSystemAudioFinal() — jeda tunggu sebelum hasil final Vosk yang
        // beruntun cepat dianggap benar-benar selesai & digabung jadi satu kalimat utuh.
        private const val SYSTEM_AUDIO_COALESCE_WINDOW_MS = 700L
        // FIX BUG "kadang cuma 2-3 kalimat lalu berhenti": sebelumnya window coalesce di
        // atas TIDAK PUNYA BATAS MAKSIMAL — kalau orang bicara terus dengan jeda pendek
        // (<700ms) untuk waktu lama (wajar di voice room ramai), buffer terus digabung dan
        // TIMER-nya terus di-reset, tidak pernah benar-benar flush ke translate. Dari luar
        // kelihatan seperti "berhenti transkrip" padahal sebenarnya numpuk diam-diam tanpa
        // ada indikasi apa pun. Sekarang dipaksa flush kalau buffer sudah menumpuk terlalu
        // lama, TIDAK PEDULI masih ada final baru yang menyusul atau tidak.
        private const val SYSTEM_AUDIO_COALESCE_MAX_WAIT_MS = 4000L
    }

    private val scope = CoroutineScope(SupervisorJob())
    private var sttJob: Job? = null
    private var partialTranslateJob: Job? = null
    private var systemAudioJob: Job? = null
    private var systemAudioSource: AudioSource? = null
    // Coalescing untuk hasil final Vosk yang datang beruntun cepat (lihat startSystemAudio):
    // Kaldi/Vosk endpointing internal cukup agresif, sering motong kalimat pas orang bicara
    // cepat lalu jeda sebentar — bukannya langsung translate tiap final, digabung dulu kalau
    // ada final BERIKUTNYA yang menyusul dalam SYSTEM_AUDIO_COALESCE_WINDOW_MS.
    private var systemAudioPendingFinalText: String = ""
    private var systemAudioFlushJob: Job? = null
    private var systemAudioCoalesceStartedAtMs: Long = 0L

    private val _state = MutableStateFlow(TranslatorState())
    val state: StateFlow<TranslatorState> = _state.asStateFlow()

    private var targetLanguageTag: String = "id"
    private var autoDetect: Boolean = true
    private var fixedSourceLanguageTag: String? = null
    private var copilotEnabled: Boolean = false
    private var smartModeEnabled: Boolean = false
    // Bahasa yang diasumsikan untuk audio lawan bicara di System Audio (Vosk butuh model
    // per-bahasa dimuat eksplisit — beda dari mic yang bisa auto-detect via ML Kit setelah
    // teksnya ada). Default "en" karena itu satu-satunya model resmi yang tersedia saat ini,
    // lihat catatan kejujuran di VoskModelCatalog.
    private var systemAudioLanguageTag: String = "en"

    fun setSystemAudioLanguageTag(languageTag: String) {
        systemAudioLanguageTag = languageTag
    }

    fun configure(targetLanguageTag: String, autoDetect: Boolean, sourceLanguageTag: String?) {
        this.targetLanguageTag = targetLanguageTag
        this.autoDetect = autoDetect
        this.fixedSourceLanguageTag = sourceLanguageTag
        // FIX: sebelumnya overlay header cuma baca `detectedLanguage` (baru terisi SETELAH
        // satu translation berhasil) — jadi kalau user sudah pilih bahasa eksplisit di picker
        // tapi translation belum sempat sukses (atau lagi gagal terus), header tetap kejebak
        // nampilin "AUTO" walau AUTO sebenarnya sudah dimatikan. Sekarang header baca
        // `configuredSourceLanguage` yang di-update di sini, LANGSUNG saat user ganti pilihan
        // di picker — tidak nunggu hasil translate apa pun.
        _state.value = _state.value.copy(
            configuredSourceLanguage = if (autoDetect) null else sourceLanguageTag,
            targetLanguage = targetLanguageTag
        )
    }

    /**
     * Aktif/nonaktifkan mode COPILOT. Mengikuti pola idle/load di spesifikasi §6: model
     * baru dimuat saat benar-benar diaktifkan, dilepas lagi saat dinonaktifkan agar tidak
     * resident di RAM secara sia-sia.
     */
    /**
     * Aktif/nonaktifkan mode SMART (Phase 3: context-aware translation via Gemini Nano —
     * lihat ContextAwareTranslationEngine). Kalau translationEngine yang di-inject bukan
     * ContextAwareTranslationEngine (atau device tidak didukung Gemini Nano), translateWithContext()
     * otomatis jatuh ke translate() biasa lewat default method di TranslationEngine — jadi ini
     * aman dipanggil terlepas dari engine apa yang dipakai.
     */
    fun setSmartModeEnabled(enabled: Boolean) {
        smartModeEnabled = enabled
    }

    fun setCopilotEnabled(enabled: Boolean) {
        copilotEnabled = enabled
        if (aiEngine == null) return
        if (enabled) {
            scope.launch { aiEngine.load() }
        } else {
            aiEngine.unload()
            _state.value = _state.value.copy(suggestedReplies = emptyList())
        }
    }

    /**
     * Mulai pipeline mic: menjalankan sesi SpeechRecognizer berulang (auto-restart) selama
     * mic ON. SpeechRecognizer sendiri yang mendeteksi mulai/akhir bicara secara internal —
     * lihat catatan arsitektur di atas kelas ini.
     */
    fun startMic() {
        if (sttJob?.isActive == true) return
        _state.value = _state.value.copy(isRunning = true, micOn = true, errorMessage = null)

        // WAJIB di Dispatchers.Main: android.speech.SpeechRecognizer harus dibuat & dipakai
        // dari thread yang punya Looper (biasanya main thread).
        sttJob = scope.launch(Dispatchers.Main) {
            while (isActive) {
                try {
                    sttEngine.startListening(fixedSourceLanguageTag).collect { result ->
                        if (result.isFinal) {
                            handleFinalTranscript(result.text)
                        } else {
                            _state.value = _state.value.copy(partialSourceText = result.text)
                            schedulePartialTranslation(result.text)
                        }
                    }
                } catch (e: Exception) {
                    _state.value = _state.value.copy(errorMessage = e.message ?: "Speech recognition unavailable.")
                }
                // Jeda singkat sebelum sesi baru, agar tidak busy-loop kalau error terus-menerus
                // (mis. izin dicabut, atau recognizer sedang sibuk).
                delay(300)
            }
        }
    }

    /**
     * Terjemahan "live" dari teks partial (belum final) selagi user masih bicara (Phase 2:
     * streaming translation lebih halus). Di-debounce agar tidak memanggil translation engine
     * di setiap perubahan huruf. Sengaja best-effort: dibatalkan begitu ada partial baru atau
     * transcript final datang, dan kegagalannya diam-diam saja karena hasil FINAL dari
     * handleFinalTranscript() adalah satu-satunya sumber kebenaran (fast path tidak terganggu).
     */
    private fun schedulePartialTranslation(text: String) {
        partialTranslateJob?.cancel()
        if (text.isBlank() || text.trim().length < PARTIAL_TRANSLATE_MIN_LENGTH) {
            _state.value = _state.value.copy(partialTranslatedText = "")
            return
        }
        partialTranslateJob = scope.launch {
            delay(PARTIAL_TRANSLATE_DEBOUNCE_MS)
            val sourceLang = if (autoDetect) {
                languageDetector.detect(text) ?: return@launch
            } else {
                fixedSourceLanguageTag ?: "en"
            }

            val cached = cache.get(sourceLang, targetLanguageTag, text)
            if (cached != null) {
                _state.value = _state.value.copy(partialTranslatedText = cached)
                return@launch
            }

            // FIX bug "Translation model files not found": sebelumnya translate() dipanggil
            // langsung tanpa pernah memastikan model ML Kit sudah terunduh untuk pasangan
            // bahasa ini. Diam-diam gagal di sini (partial translation memang best-effort).
            if (!translationEngine.ensureModelDownloaded(sourceLang, targetLanguageTag)) return@launch

            val outcome = if (smartModeEnabled) {
                translationEngine.translateWithContext(
                    text, sourceLang, targetLanguageTag,
                    conversationContext.recentTurns().map { it.sourceText }
                )
            } else {
                translationEngine.translate(text, sourceLang, targetLanguageTag)
            }
            when (outcome) {
                is TranslationOutcome.Success -> {
                    _state.value = _state.value.copy(partialTranslatedText = outcome.translatedText)
                }
                is TranslationOutcome.Failure -> {
                    // Diamkan: partial translation gagal bukan error yang perlu ditampilkan,
                    // final transcript nanti tetap dicoba lagi lewat handleFinalTranscript().
                }
            }
        }
    }

    private suspend fun handleFinalTranscript(text: String) {
        partialTranslateJob?.cancel()
        if (text.isBlank()) return

        val sourceLang = if (autoDetect) {
            languageDetector.detect(text) ?: "en"
        } else {
            fixedSourceLanguageTag ?: "en"
        }

        val cached = cache.get(sourceLang, targetLanguageTag, text)
        if (cached != null) {
            emitTranslated(text, cached, sourceLang)
            return
        }

        // FIX bug "Translation model files not found. Make sure to call
        // downloadModelIfNeeded...": translate() sebelumnya dipanggil tanpa pernah memastikan
        // model ML Kit sudah terunduh untuk pasangan bahasa ini terlebih dulu. Di sini (final
        // transcript, bukan best-effort seperti partial) kegagalan ditampilkan ke user sebagai
        // error yang jelas, bukan diam-diam.
        if (!translationEngine.ensureModelDownloaded(sourceLang, targetLanguageTag)) {
            _state.value = _state.value.copy(
                errorMessage = "Mengunduh model terjemahan $sourceLang→$targetLanguageTag, coba lagi sesaat lagi."
            )
            return
        }

        val outcome = if (smartModeEnabled) {
            translationEngine.translateWithContext(
                text, sourceLang, targetLanguageTag,
                conversationContext.recentTurns().map { it.sourceText }
            )
        } else {
            translationEngine.translate(text, sourceLang, targetLanguageTag)
        }
        when (outcome) {
            is TranslationOutcome.Success -> {
                cache.put(sourceLang, targetLanguageTag, text, outcome.translatedText)
                emitTranslated(text, outcome.translatedText, sourceLang)
            }
            is TranslationOutcome.Failure -> {
                _state.value = _state.value.copy(errorMessage = outcome.message)
            }
        }
    }

    private fun emitTranslated(source: String, translated: String, detectedLang: String) {
        // Dicatat sebagai groundwork mode SMART (Phase 3); fast path di atas tidak menunggu ini.
        conversationContext.addTurn(ConversationTurn(source, translated, detectedLang))
        _state.value = _state.value.copy(
            partialSourceText = "",
            partialTranslatedText = "",
            lastSourceText = source,
            lastTranslatedText = translated,
            detectedLanguage = detectedLang,
            errorMessage = null,
            suggestedReplies = emptyList(), // reset dulu, AI Path akan mengisinya belakangan
            copilotErrorMessage = null,
            // APPEND, bukan overwrite — lihat catatan di TranslatorState.transcriptLog.
            transcriptLog = _state.value.transcriptLog + TranscriptEntry(source, translated)
        )
        triggerAiPathIfEnabled(translated, detectedLang)
    }

    /**
     * AI PATH (spesifikasi §11): dijalankan sebagai coroutine terpisah setelah translation
     * SUDAH tampil di overlay (lihat emitTranslated di atas). Kalau AI belum selesai atau
     * gagal, translation tetap terlihat normal — tidak ada yang menunggu baris ini.
     *
     * FIX bahasa suggested replies (permintaan user): [aiEngine] tetap "berpikir" & dikasih
     * konteks dalam bahasa target (mis. ID) — itu bahasa yang paling dimengerti oleh heuristik
     * PlaceholderCopilotEngine maupun prompt GeminiNanoCopilotEngine. TAPI hasil akhir yang
     * ditampilkan ke user sekarang di-translate lagi ke bahasa LAWAN BICARA ([sourceLang], hasil
     * deteksi dari transcript barusan) via translationEngine yang sama dipakai untuk jalur
     * utama — supaya saran itu bisa langsung ditempel/kirim ke WhatsApp/HelloTalk dkk dalam
     * bahasa yang dipahami lawan bicara. Teks aslinya (bahasa target/ID) disimpan sebagai
     * SuggestedReply.translation, biar user tetap tahu arti dari apa yang mau dia kirim.
     * Kalau sourceLang == targetLanguageTag (lawan bicara kebetulan sama bahasanya), tidak ada
     * yang perlu diterjemahkan lagi.
     */
    private fun triggerAiPathIfEnabled(translatedText: String, sourceLang: String) {
        if (!copilotEnabled || aiEngine == null) return
        scope.launch {
            if (aiEngine.status == AIEngineStatus.IDLE) aiEngine.load()
            val recentContext = conversationContext.recentTurns().map { it.translatedText }
            val rawSuggestions = aiEngine.generateSuggestions(translatedText, recentContext, targetLanguageTag)

            val localized = if (sourceLang == targetLanguageTag) {
                rawSuggestions
            } else {
                val canTranslateBack = translationEngine.ensureModelDownloaded(targetLanguageTag, sourceLang)
                rawSuggestions.map { suggestion ->
                    if (!canTranslateBack) return@map suggestion
                    when (val outcome = translationEngine.translate(suggestion.text, targetLanguageTag, sourceLang)) {
                        is TranslationOutcome.Success -> suggestion.copy(
                            text = outcome.translatedText,
                            translation = suggestion.text
                        )
                        // Diamkan: kalau gagal balik-terjemahkan satu saran, tampilkan versi
                        // ID apa adanya daripada menghilangkan saran itu sepenuhnya.
                        is TranslationOutcome.Failure -> suggestion
                    }
                }
            }

            _state.value = _state.value.copy(
                // Romanisasi ditempel di sini (bukan di dalam AIEngine manapun) supaya SEMUA
                // tier (Gemini Nano, Remote, rule-based) otomatis dapat fitur ini tanpa perlu
                // diimplementasikan berulang di tiap engine.
                // Diperluas dari sebelumnya "cuma kalau sourceLang == zh" jadi general —
                // PinyinUtils sekarang pakai transliterator "Any-Latin" ICU yang otomatis
                // deteksi aksara APA PUN yang bukan Latin (Jepang, Korea, Arab, dll) dan balik
                // null sendiri kalau teksnya sudah full Latin, jadi gerbang manual per-bahasa
                // di sini tidak diperlukan lagi.
                suggestedReplies = localized.map { it.copy(pinyin = PinyinUtils.pinyinOrNull(it.text)) },
                // Cuma tampilkan diagnostik kalau memang ujung-ujungnya kosong — begitu ADA
                // saran yang berhasil (dari tier manapun), tidak relevan lagi menampilkan
                // error tier sebelumnya.
                copilotErrorMessage = if (localized.isEmpty()) aiEngine.lastError else null
            )
        }
    }

    /** Dipanggil dari tombol "Clear Conversation" di overlay/settings (spesifikasi §4/§15). */
    /** Tombol sapu/trash di overlay — bersihkan context AI (SMART/COPILOT) SEKALIGUS log
     * transkrip yang ditampilkan (TranslatorState.transcriptLog). Ini satu-satunya cara log
     * transkrip berkurang — tidak ada limit/auto-cut otomatis (permintaan user). */
    fun clearConversation() {
        conversationContext.clear()
        _state.value = _state.value.copy(transcriptLog = emptyList())
    }

    fun setContextLimit(maxTurns: Int) = conversationContext.setMaxTurns(maxTurns)

    fun stopMic() {
        sttJob?.cancel()
        partialTranslateJob?.cancel()
        sttEngine.stopListening()
        _state.value = _state.value.copy(micOn = false, partialSourceText = "", partialTranslatedText = "")
    }

    /**
     * Mulai capture System Audio dari [source] (mis. SystemAudioSource yang sudah dibungkus
     * MediaProjection valid di OverlayService). Phase 3.1: kalau [systemAudioSttEngine] &
     * [systemAudioModelManager] disediakan (lihat OverlayService), setiap AudioChunk sekarang
     * BENAR-BENAR ditranskripsi lewat Vosk (bukan sekadar di-drain seperti sebelumnya) —
     * android.speech.SpeechRecognizer tetap tidak dipakai di sini karena dia tidak menerima
     * PCM eksternal (lihat catatan di AndroidSpeechRecognizerEngine.kt), makanya System Audio
     * butuh engine PCM-streaming terpisah.
     *
     * Model bahasa untuk [systemAudioLanguageTag] diunduh sekali (kalau belum ada) SEBELUM
     * mulai feed chunk — progressnya diekspos lewat state.systemAudioSttStatus supaya overlay
     * bisa tampilkan "mengunduh model..." dengan jujur, bukan diam-diam gagal. Kalau
     * [systemAudioSttEngine] null, fallback ke perilaku lama (capture jalan, transkrip tidak
     * ada) — dipertahankan supaya pipeline ini tetap bisa dipakai/dites tanpa Vosk ter-setup.
     */
    /**
     * Gabungkan hasil final Vosk yang datang beruntun cepat (lihat komentar di
     * systemAudioPendingFinalText) sebelum benar-benar dikirim ke translate. Setiap final
     * baru yang masuk MEMBATALKAN timer flush sebelumnya dan mulai timer baru — jadi kalimat
     * cuma benar-benar "selesai" & diterjemahkan setelah jeda hening
     * [SYSTEM_AUDIO_COALESCE_WINDOW_MS] tanpa final baru. Trade-off yang disadari: nambah
     * latency (maks ~700ms) demi kalimat utuh, bukan terpotong-potong — sesuai laporan user
     * ("kepotong-potong" lebih mengganggu daripada delay sedikit).
     */
    private fun coalesceSystemAudioFinal(text: String) {
        if (text.isBlank()) return
        val now = System.currentTimeMillis()
        if (systemAudioPendingFinalText.isBlank()) {
            systemAudioCoalesceStartedAtMs = now
            systemAudioPendingFinalText = text
        } else {
            systemAudioPendingFinalText = "$systemAudioPendingFinalText $text"
        }
        systemAudioFlushJob?.cancel()

        val elapsedSinceStart = now - systemAudioCoalesceStartedAtMs
        if (elapsedSinceStart >= SYSTEM_AUDIO_COALESCE_MAX_WAIT_MS) {
            // Sudah kelamaan menumpuk (orang bicara terus tanpa jeda >700ms) — flush PAKSA
            // sekarang juga, jangan tunggu window lagi. Ini yang mencegah bug "kelihatan
            // berhenti" saat pembicaraan cepat/berkelanjutan.
            val combined = systemAudioPendingFinalText
            systemAudioPendingFinalText = ""
            scope.launch { handleFinalTranscript(combined) }
            return
        }

        systemAudioFlushJob = scope.launch {
            delay(SYSTEM_AUDIO_COALESCE_WINDOW_MS)
            val combined = systemAudioPendingFinalText
            systemAudioPendingFinalText = ""
            if (combined.isNotBlank()) handleFinalTranscript(combined)
        }
    }

    fun startSystemAudio(source: AudioSource) {
        systemAudioJob?.cancel()
        systemAudioSource = source
        _state.value = _state.value.copy(systemAudioOn = true)

        val sttEngine = systemAudioSttEngine
        val modelManager = systemAudioModelManager
        val languageTag = systemAudioLanguageTag

        systemAudioJob = scope.launch(Dispatchers.IO) {
            if (sttEngine != null && modelManager != null) {
                val prepared = ensureSystemAudioModelReady(modelManager, languageTag)
                if (!prepared) {
                    // Status error/Unsupported sudah di-set oleh ensureSystemAudioModelReady().
                    // Capture PCM tetap dibiarkan jalan (systemAudioOn tetap true, sesuai
                    // prinsip: jangan matikan capture yang sudah diizinkan user hanya karena
                    // transkrip belum bisa) — hanya transkrip yang tidak akan muncul.
                } else if (!sttEngine.start(languageTag)) {
                    _state.value = _state.value.copy(
                        systemAudioSttStatus = SystemAudioSttStatus.Error(
                            "Model bahasa sudah terunduh tapi gagal dimuat. Coba nonaktifkan lalu aktifkan lagi System Audio."
                        )
                    )
                } else {
                    _state.value = _state.value.copy(systemAudioSttStatus = SystemAudioSttStatus.Transcribing)
                }
            }

            try {
                source.start().collect { chunk ->
                    if (sttEngine?.isReady != true) return@collect
                    val result = sttEngine.accept(chunk)
                    // FIX: sebelumnya error dari accept() (Vosk gagal internal) diam-diam
                    // return null selamanya, tanpa indikasi apa pun — sekarang lastError
                    // dicek tiap kali null, supaya kalau memang error (bukan cuma "belum ada
                    // hasil baru"), tampil di overlay via SystemAudioSttStatus.Error.
                    if (result == null) {
                        val err = sttEngine.lastError
                        if (err != null) {
                            _state.value = _state.value.copy(systemAudioSttStatus = SystemAudioSttStatus.Error(err))
                        }
                        return@collect
                    }
                    if (result.isFinal) {
                        coalesceSystemAudioFinal(result.text)
                    } else {
                        _state.value = _state.value.copy(partialSourceText = result.text)
                        schedulePartialTranslation(result.text)
                    }
                }
            } catch (e: Exception) {
                _state.value = _state.value.copy(
                    errorMessage = e.message ?: "System audio capture unavailable.",
                    systemAudioOn = false
                )
            }
        }
    }

    private suspend fun ensureSystemAudioModelReady(
        modelManager: VoskModelManager,
        languageTag: String
    ): Boolean {
        if (modelManager.isModelReady(languageTag)) return true

        var success = false
        modelManager.prepare(languageTag).collect { status ->
            when (status) {
                is ModelPrepStatus.AlreadyReady, is ModelPrepStatus.Ready -> success = true

                is ModelPrepStatus.Downloading -> {
                    val percent = if (status.totalBytes > 0) {
                        ((status.bytesDownloaded * 100) / status.totalBytes).toInt()
                    } else 0
                    _state.value = _state.value.copy(
                        systemAudioSttStatus = SystemAudioSttStatus.DownloadingModel(percent)
                    )
                }

                is ModelPrepStatus.Extracting -> {
                    _state.value = _state.value.copy(systemAudioSttStatus = SystemAudioSttStatus.PreparingModel)
                }

                is ModelPrepStatus.Unsupported -> {
                    _state.value = _state.value.copy(
                        systemAudioSttStatus = SystemAudioSttStatus.Unsupported(status.languageTag)
                    )
                }

                is ModelPrepStatus.Failed -> {
                    _state.value = _state.value.copy(
                        systemAudioSttStatus = SystemAudioSttStatus.Error(status.message)
                    )
                }
            }
        }
        return success
    }

    fun stopSystemAudio() {
        systemAudioJob?.cancel()
        systemAudioJob = null
        systemAudioFlushJob?.cancel()
        systemAudioFlushJob = null
        systemAudioPendingFinalText = ""
        systemAudioSttEngine?.stop()
        systemAudioSource?.stop()
        systemAudioSource = null
        _state.value = _state.value.copy(systemAudioOn = false, systemAudioSttStatus = SystemAudioSttStatus.Idle)
    }

    /** Hentikan seluruh pipeline & lepaskan semua resource (dipanggil saat translator OFF). */
    fun stopAll() {
        stopMic()
        stopSystemAudio()
        translationEngine.release()
        aiEngine?.unload()
        _state.value = TranslatorState()
        scope.cancel()
    }
}
