package com.adjdev.livetranslate.stt

import com.adjdev.livetranslate.audio.AudioChunk
import com.adjdev.livetranslate.stt.vosk.PcmSttEngine

/**
 * PRIORITAS: Groq (kalau API key sudah diisi — field yang SAMA dipakai mic di Settings) —
 * lebih cepat, lebih akurat, dan mendukung jauh lebih banyak bahasa (termasuk Bahasa
 * Indonesia, yang TIDAK ADA di Vosk). Fallback ke Vosk (offline, gratis, tanpa internet)
 * kalau API key belum diisi — supaya System Audio tetap berfungsi tanpa AI/cloud online
 * sama sekali sesuai prinsip local-first spesifikasi §1/§6.
 *
 * Dipilih SEKALI saat [start] dipanggil (beda dari PreferredSttEngine yang mic pakai,
 * yang re-check tiap sesi) — System Audio cuma di-start SEKALI per sesi translator (saat
 * MediaProjection permission diberikan), jadi tidak ada "sesi berikutnya" untuk pindah
 * engine di tengah jalan; ganti API key butuh Stop lalu Start Translator lagi supaya kepakai.
 */
class PreferredPcmSttEngine(
    private val cloud: GroqWhisperPcmSttEngine,
    private val local: PcmSttEngine
) : PcmSttEngine {

    private var active: PcmSttEngine? = null

    override val isReady: Boolean get() = active?.isReady == true
    override val lastError: String? get() = active?.lastError

    override fun start(languageTag: String): Boolean {
        active = if (cloud.isReady) cloud else local
        return active?.start(languageTag) == true
    }

    override suspend fun accept(chunk: AudioChunk): TranscriptResult? = active?.accept(chunk)

    override fun stop() {
        active?.stop()
    }
}
