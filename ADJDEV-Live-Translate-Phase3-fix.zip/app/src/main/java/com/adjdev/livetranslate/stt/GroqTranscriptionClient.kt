package com.adjdev.livetranslate.stt

import com.adjdev.livetranslate.audio.WavEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/**
 * Logic upload ke Groq Whisper API, di-extract dari GroqWhisperSttEngine (mic) supaya bisa
 * dipakai juga oleh GroqWhisperPcmSttEngine (System Audio) tanpa duplikasi. Lihat
 * GroqWhisperSttEngine.kt untuk catatan kejujuran lengkap (belum pernah dites ke API
 * sungguhan) dan penjelasan kenapa Groq dipilih.
 */
object GroqTranscriptionClient {
    private const val ENDPOINT = "https://api.groq.com/openai/v1/audio/transcriptions"
    private const val MODEL = "whisper-large-v3-turbo"

    suspend fun transcribe(
        pcm: ShortArray,
        sampleRateHz: Int,
        languageTag: String?,
        apiKey: String?
    ): String? = withContext(Dispatchers.IO) {
        val wavBytes = WavEncoder.encode(pcm, sampleRateHz)
        val boundary = "----ADJDEV${UUID.randomUUID()}"
        val conn = (URL(ENDPOINT).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15_000
            readTimeout = 20_000
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        }

        conn.outputStream.use { out ->
            writeFormField(out, boundary, "model", MODEL)
            if (!languageTag.isNullOrBlank() && languageTag != "auto") {
                writeFormField(out, boundary, "language", languageTag)
            }
            writeFormField(out, boundary, "response_format", "json")
            writeFileField(out, boundary, "file", "audio.wav", "audio/wav", wavBytes)
            out.write("--$boundary--\r\n".toByteArray())
        }

        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader()?.use { it.readText() } ?: ""

        if (code !in 200..299) {
            val hint = when (code) {
                401 -> "Speech recognition unavailable: Groq API key salah/kadaluarsa — cek lagi di Pengaturan."
                429 -> "Speech recognition unavailable: kuota gratis Groq harian habis, coba lagi nanti."
                in 500..599 -> "Speech recognition unavailable: server Groq lagi bermasalah, coba lagi sesaat."
                else -> "Speech recognition unavailable: Groq STT gagal ($code)."
            }
            throw IllegalStateException("$hint\n$body")
        }
        JSONObject(body).optString("text").trim().ifBlank { null }
    }

    fun rmsOf(samples: ShortArray): Double {
        if (samples.isEmpty()) return 0.0
        var sum = 0.0
        for (s in samples) sum += s.toDouble() * s.toDouble()
        return kotlin.math.sqrt(sum / samples.size)
    }

    private fun writeFormField(out: OutputStream, boundary: String, name: String, value: String) {
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"$name\"\r\n\r\n".toByteArray())
        out.write("$value\r\n".toByteArray())
    }

    private fun writeFileField(
        out: OutputStream, boundary: String, name: String, filename: String,
        contentType: String, data: ByteArray
    ) {
        out.write("--$boundary\r\n".toByteArray())
        out.write("Content-Disposition: form-data; name=\"$name\"; filename=\"$filename\"\r\n".toByteArray())
        out.write("Content-Type: $contentType\r\n\r\n".toByteArray())
        out.write(data)
        out.write("\r\n".toByteArray())
    }
}
